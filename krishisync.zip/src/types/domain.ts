export type UserRole = 'farmer' | 'owner';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  region: string;
  organizationName: string;
  avatarInitials: string;
  createdAt: string;
}

export interface AuthSession {
  user: User;
  accessToken: string;
  expiresAt: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
  role: UserRole;
}

export interface RegisterPayload {
  name: string;
  email: string;
  phone: string;
  password: string;
  role: UserRole;
  region: string;
  organizationName: string;
}

export type EquipmentCategory =
  | 'Tractor'
  | 'Harvester'
  | 'Sprayer Drone'
  | 'Planter & Seeder'
  | 'Rotavator'
  | 'Laser Leveler';

export type EquipmentStatus = 'Available' | 'Booked' | 'In Operation' | 'Maintenance';

export interface Equipment {
  id: string;
  ownerId: string;
  ownerName: string;
  name: string;
  model: string;
  category: EquipmentCategory;
  workCapacityAcresPerHr: number;
  hourlyRateInr: number;
  dailyRateInr: number;
  location: string;
  coordinates: { lat: number; lng: number };
  status: EquipmentStatus;
  horsepowerOrSpec: string;
  imageUrl: string;
  utilizationPercent: number;
  nextAvailableDate: string;
  lastServicedDate: string;
}

export type EquipmentInput = Omit<
  Equipment,
  'id' | 'ownerId' | 'ownerName' | 'utilizationPercent' | 'lastServicedDate'
>;

export type CropType = 'Wheat' | 'Paddy Rice' | 'Sugarcane' | 'Soybean' | 'Cotton' | 'Maize';

export type OperationType =
  | 'Plowing'
  | 'Sowing'
  | 'Harvesting'
  | 'Spraying'
  | 'Soil Leveling'
  | 'Rotavation';

export interface Plot {
  id: string;
  farmerId: string;
  farmerName: string;
  name: string;
  areaAcres: number;
  cropType: CropType;
  locationLabel: string;
  coordinates: { lat: number; lng: number };
  operationType: OperationType;
  deadline: string;
  soilMoisturePercent: number;
  notes: string;
}

export type PlotInput = Omit<Plot, 'id' | 'farmerId' | 'farmerName'>;

export type BookingStatus =
  | 'Pending'
  | 'Confirmed'
  | 'Scheduled'
  | 'In Progress'
  | 'Completed'
  | 'Cancelled'
  | 'Disrupted';

export type BookingPriority = 'Critical' | 'High' | 'Standard';

export interface Booking {
  id: string;
  farmerId: string;
  farmerName: string;
  ownerId: string;
  ownerName: string;
  equipmentId: string;
  equipmentName: string;
  equipmentCategory: EquipmentCategory;
  plotId: string;
  plotName: string;
  plotAreaAcres: number;
  operationType: OperationType;
  requestedDate: string;
  deadline: string;
  estimatedHours: number;
  estimatedCostInr: number;
  priority: BookingPriority;
  status: BookingStatus;
  travelDistanceKm: number;
  notes?: string;
  createdAt: string;
}

export interface BookingInput {
  equipmentId: string;
  plotId: string;
  operationType: OperationType;
  requestedDate: string;
  deadline: string;
  priority: BookingPriority;
  notes?: string;
}

export interface ScheduleSlot {
  id: string;
  bookingId: string;
  equipmentId: string;
  equipmentName: string;
  plotId: string;
  plotName: string;
  farmerName: string;
  operationType: OperationType;
  date: string;
  startHour: number;
  durationHours: number;
  travelBufferMinutes: number;
  travelOriginLabel: string;
  priority: BookingPriority;
  status: 'Allocated' | 'Conflict' | 'Revised';
}

export interface ScheduleConflict {
  id: string;
  severity: 'High' | 'Medium';
  equipmentId: string;
  equipmentName: string;
  date: string;
  summary: string;
  affectedBookingIds: string[];
  recommendedAction: string;
  resolved: boolean;
}

export interface ScheduleGenerationParams {
  startDate: string;
  horizonDays: number;
  prioritizeDeadlines: boolean;
  includeTravelBuffers: boolean;
  bufferMinutesPer10Km: number;
}

export interface ScheduleGenerationResponse {
  sourceMode: 'external-api' | 'supabase-rpc' | 'demo-adapter';
  generatedAt: string;
  slots: ScheduleSlot[];
  conflicts: ScheduleConflict[];
  summary: {
    totalAllocatedHours: number;
    totalTravelBufferMinutes: number;
    onTimeDeadlineRatePercent: number;
    unresolvedConflicts: number;
  };
}

export type DisruptionType = 'Machine Breakdown' | 'Severe Weather';
export type DisruptionSeverity = 'Critical' | 'Moderate';

export interface AlternativeSuggestion {
  equipmentId: string;
  equipmentName: string;
  category: EquipmentCategory;
  distanceKm: number;
  hourlyRateInr: number;
  earliestWindow: string;
  compatibilityNote: string;
}

export interface RevisedScheduleItem {
  bookingId: string;
  plotName: string;
  previousEquipmentName: string;
  newEquipmentId: string;
  newEquipmentName: string;
  previousWindow: string;
  revisedWindow: string;
  status: 'Proposed' | 'Applied';
}

export interface DisruptionReport {
  id: string;
  type: DisruptionType;
  severity: DisruptionSeverity;
  equipmentId?: string;
  equipmentName?: string;
  affectedRegion: string;
  reportedBy: string;
  reportedAt: string;
  description: string;
  status: 'Active' | 'Mitigated';
  affectedBookingIds: string[];
  alternatives: AlternativeSuggestion[];
  revisedPlan: RevisedScheduleItem[];
}

export interface DisruptionInput {
  type: DisruptionType;
  severity: DisruptionSeverity;
  equipmentId?: string;
  affectedRegion: string;
  description: string;
}

export type NotificationCategory = 'Booking Update' | 'Urgent Deadline' | 'Rescheduling';

export interface AppNotification {
  id: string;
  category: NotificationCategory;
  severity: 'info' | 'warning' | 'critical';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  actionRoute: string;
  actionLabel: string;
  relatedId?: string;
}

export interface FarmerDashboardData {
  metrics: {
    totalBookings: number;
    upcomingOperations: number;
    urgentDeadlines: number;
    availableEquipmentCount: number;
  };
  weeklyOperationsChart: Array<{
    day: string;
    scheduledHours: number;
    completedAcres: number;
  }>;
  recentActivities: Array<{
    id: string;
    title: string;
    detail: string;
    timestamp: string;
  }>;
}

export interface OwnerDashboardData {
  metrics: {
    registeredMachines: number;
    availableEquipment: number;
    pendingRequests: number;
    upcomingSchedules: number;
  };
  revenueUtilizationChart: Array<{
    month: string;
    revenueInr: number;
    utilizationPercent: number;
  }>;
}
