export type DbUserRole = 'farmer' | 'equipment_owner' | 'admin';

export type DbEquipmentType =
  | 'Tractor'
  | 'Harvester'
  | 'Sprayer'
  | 'Seeder'
  | 'Plough'
  | 'Other';

export type DbEquipmentAvailability =
  | 'available'
  | 'booked'
  | 'in_operation'
  | 'maintenance'
  | 'unavailable';

export type DbBookingStatus =
  | 'pending'
  | 'accepted'
  | 'rejected'
  | 'scheduled'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  | 'rescheduling_required';

export type DbScheduleStatus =
  | 'scheduled'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  | 'rescheduling_required';

export type DbDisruptionType =
  | 'machine_breakdown'
  | 'weather_disruption'
  | 'equipment_unavailable'
  | 'other';

export type DbDisruptionStatus = 'active' | 'mitigated' | 'resolved';

export type DbNotificationType =
  | 'booking_request'
  | 'booking_accepted'
  | 'booking_rejected'
  | 'schedule_updated'
  | 'deadline_warning'
  | 'equipment_breakdown'
  | 'weather_disruption'
  | 'rescheduling';

export interface ProfileRow {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  role: DbUserRole;
  address: string;
  latitude: number | null;
  longitude: number | null;
  created_at: string;
  updated_at: string;
}

export interface EquipmentRow {
  id: string;
  owner_id: string;
  equipment_name: string;
  equipment_type: DbEquipmentType;
  brand: string;
  model: string;
  description: string;
  work_rate_acres_per_hour: number;
  hourly_rate: number;
  per_acre_rate: number;
  latitude: number;
  longitude: number;
  address: string;
  availability_status: DbEquipmentAvailability;
  created_at: string;
  updated_at: string;
}

export interface PlotRow {
  id: string;
  farmer_id: string;
  plot_name: string;
  area_acres: number;
  crop_type: string;
  operation_type: string;
  latitude: number;
  longitude: number;
  address: string;
  preferred_start_time: string | null;
  deadline: string;
  created_at: string;
  updated_at: string;
}

export interface BookingRow {
  id: string;
  farmer_id: string;
  equipment_id: string;
  plot_id: string;
  operation_type: string;
  requested_start_time: string;
  requested_deadline: string;
  estimated_duration_hours: number;
  status: DbBookingStatus;
  priority_score: number;
  assigned_start_time: string | null;
  assigned_end_time: string | null;
  rejection_reason: string | null;
  created_at: string;
  updated_at: string;
}

export interface BookingHistoryRow {
  id: string;
  booking_id: string;
  previous_status: DbBookingStatus | null;
  new_status: DbBookingStatus;
  changed_by: string | null;
  note: string;
  changed_at: string;
}

export interface ScheduleRow {
  id: string;
  booking_id: string;
  equipment_id: string;
  farmer_id: string;
  plot_id: string;
  scheduled_start: string;
  scheduled_end: string;
  travel_buffer_minutes: number;
  estimated_travel_distance_km: number;
  status: DbScheduleStatus;
  scheduling_reason: string;
  created_at: string;
  updated_at: string;
}

export interface DisruptionRow {
  id: string;
  equipment_id: string | null;
  disruption_type: DbDisruptionType;
  description: string;
  start_time: string;
  end_time: string | null;
  affected_area: string;
  status: DbDisruptionStatus;
  reported_by: string;
  created_at: string;
}

export interface NotificationRow {
  id: string;
  user_id: string;
  title: string;
  message: string;
  notification_type: DbNotificationType;
  related_booking_id: string | null;
  is_read: boolean;
  created_at: string;
}
