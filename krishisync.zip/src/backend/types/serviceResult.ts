export interface PaginationParams {
  page?: number;
  pageSize?: number;
}

export interface ResponseMeta {
  page: number;
  pageSize: number;
  total: number;
}

export interface ServiceResponse<T> {
  success: boolean;
  data: T | null;
  error: string | null;
  meta?: ResponseMeta;
}

export function ok<T>(data: T, meta?: ResponseMeta): ServiceResponse<T> {
  return {
    success: true,
    data,
    error: null,
    ...(meta ? { meta } : {}),
  };
}

export function fail<T = never>(error: unknown): ServiceResponse<T> {
  const message =
    error instanceof Error
      ? error.message
      : typeof error === 'string'
      ? error
      : 'An unexpected backend error occurred.';
  return {
    success: false,
    data: null,
    error: message,
  };
}

export function normalizePagination(params?: PaginationParams): {
  page: number;
  pageSize: number;
  from: number;
  to: number;
} {
  const page = Math.max(1, Math.floor(params?.page ?? 1));
  const pageSize = Math.min(100, Math.max(1, Math.floor(params?.pageSize ?? 20)));
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;
  return { page, pageSize, from, to };
}
