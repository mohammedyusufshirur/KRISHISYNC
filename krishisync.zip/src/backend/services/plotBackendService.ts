import { assertValidCoordinates, getDatabaseClient } from '../lib/supabaseConnection';
import { PlotRow } from '../types/database.types';
import {
  fail,
  normalizePagination,
  ok,
  PaginationParams,
  ServiceResponse,
} from '../types/serviceResult';

export interface CreatePlotInput {
  plot_name: string;
  area_acres: number;
  crop_type: string;
  operation_type: string;
  latitude: number;
  longitude: number;
  address?: string;
  preferred_start_time?: string | null;
  deadline: string;
}

export async function createPlot(
  input: CreatePlotInput
): Promise<ServiceResponse<PlotRow>> {
  try {
    if (!input.plot_name.trim() || input.area_acres <= 0 || !input.deadline) {
      throw new Error('Plot name, positive area_acres, and deadline are required.');
    }
    if (input.preferred_start_time && input.preferred_start_time > input.deadline) {
      throw new Error('preferred_start_time cannot be after deadline.');
    }
    assertValidCoordinates(input.latitude, input.longitude);

    const db = getDatabaseClient();
    const { data: authData, error: authErr } = await db.auth.getUser();
    if (authErr || !authData.user) throw new Error('Authenticated farmer account required.');

    const { data, error } = await db
      .from('plots')
      .insert({
        farmer_id: authData.user.id,
        plot_name: input.plot_name.trim(),
        area_acres: input.area_acres,
        crop_type: input.crop_type.trim(),
        operation_type: input.operation_type.trim(),
        latitude: input.latitude,
        longitude: input.longitude,
        address: input.address?.trim() ?? '',
        preferred_start_time: input.preferred_start_time ?? null,
        deadline: input.deadline,
      })
      .select('*')
      .single();

    if (error) throw new Error(error.message);
    return ok(data as PlotRow);
  } catch (err) {
    return fail(err);
  }
}

export async function getFarmerPlots(
  farmerId?: string,
  pagination?: PaginationParams
): Promise<ServiceResponse<PlotRow[]>> {
  try {
    const db = getDatabaseClient();
    let targetFarmerId = farmerId;
    if (!targetFarmerId) {
      const { data: authData, error: authErr } = await db.auth.getUser();
      if (authErr || !authData.user) throw new Error('Authenticated user required.');
      targetFarmerId = authData.user.id;
    }

    const { page, pageSize, from, to } = normalizePagination(pagination);
    const { data, error, count } = await db
      .from('plots')
      .select('*', { count: 'exact' })
      .eq('farmer_id', targetFarmerId)
      .order('deadline', { ascending: true })
      .range(from, to);

    if (error) throw new Error(error.message);
    return ok((data ?? []) as PlotRow[], {
      page,
      pageSize,
      total: count ?? 0,
    });
  } catch (err) {
    return fail(err);
  }
}

export async function getPlotById(plotId: string): Promise<ServiceResponse<PlotRow>> {
  try {
    const db = getDatabaseClient();
    const { data, error } = await db.from('plots').select('*').eq('id', plotId).single();
    if (error) throw new Error(error.message);
    return ok(data as PlotRow);
  } catch (err) {
    return fail(err);
  }
}

export async function updatePlot(
  plotId: string,
  patch: Partial<CreatePlotInput>
): Promise<ServiceResponse<PlotRow>> {
  try {
    if (patch.area_acres !== undefined && patch.area_acres <= 0) {
      throw new Error('area_acres must be greater than 0.');
    }
    if (patch.latitude !== undefined || patch.longitude !== undefined) {
      if (patch.latitude === undefined || patch.longitude === undefined) {
        throw new Error('Both latitude and longitude must be supplied together.');
      }
      assertValidCoordinates(patch.latitude, patch.longitude);
    }

    const db = getDatabaseClient();
    const { data, error } = await db
      .from('plots')
      .update(patch)
      .eq('id', plotId)
      .select('*')
      .single();

    if (error) throw new Error(error.message);
    return ok(data as PlotRow);
  } catch (err) {
    return fail(err);
  }
}

export async function deletePlot(plotId: string): Promise<ServiceResponse<null>> {
  try {
    const db = getDatabaseClient();
    const { error } = await db.from('plots').delete().eq('id', plotId);
    if (error) throw new Error(error.message);
    return ok(null);
  } catch (err) {
    return fail(err);
  }
}
