import { getDatabaseClient } from '../lib/supabaseConnection';
import { BookingHistoryRow, BookingRow, DbBookingStatus } from '../types/database.types';
import {
  fail,
  normalizePagination,
  ok,
  PaginationParams,
  ServiceResponse,
} from '../types/serviceResult';

export interface CreateBookingInput {
  equipment_id: string;
  plot_id: string;
  operation_type: string;
  requested_start_time: string;
  requested_deadline: string;
  priority_score?: number;
}

export async function createBooking(
  input: CreateBookingInput
): Promise<ServiceResponse<BookingRow>> {
  try {
    if (!input.equipment_id || !input.plot_id || !input.operation_type.trim()) {
      throw new Error('equipment_id, plot_id, and operation_type are required.');
    }
    if (input.requested_deadline < input.requested_start_time) {
      throw new Error('requested_deadline cannot be earlier than requested_start_time.');
    }

    const db = getDatabaseClient();
    const { data, error } = await db.rpc('create_booking_request', {
      p_equipment_id: input.equipment_id,
      p_plot_id: input.plot_id,
      p_operation_type: input.operation_type.trim(),
      p_requested_start_time: input.requested_start_time,
      p_requested_deadline: input.requested_deadline,
      p_priority_score: input.priority_score ?? 50,
    });

    if (error) throw new Error(error.message);
    return ok(data as BookingRow);
  } catch (err) {
    return fail(err);
  }
}

export async function getFarmerBookings(
  farmerId?: string,
  pagination?: PaginationParams
): Promise<ServiceResponse<BookingRow[]>> {
  try {
    const db = getDatabaseClient();
    let targetFarmerId = farmerId;
    if (!targetFarmerId) {
      const { data: authData, error: authErr } = await db.auth.getUser();
      if (authErr || !authData.user) throw new Error('Authenticated user required.');
      targetFarmerId = authData.user.id;
    }

    const { page, pageSize, from, to } = normalizePagination(pagination);
    const { data, error, count } = await db
      .from('bookings')
      .select('*', { count: 'exact' })
      .eq('farmer_id', targetFarmerId)
      .order('created_at', { ascending: false })
      .range(from, to);

    if (error) throw new Error(error.message);
    return ok((data ?? []) as BookingRow[], {
      page,
      pageSize,
      total: count ?? 0,
    });
  } catch (err) {
    return fail(err);
  }
}

export async function getOwnerBookings(
  ownerId?: string,
  pagination?: PaginationParams
): Promise<ServiceResponse<BookingRow[]>> {
  try {
    const db = getDatabaseClient();
    let targetOwnerId = ownerId;
    if (!targetOwnerId) {
      const { data: authData, error: authErr } = await db.auth.getUser();
      if (authErr || !authData.user) throw new Error('Authenticated user required.');
      targetOwnerId = authData.user.id;
    }

    const { page, pageSize, from, to } = normalizePagination(pagination);
    const { data, error, count } = await db
      .from('bookings')
      .select('*, equipment!inner(owner_id)', { count: 'exact' })
      .eq('equipment.owner_id', targetOwnerId)
      .order('created_at', { ascending: false })
      .range(from, to);

    if (error) throw new Error(error.message);
    return ok((data ?? []) as BookingRow[], {
      page,
      pageSize,
      total: count ?? 0,
    });
  } catch (err) {
    return fail(err);
  }
}

export async function acceptBooking(
  bookingId: string
): Promise<ServiceResponse<BookingRow>> {
  try {
    const db = getDatabaseClient();
    const { data, error } = await db.rpc('respond_to_booking', {
      p_booking_id: bookingId,
      p_decision: 'accept',
      p_rejection_reason: null,
    });
    if (error) throw new Error(error.message);
    return ok(data as BookingRow);
  } catch (err) {
    return fail(err);
  }
}

export async function rejectBooking(
  bookingId: string,
  rejectionReason: string
): Promise<ServiceResponse<BookingRow>> {
  try {
    const db = getDatabaseClient();
    const { data, error } = await db.rpc('respond_to_booking', {
      p_booking_id: bookingId,
      p_decision: 'reject',
      p_rejection_reason: rejectionReason,
    });
    if (error) throw new Error(error.message);
    return ok(data as BookingRow);
  } catch (err) {
    return fail(err);
  }
}

export async function cancelBooking(
  bookingId: string
): Promise<ServiceResponse<BookingRow>> {
  return updateBookingStatus(bookingId, 'cancelled');
}

export async function updateBookingStatus(
  bookingId: string,
  status: DbBookingStatus
): Promise<ServiceResponse<BookingRow>> {
  try {
    const db = getDatabaseClient();
    const { data, error } = await db
      .from('bookings')
      .update({ status })
      .eq('id', bookingId)
      .select('*')
      .single();

    if (error) throw new Error(error.message);
    return ok(data as BookingRow);
  } catch (err) {
    return fail(err);
  }
}

export async function getBookingHistory(
  bookingId: string
): Promise<ServiceResponse<BookingHistoryRow[]>> {
  try {
    const db = getDatabaseClient();
    const { data, error } = await db
      .from('booking_history')
      .select('*')
      .eq('booking_id', bookingId)
      .order('changed_at', { ascending: false });

    if (error) throw new Error(error.message);
    return ok((data ?? []) as BookingHistoryRow[]);
  } catch (err) {
    return fail(err);
  }
}
