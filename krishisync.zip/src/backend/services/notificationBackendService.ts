import { getDatabaseClient } from '../lib/supabaseConnection';
import { DbNotificationType, NotificationRow } from '../types/database.types';
import {
  fail,
  normalizePagination,
  ok,
  PaginationParams,
  ServiceResponse,
} from '../types/serviceResult';

export interface CreateNotificationInput {
  user_id: string;
  title: string;
  message: string;
  notification_type: DbNotificationType;
  related_booking_id?: string | null;
}

export async function createNotification(
  input: CreateNotificationInput
): Promise<ServiceResponse<NotificationRow>> {
  try {
    if (!input.user_id || !input.title.trim() || !input.message.trim()) {
      throw new Error('user_id, title, and message are required.');
    }

    const db = getDatabaseClient();
    const { data, error } = await db
      .from('notifications')
      .insert({
        user_id: input.user_id,
        title: input.title.trim(),
        message: input.message.trim(),
        notification_type: input.notification_type,
        related_booking_id: input.related_booking_id ?? null,
      })
      .select('*')
      .single();

    if (error) throw new Error(error.message);
    return ok(data as NotificationRow);
  } catch (err) {
    return fail(err);
  }
}

export async function getNotifications(
  userId?: string,
  pagination?: PaginationParams
): Promise<ServiceResponse<NotificationRow[]>> {
  try {
    const db = getDatabaseClient();
    let targetUserId = userId;
    if (!targetUserId) {
      const { data: authData, error: authErr } = await db.auth.getUser();
      if (authErr || !authData.user) throw new Error('Authenticated user required.');
      targetUserId = authData.user.id;
    }

    const { page, pageSize, from, to } = normalizePagination(pagination);
    const { data, error, count } = await db
      .from('notifications')
      .select('*', { count: 'exact' })
      .eq('user_id', targetUserId)
      .order('created_at', { ascending: false })
      .range(from, to);

    if (error) throw new Error(error.message);
    return ok((data ?? []) as NotificationRow[], {
      page,
      pageSize,
      total: count ?? 0,
    });
  } catch (err) {
    return fail(err);
  }
}

export async function markNotificationRead(
  notificationId: string
): Promise<ServiceResponse<NotificationRow>> {
  try {
    const db = getDatabaseClient();
    const { data, error } = await db
      .from('notifications')
      .update({ is_read: true })
      .eq('id', notificationId)
      .select('*')
      .single();

    if (error) throw new Error(error.message);
    return ok(data as NotificationRow);
  } catch (err) {
    return fail(err);
  }
}

export async function markAllNotificationsRead(
  userId?: string
): Promise<ServiceResponse<boolean>> {
  try {
    const db = getDatabaseClient();
    let targetUserId = userId;
    if (!targetUserId) {
      const { data: authData, error: authErr } = await db.auth.getUser();
      if (authErr || !authData.user) throw new Error('Authenticated user required.');
      targetUserId = authData.user.id;
    }

    const { error } = await db
      .from('notifications')
      .update({ is_read: true })
      .eq('user_id', targetUserId)
      .eq('is_read', false);

    if (error) throw new Error(error.message);
    return ok(true);
  } catch (err) {
    return fail(err);
  }
}

export function subscribeToNotifications(
  userId: string,
  onNotification: (notification: NotificationRow) => void
): () => void {
  const db = getDatabaseClient();
  const channel = db
    .channel(`notifications:${userId}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'notifications',
        filter: `user_id=eq.${userId}`,
      },
      (payload) => {
        if (payload.new) {
          onNotification(payload.new as NotificationRow);
        }
      }
    )
    .subscribe();

  return () => {
    void db.removeChannel(channel);
  };
}
