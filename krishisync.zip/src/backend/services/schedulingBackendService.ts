import { getDatabaseClient } from '../lib/supabaseConnection';
import {
  BookingRow,
  DbScheduleStatus,
  EquipmentRow,
  PlotRow,
  ScheduleRow,
} from '../types/database.types';
import {
  fail,
  normalizePagination,
  ok,
  PaginationParams,
  ServiceResponse,
} from '../types/serviceResult';

export interface SaveScheduleInput {
  booking_id: string;
  equipment_id: string;
  scheduled_start: string;
  scheduled_end: string;
  travel_buffer_minutes?: number;
  estimated_travel_distance_km?: number;
  scheduling_reason?: string;
}

export interface UpdateScheduleInput {
  scheduled_start?: string;
  scheduled_end?: string;
  travel_buffer_minutes?: number;
  estimated_travel_distance_km?: number;
  status?: DbScheduleStatus;
  scheduling_reason?: string;
}

export interface EquipmentLocationPoint {
  id: string;
  equipment_name: string;
  equipment_type: EquipmentRow['equipment_type'];
  latitude: number;
  longitude: number;
  address: string;
  availability_status: EquipmentRow['availability_status'];
}

export interface PlotLocationPoint {
  id: string;
  plot_name: string;
  area_acres: number;
  crop_type: string;
  operation_type: string;
  latitude: number;
  longitude: number;
  address: string;
  deadline: string;
}

/**
 * Provides pending/accepted/rescheduling_required bookings sorted by priority & deadline
 * for Member 3's scheduling engine.
 */
export async function getPendingBookings(
  pagination?: PaginationParams
): Promise<ServiceResponse<BookingRow[]>> {
  try {
    const db = getDatabaseClient();
    const { page, pageSize, from, to } = normalizePagination(pagination);

    const { data, error, count } = await db
      .from('bookings')
      .select('*', { count: 'exact' })
      .in('status', ['pending', 'accepted', 'rescheduling_required'])
      .order('priority_score', { ascending: false })
      .order('requested_deadline', { ascending: true })
      .range(from, to);

    if (error) throw new Error(error.message);
    return ok((data ?? []) as BookingRow[], {
      page,
      pageSize,
      total: count ?? 0,
    });
  } catch (err) {
    return fail(err);
  }
}

/**
 * Provides machines eligible for scheduling ('available' or 'booked').
 */
export async function getAvailableEquipment(
  pagination?: PaginationParams
): Promise<ServiceResponse<EquipmentRow[]>> {
  try {
    const db = getDatabaseClient();
    const { page, pageSize, from, to } = normalizePagination(pagination);

    const { data, error, count } = await db
      .from('equipment')
      .select('*', { count: 'exact' })
      .in('availability_status', ['available', 'booked'])
      .order('created_at', { ascending: false })
      .range(from, to);

    if (error) throw new Error(error.message);
    return ok((data ?? []) as EquipmentRow[], {
      page,
      pageSize,
      total: count ?? 0,
    });
  } catch (err) {
    return fail(err);
  }
}

export async function getEquipmentLocations(): Promise<
  ServiceResponse<EquipmentLocationPoint[]>
> {
  try {
    const db = getDatabaseClient();
    const { data, error } = await db
      .from('equipment')
      .select(
        'id, equipment_name, equipment_type, latitude, longitude, address, availability_status'
      );

    if (error) throw new Error(error.message);
    return ok((data ?? []) as EquipmentLocationPoint[]);
  } catch (err) {
    return fail(err);
  }
}

export async function getPlotLocations(): Promise<ServiceResponse<PlotLocationPoint[]>> {
  try {
    const db = getDatabaseClient();
    const { data, error } = await db
      .from('plots')
      .select(
        'id, plot_name, area_acres, crop_type, operation_type, latitude, longitude, address, deadline'
      );

    if (error) throw new Error(error.message);
    return ok((data ?? []) as PlotLocationPoint[]);
  } catch (err) {
    return fail(err);
  }
}

export async function getEquipmentSchedule(
  equipmentId?: string,
  pagination?: PaginationParams
): Promise<ServiceResponse<ScheduleRow[]>> {
  try {
    const db = getDatabaseClient();
    const { page, pageSize, from, to } = normalizePagination(pagination);

    let query = db
      .from('schedules')
      .select('*', { count: 'exact' })
      .order('scheduled_start', { ascending: true })
      .range(from, to);

    if (equipmentId) {
      query = query.eq('equipment_id', equipmentId);
    }

    const { data, error, count } = await query;
    if (error) throw new Error(error.message);

    return ok((data ?? []) as ScheduleRow[], {
      page,
      pageSize,
      total: count ?? 0,
    });
  } catch (err) {
    return fail(err);
  }
}

/**
 * Persists a conflict-free machine allocation via the transactional
 * `save_schedule_allocation` RPC (enforced by PostgreSQL GIST exclusion constraints).
 */
export async function saveSchedule(
  input: SaveScheduleInput
): Promise<ServiceResponse<ScheduleRow>> {
  try {
    if (!input.booking_id || !input.equipment_id) {
      throw new Error('booking_id and equipment_id are required.');
    }
    if (new Date(input.scheduled_end) <= new Date(input.scheduled_start)) {
      throw new Error('scheduled_end must be strictly after scheduled_start.');
    }

    const db = getDatabaseClient();
    const { data, error } = await db.rpc('save_schedule_allocation', {
      p_booking_id: input.booking_id,
      p_equipment_id: input.equipment_id,
      p_scheduled_start: input.scheduled_start,
      p_scheduled_end: input.scheduled_end,
      p_travel_buffer_minutes: input.travel_buffer_minutes ?? 0,
      p_estimated_travel_distance_km: input.estimated_travel_distance_km ?? 0,
      p_scheduling_reason: input.scheduling_reason ?? '',
    });

    if (error) throw new Error(error.message);
    return ok(data as ScheduleRow);
  } catch (err) {
    return fail(err);
  }
}

export async function updateSchedule(
  scheduleId: string,
  patch: UpdateScheduleInput
): Promise<ServiceResponse<ScheduleRow>> {
  try {
    if (
      patch.scheduled_start &&
      patch.scheduled_end &&
      new Date(patch.scheduled_end) <= new Date(patch.scheduled_start)
    ) {
      throw new Error('scheduled_end must be strictly after scheduled_start.');
    }

    const db = getDatabaseClient();
    const { data, error } = await db
      .from('schedules')
      .update(patch)
      .eq('id', scheduleId)
      .select('*')
      .single();

    if (error) throw new Error(error.message);
    return ok(data as ScheduleRow);
  } catch (err) {
    return fail(err);
  }
}
