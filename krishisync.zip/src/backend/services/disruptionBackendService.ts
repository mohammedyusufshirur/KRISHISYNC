import { getDatabaseClient } from '../lib/supabaseConnection';
import {
  BookingRow,
  DbDisruptionStatus,
  DbDisruptionType,
  DisruptionRow,
  EquipmentRow,
} from '../types/database.types';
import {
  fail,
  normalizePagination,
  ok,
  PaginationParams,
  ServiceResponse,
} from '../types/serviceResult';

export interface ReportDisruptionInput {
  disruption_type: DbDisruptionType;
  description: string;
  equipment_id?: string | null;
  start_time?: string;
  end_time?: string | null;
  affected_area?: string;
}

/**
 * Reports an equipment breakdown or weather disruption transactionally via `report_disruption_tx`.
 * Marks affected machine maintenance/unavailable and flags overlapping schedules/bookings as
 * 'rescheduling_required' without deleting or cancelling confirmed bookings.
 */
export async function reportDisruption(
  input: ReportDisruptionInput
): Promise<ServiceResponse<DisruptionRow>> {
  try {
    if (!input.description || input.description.trim().length < 3) {
      throw new Error('Disruption description must be at least 3 characters.');
    }
    if (input.disruption_type === 'machine_breakdown' && !input.equipment_id) {
      throw new Error('equipment_id is required when reporting a machine_breakdown.');
    }

    const db = getDatabaseClient();
    const { data, error } = await db.rpc('report_disruption_tx', {
      p_disruption_type: input.disruption_type,
      p_description: input.description.trim(),
      p_equipment_id: input.equipment_id ?? null,
      p_start_time: input.start_time ?? new Date().toISOString(),
      p_end_time: input.end_time ?? null,
      p_affected_area: input.affected_area ?? '',
    });

    if (error) throw new Error(error.message);
    return ok(data as DisruptionRow);
  } catch (err) {
    return fail(err);
  }
}

export async function getDisruptions(
  statusFilter?: DbDisruptionStatus,
  pagination?: PaginationParams
): Promise<ServiceResponse<DisruptionRow[]>> {
  try {
    const db = getDatabaseClient();
    const { page, pageSize, from, to } = normalizePagination(pagination);

    let query = db
      .from('disruptions')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(from, to);

    if (statusFilter) {
      query = query.eq('status', statusFilter);
    }

    const { data, error, count } = await query;
    if (error) throw new Error(error.message);

    return ok((data ?? []) as DisruptionRow[], {
      page,
      pageSize,
      total: count ?? 0,
    });
  } catch (err) {
    return fail(err);
  }
}

export async function getAffectedBookings(
  equipmentId?: string
): Promise<ServiceResponse<BookingRow[]>> {
  try {
    const db = getDatabaseClient();
    let query = db
      .from('bookings')
      .select('*')
      .eq('status', 'rescheduling_required')
      .order('requested_deadline', { ascending: true });

    if (equipmentId) {
      query = query.eq('equipment_id', equipmentId);
    }

    const { data, error } = await query;
    if (error) throw new Error(error.message);
    return ok((data ?? []) as BookingRow[]);
  } catch (err) {
    return fail(err);
  }
}

export async function restoreEquipmentAvailability(
  equipmentId: string,
  disruptionId?: string
): Promise<ServiceResponse<EquipmentRow>> {
  try {
    if (!equipmentId) {
      throw new Error('equipmentId is required.');
    }

    const db = getDatabaseClient();
    const { data, error } = await db.rpc('restore_equipment_availability', {
      p_equipment_id: equipmentId,
      p_disruption_id: disruptionId ?? null,
    });

    if (error) throw new Error(error.message);
    return ok(data as EquipmentRow);
  } catch (err) {
    return fail(err);
  }
}
