import { getDatabaseClient } from '../lib/supabaseConnection';
import { DbUserRole, ProfileRow } from '../types/database.types';
import { fail, ok, ServiceResponse } from '../types/serviceResult';

export interface RegisterUserInput {
  email: string;
  password: string;
  full_name: string;
  phone?: string;
  role: Extract<DbUserRole, 'farmer' | 'equipment_owner'>;
  address?: string;
  latitude?: number | null;
  longitude?: number | null;
}

export interface LoginUserInput {
  email: string;
  password: string;
}

export interface UpdateProfileInput {
  full_name?: string;
  phone?: string;
  address?: string;
  latitude?: number | null;
  longitude?: number | null;
}

export async function registerUser(
  input: RegisterUserInput
): Promise<ServiceResponse<{ userId: string; email: string; profile: ProfileRow | null }>> {
  try {
    if (!input.email.trim() || input.password.length < 6 || input.full_name.trim().length < 2) {
      throw new Error('Valid email, full name, and a password of at least 6 characters are required.');
    }

    // Ordinary registration can never self-assign 'admin'
    const safeRole: Extract<DbUserRole, 'farmer' | 'equipment_owner'> =
      input.role === 'equipment_owner' ? 'equipment_owner' : 'farmer';

    const db = getDatabaseClient();
    const { data, error } = await db.auth.signUp({
      email: input.email.trim(),
      password: input.password,
      options: {
        data: {
          full_name: input.full_name.trim(),
          phone: input.phone?.trim() ?? '',
          role: safeRole,
          address: input.address?.trim() ?? '',
          latitude: input.latitude ?? null,
          longitude: input.longitude ?? null,
        },
      },
    });

    if (error) throw new Error(error.message);
    if (!data.user) throw new Error('Registration did not return a user record.');

    let profile: ProfileRow | null = null;
    if (data.session) {
      const profileRes = await db
        .from('profiles')
        .select('*')
        .eq('id', data.user.id)
        .maybeSingle();
      if (!profileRes.error && profileRes.data) {
        profile = profileRes.data as ProfileRow;
      }
    }

    return ok({
      userId: data.user.id,
      email: data.user.email ?? input.email.trim(),
      profile,
    });
  } catch (err) {
    return fail(err);
  }
}

export async function loginUser(
  input: LoginUserInput
): Promise<ServiceResponse<{ accessToken: string; profile: ProfileRow | null }>> {
  try {
    if (!input.email.trim() || !input.password) {
      throw new Error('Email and password are required.');
    }

    const db = getDatabaseClient();
    const { data, error } = await db.auth.signInWithPassword({
      email: input.email.trim(),
      password: input.password,
    });

    if (error) throw new Error(error.message);
    if (!data.session || !data.user) throw new Error('No active session returned by Supabase Auth.');

    const { data: profileData, error: profileErr } = await db
      .from('profiles')
      .select('*')
      .eq('id', data.user.id)
      .maybeSingle();

    if (profileErr) throw new Error(profileErr.message);

    return ok({
      accessToken: data.session.access_token,
      profile: (profileData as ProfileRow | null) ?? null,
    });
  } catch (err) {
    return fail(err);
  }
}

export async function logoutUser(): Promise<ServiceResponse<null>> {
  try {
    const db = getDatabaseClient();
    const { error } = await db.auth.signOut();
    if (error) throw new Error(error.message);
    return ok(null);
  } catch (err) {
    return fail(err);
  }
}

export async function getCurrentUser(): Promise<ServiceResponse<ProfileRow | null>> {
  try {
    const db = getDatabaseClient();
    const { data: userData, error: userErr } = await db.auth.getUser();
    if (userErr) throw new Error(userErr.message);
    if (!userData.user) return ok(null);

    const { data, error } = await db
      .from('profiles')
      .select('*')
      .eq('id', userData.user.id)
      .maybeSingle();

    if (error) throw new Error(error.message);
    return ok((data as ProfileRow | null) ?? null);
  } catch (err) {
    return fail(err);
  }
}

export async function resetPassword(
  email: string,
  redirectTo?: string
): Promise<ServiceResponse<null>> {
  try {
    if (!email.trim()) throw new Error('Email address is required for password reset.');
    const db = getDatabaseClient();
    const { error } = await db.auth.resetPasswordForEmail(email.trim(), {
      redirectTo,
    });
    if (error) throw new Error(error.message);
    return ok(null);
  } catch (err) {
    return fail(err);
  }
}

export async function updateProfile(
  patch: UpdateProfileInput
): Promise<ServiceResponse<ProfileRow>> {
  try {
    const db = getDatabaseClient();
    const { data: userData, error: authErr } = await db.auth.getUser();
    if (authErr || !userData.user) throw new Error('Authenticated session required.');

    const { data, error } = await db
      .from('profiles')
      .update(patch)
      .eq('id', userData.user.id)
      .select('*')
      .single();

    if (error) throw new Error(error.message);
    return ok(data as ProfileRow);
  } catch (err) {
    return fail(err);
  }
}
