import { assertValidCoordinates, getDatabaseClient } from '../lib/supabaseConnection';
import {
  DbEquipmentAvailability,
  DbEquipmentType,
  EquipmentRow,
} from '../types/database.types';
import {
  fail,
  normalizePagination,
  ok,
  PaginationParams,
  ServiceResponse,
} from '../types/serviceResult';

export interface CreateEquipmentInput {
  equipment_name: string;
  equipment_type: DbEquipmentType;
  brand?: string;
  model?: string;
  description?: string;
  work_rate_acres_per_hour: number;
  hourly_rate: number;
  per_acre_rate?: number;
  latitude: number;
  longitude: number;
  address?: string;
  availability_status?: DbEquipmentAvailability;
}

export interface EquipmentFilterParams extends PaginationParams {
  search?: string;
  equipment_type?: DbEquipmentType;
  availability_status?: DbEquipmentAvailability;
}

export async function createEquipment(
  input: CreateEquipmentInput
): Promise<ServiceResponse<EquipmentRow>> {
  try {
    if (!input.equipment_name.trim() || input.work_rate_acres_per_hour <= 0) {
      throw new Error('Equipment name and positive work_rate_acres_per_hour are required.');
    }
    if (input.hourly_rate < 0 || (input.per_acre_rate ?? 0) < 0) {
      throw new Error('Rental rates cannot be negative.');
    }
    assertValidCoordinates(input.latitude, input.longitude);

    const db = getDatabaseClient();
    const { data: authData, error: authErr } = await db.auth.getUser();
    if (authErr || !authData.user) throw new Error('Authenticated equipment owner required.');

    const { data, error } = await db
      .from('equipment')
      .insert({
        owner_id: authData.user.id,
        equipment_name: input.equipment_name.trim(),
        equipment_type: input.equipment_type,
        brand: input.brand?.trim() ?? '',
        model: input.model?.trim() ?? '',
        description: input.description?.trim() ?? '',
        work_rate_acres_per_hour: input.work_rate_acres_per_hour,
        hourly_rate: input.hourly_rate,
        per_acre_rate: input.per_acre_rate ?? 0,
        latitude: input.latitude,
        longitude: input.longitude,
        address: input.address?.trim() ?? '',
        availability_status: input.availability_status ?? 'available',
      })
      .select('*')
      .single();

    if (error) throw new Error(error.message);
    return ok(data as EquipmentRow);
  } catch (err) {
    return fail(err);
  }
}

export async function getEquipment(
  filters?: EquipmentFilterParams
): Promise<ServiceResponse<EquipmentRow[]>> {
  try {
    const db = getDatabaseClient();
    const { page, pageSize, from, to } = normalizePagination(filters);

    let query = db
      .from('equipment')
      .select('*', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(from, to);

    if (filters?.equipment_type) {
      query = query.eq('equipment_type', filters.equipment_type);
    }
    if (filters?.availability_status) {
      query = query.eq('availability_status', filters.availability_status);
    }
    if (filters?.search?.trim()) {
      const term = filters.search.trim();
      query = query.or(
        `equipment_name.ilike.%${term}%,brand.ilike.%${term}%,model.ilike.%${term}%,address.ilike.%${term}%`
      );
    }

    const { data, error, count } = await query;
    if (error) throw new Error(error.message);

    return ok((data ?? []) as EquipmentRow[], {
      page,
      pageSize,
      total: count ?? 0,
    });
  } catch (err) {
    return fail(err);
  }
}

export async function getOwnerEquipment(
  ownerId?: string,
  pagination?: PaginationParams
): Promise<ServiceResponse<EquipmentRow[]>> {
  try {
    const db = getDatabaseClient();
    let targetOwnerId = ownerId;
    if (!targetOwnerId) {
      const { data: authData, error: authErr } = await db.auth.getUser();
      if (authErr || !authData.user) throw new Error('Authenticated user required.');
      targetOwnerId = authData.user.id;
    }

    const { page, pageSize, from, to } = normalizePagination(pagination);
    const { data, error, count } = await db
      .from('equipment')
      .select('*', { count: 'exact' })
      .eq('owner_id', targetOwnerId)
      .order('created_at', { ascending: false })
      .range(from, to);

    if (error) throw new Error(error.message);
    return ok((data ?? []) as EquipmentRow[], {
      page,
      pageSize,
      total: count ?? 0,
    });
  } catch (err) {
    return fail(err);
  }
}

export async function updateEquipment(
  equipmentId: string,
  patch: Partial<CreateEquipmentInput>
): Promise<ServiceResponse<EquipmentRow>> {
  try {
    if (patch.latitude !== undefined || patch.longitude !== undefined) {
      if (patch.latitude === undefined || patch.longitude === undefined) {
        throw new Error('Both latitude and longitude must be provided when updating coordinates.');
      }
      assertValidCoordinates(patch.latitude, patch.longitude);
    }

    const db = getDatabaseClient();
    const { data, error } = await db
      .from('equipment')
      .update(patch)
      .eq('id', equipmentId)
      .select('*')
      .single();

    if (error) throw new Error(error.message);
    return ok(data as EquipmentRow);
  } catch (err) {
    return fail(err);
  }
}

export async function deleteEquipment(
  equipmentId: string
): Promise<ServiceResponse<null>> {
  try {
    const db = getDatabaseClient();
    const { error } = await db.from('equipment').delete().eq('id', equipmentId);
    if (error) throw new Error(error.message);
    return ok(null);
  } catch (err) {
    return fail(err);
  }
}

export async function checkEquipmentAvailability(
  equipmentId: string,
  windowStartIso: string,
  windowEndIso: string
): Promise<ServiceResponse<{ isAvailable: boolean; conflictingSchedules: number }>> {
  try {
    if (windowEndIso <= windowStartIso) {
      throw new Error('windowEndIso must be after windowStartIso.');
    }
    const db = getDatabaseClient();

    const { data: eq, error: eqErr } = await db
      .from('equipment')
      .select('availability_status')
      .eq('id', equipmentId)
      .single();

    if (eqErr) throw new Error(eqErr.message);
    if (eq.availability_status === 'maintenance' || eq.availability_status === 'unavailable') {
      return ok({ isAvailable: false, conflictingSchedules: 0 });
    }

    const { count, error: schedErr } = await db
      .from('schedules')
      .select('id', { count: 'exact', head: true })
      .eq('equipment_id', equipmentId)
      .in('status', ['scheduled', 'in_progress'])
      .lt('scheduled_start', windowEndIso)
      .gt('scheduled_end', windowStartIso);

    if (schedErr) throw new Error(schedErr.message);
    const conflictingSchedules = count ?? 0;

    return ok({
      isAvailable: conflictingSchedules === 0,
      conflictingSchedules,
    });
  } catch (err) {
    return fail(err);
  }
}
