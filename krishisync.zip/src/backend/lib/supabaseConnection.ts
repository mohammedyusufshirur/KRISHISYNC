import type { SupabaseClient } from '@supabase/supabase-js';
import { requireSupabaseClient, supabase } from '../../lib/supabaseClient';

/**
 * Reusable database connection accessor for KRISHISYNC backend services.
 * Guarantees a single shared SupabaseClient instance and throws an explicit
 * error if `VITE_SUPABASE_URL` or `VITE_SUPABASE_ANON_KEY` are missing.
 */
export function getDatabaseClient(): SupabaseClient {
  return requireSupabaseClient();
}

export function getOptionalDatabaseClient(): SupabaseClient | null {
  return supabase;
}

export function assertValidCoordinates(latitude: number, longitude: number): void {
  if (
    Number.isNaN(latitude) ||
    Number.isNaN(longitude) ||
    latitude < -90 ||
    latitude > 90 ||
    longitude < -180 ||
    longitude > 180
  ) {
    throw new Error(
      'Invalid coordinates: latitude must be between -90 and 90 and longitude between -180 and 180.'
    );
  }
}
