import React from 'react';
import { ArrowRight, CalendarCheck2, ShieldAlert, Tractor, TrendingUp } from 'lucide-react';
import { Link } from 'react-router-dom';
import { DEMO_IMAGES } from '../data/mockData';

export const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-white text-[#0F172A]">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
          <Link
            to="/"
            className="text-lg font-bold tracking-tight text-[#0B3B24] whitespace-nowrap shrink-0"
          >
            KRISHISYNC
          </Link>

          <nav
            className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600"
            aria-label="Primary"
          >
            <a
              href="#benefits"
              className="hover:text-[#14532D] transition-colors whitespace-nowrap shrink-0"
            >
              Benefits
            </a>
            <a
              href="#how-it-works"
              className="hover:text-[#14532D] transition-colors whitespace-nowrap shrink-0"
            >
              How It Works
            </a>
            <a
              href="#features"
              className="hover:text-[#14532D] transition-colors whitespace-nowrap shrink-0"
            >
              Capabilities
            </a>
            <Link
              to="/app/scheduler"
              className="hover:text-[#14532D] transition-colors whitespace-nowrap shrink-0"
            >
              Live Demo
            </Link>
          </nav>

          <div className="flex items-center shrink-0">
            <Link
              to="/auth"
              className="px-4 py-2 text-xs sm:text-sm font-medium text-white bg-[#14532D] hover:bg-[#0B3B24] rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Sign In
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Split */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-12 lg:pt-16 lg:pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-center">
            <p className="text-xs font-medium text-emerald-700 tracking-wide">
              Cooperative Mechanization · Precision Dispatch · Deadline Protection
            </p>
            <h1
              className="mt-4 font-bold tracking-tight text-[#0F172A] leading-[1.08]"
              style={{
                fontSize: 'clamp(2.25rem, 4vw, 3.65rem)',
                textWrap: 'balance',
              }}
            >
              Smart Equipment. Smarter Farming.
            </h1>
            <p className="mt-5 text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl">
              KRISHISYNC connects smallholder plots with regional tractor, harvester, and spray
              drone fleets through deadline-aware scheduling, transit buffer planning, and rapid
              disruption recovery.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link
                to="/auth?mode=register&role=farmer"
                className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] rounded-lg transition-colors whitespace-nowrap"
              >
                <span>Register as Farmer</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/auth?mode=register&role=owner"
                className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-[#14532D] bg-white border border-slate-300 hover:border-[#14532D] hover:bg-emerald-50/40 rounded-lg transition-colors whitespace-nowrap"
              >
                <span>Register Equipment Fleet</span>
              </Link>
              <Link
                to="/app/farmer-dashboard"
                className="px-3 py-3 text-sm font-medium text-slate-600 hover:text-[#14532D] transition-colors whitespace-nowrap"
              >
                Explore Workspace
              </Link>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="h-full min-h-[300px] lg:min-h-[400px] rounded-xl border border-slate-200 overflow-hidden bg-emerald-950 relative">
              <img
                src={DEMO_IMAGES.heroTractor}
                alt="Precision agricultural tractor operating across terraced farmland at sunrise"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-6 text-white">
                <p className="text-xs font-mono uppercase tracking-wider text-emerald-300">
                  Baramati &amp; Indapur Cluster
                </p>
                <p className="mt-1 text-sm sm:text-base font-medium">
                  Coordinated sowing, spraying, and harvesting windows across 1,420+ mapped acres.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width 4-Column Proof Strip directly below hero split */}
        <div className="mt-10 grid grid-cols-2 lg:grid-cols-4 border border-slate-200 rounded-xl bg-[#F8FAFC] divide-y sm:divide-y-0 sm:divide-x divide-slate-200">
          <div className="p-5">
            <p className="text-2xl font-bold font-mono tabular-nums text-[#14532D]">34%</p>
            <p className="mt-1 text-xs text-slate-600">
              Reduction in idle machine transit across cluster hubs
            </p>
          </div>
          <div className="p-5">
            <p className="text-2xl font-bold font-mono tabular-nums text-[#14532D]">96.4%</p>
            <p className="mt-1 text-xs text-slate-600">
              Critical crop window deadlines met on schedule
            </p>
          </div>
          <div className="p-5">
            <p className="text-2xl font-bold font-mono tabular-nums text-[#14532D]">18 min</p>
            <p className="mt-1 text-xs text-slate-600">
              Average emergency breakdown reassignment turnaround
            </p>
          </div>
          <div className="p-5">
            <p className="text-2xl font-bold font-mono tabular-nums text-[#14532D]">2.6x</p>
            <p className="mt-1 text-xs text-slate-600">
              Seasonal fleet utilization gain for equipment owners
            </p>
          </div>
        </div>
      </section>

      {/* Platform Benefits - Asymmetric Bento */}
      <section id="benefits" className="border-t border-slate-200 bg-[#F8FAFC] py-16">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-emerald-700">Platform Benefits</p>
            <h2
              className="mt-2 text-2xl sm:text-3xl font-bold tracking-tight text-slate-900"
              style={{ textWrap: 'balance' }}
            >
              Built for time-sensitive field windows and high-utilization fleets
            </h2>
          </div>

          <div className="mt-10 grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 rounded-xl border border-slate-200 bg-white overflow-hidden grid grid-cols-1 md:grid-cols-2">
              <div className="p-7 flex flex-col justify-between">
                <div>
                  <Tractor className="w-5 h-5 text-[#14532D]" />
                  <h3 className="mt-4 text-lg font-semibold text-slate-900">
                    Deadline-Driven Equipment Allocation
                  </h3>
                  <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                    Harvesting and spraying cannot wait for manual phone tag. Farmers submit plot
                    acreage, crop stage, and hard deadlines so fleets dispatch in the exact order
                    of agronomic urgency.
                  </p>
                </div>
                <p className="mt-6 text-xs font-mono text-slate-500">
                  Plot Coordinates · Capacity Math · Priority Weighting
                </p>
              </div>
              <div className="min-h-[220px] bg-emerald-950">
                <img
                  src={DEMO_IMAGES.harvester}
                  alt="Combine harvester harvesting ripe grain crop"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-7 flex flex-col justify-between">
              <div>
                <TrendingUp className="w-5 h-5 text-[#14532D]" />
                <h3 className="mt-4 text-lg font-semibold text-slate-900">
                  Zero Deadhead Routing
                </h3>
                <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                  Travel buffers between hubs and neighbouring plots are accounted for directly on
                  the machine timeline, cutting wasted diesel and preventing overlapping arrivals.
                </p>
              </div>
              <div className="mt-6 pt-5 border-t border-slate-100 flex items-baseline justify-between">
                <span className="text-xs text-slate-500">Avg. buffer accuracy</span>
                <span className="text-lg font-bold font-mono tabular-nums text-[#14532D]">
                  ±10 min
                </span>
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-7 flex flex-col justify-between">
              <div>
                <ShieldAlert className="w-5 h-5 text-[#14532D]" />
                <h3 className="mt-4 text-lg font-semibold text-slate-900">
                  Instant Breakdown &amp; Weather Recovery
                </h3>
                <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                  When a harvester stalls or unseasonal rain hits a sector, operators see every
                  impacted booking immediately alongside nearby compatible backup machines.
                </p>
              </div>
              <div className="mt-6 pt-5 border-t border-slate-100 flex items-baseline justify-between">
                <span className="text-xs text-slate-500">Affected plot visibility</span>
                <span className="text-lg font-bold font-mono tabular-nums text-[#14532D]">
                  100%
                </span>
              </div>
            </div>

            <div className="lg:col-span-2 rounded-xl border border-slate-200 bg-white overflow-hidden grid grid-cols-1 md:grid-cols-2">
              <div className="min-h-[220px] bg-emerald-950 order-2 md:order-1">
                <img
                  src={DEMO_IMAGES.drone}
                  alt="Precision agricultural spraying drone over emerald paddy rows"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-7 flex flex-col justify-between order-1 md:order-2">
                <div>
                  <CalendarCheck2 className="w-5 h-5 text-[#14532D]" />
                  <h3 className="mt-4 text-lg font-semibold text-slate-900">
                    Transparent Cost &amp; Field Capacity Estimates
                  </h3>
                  <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                    Every booking calculates estimated field hours and total INR cost upfront from
                    the machine&apos;s verified acres-per-hour capacity and plot size.
                  </p>
                </div>
                <p className="mt-6 text-xs font-mono text-slate-500">
                  Hourly &amp; Daily Rates · Instant Cost Preview
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-16 bg-white border-t border-slate-200">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-emerald-700">Operational Workflow</p>
            <h2
              className="mt-2 text-2xl sm:text-3xl font-bold tracking-tight text-slate-900"
              style={{ textWrap: 'balance' }}
            >
              How KRISHISYNC coordinates every field operation
            </h2>
          </div>

          <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                step: '01. Map Plots & Deadlines',
                body: 'Farmers register plot boundaries, crop types, GPS coordinates, and critical operational deadlines.',
              },
              {
                step: '02. Publish Verified Fleet',
                body: 'Equipment owners list tractors, combines, rotavators, and spray drones with capacities and rates.',
              },
              {
                step: '03. Sync Smart Schedule',
                body: 'Bookings flow into the scheduling engine with priority labels, transit buffers, and conflict checks.',
              },
              {
                step: '04. Recover From Disruptions',
                body: 'Report breakdowns or weather events to surface alternative rigs and push revised timelines.',
              },
            ].map((item) => (
              <div
                key={item.step}
                className="rounded-xl border border-slate-200 bg-[#F8FAFC] p-6"
              >
                <h3 className="text-base font-semibold text-slate-900">{item.step}</h3>
                <p className="mt-2.5 text-sm text-slate-600 leading-relaxed">{item.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Capabilities & Role Conversion */}
      <section id="features" className="py-16 bg-[#F8FAFC] border-t border-slate-200">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          <div className="lg:col-span-5 rounded-xl border border-slate-200 bg-white overflow-hidden">
            <img
              src={DEMO_IMAGES.rotavator}
              alt="Tractor with rotavator and laser leveler preparing agricultural field"
              referrerPolicy="no-referrer"
              className="w-full h-full min-h-[260px] object-cover"
            />
          </div>

          <div className="lg:col-span-7 rounded-xl border border-slate-200 bg-[#0B3B24] text-white p-8 sm:p-10 flex flex-col justify-between">
            <div>
              <p className="text-xs font-medium text-emerald-300">Ready for Cluster Deployment</p>
              <h2
                className="mt-3 text-2xl sm:text-3xl font-bold tracking-tight"
                style={{ textWrap: 'balance' }}
              >
                Start managing plots, machinery, and conflict-free schedules today.
              </h2>
              <p className="mt-3 text-sm sm:text-base text-emerald-100/90 max-w-xl leading-relaxed">
                Switch effortlessly between Farmer and Equipment Owner perspectives, register real
                field assets, and test live disruption mitigation.
              </p>
            </div>

            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/auth?mode=register&role=farmer"
                className="px-5 py-2.5 text-sm font-semibold text-[#0B3B24] bg-white hover:bg-emerald-50 rounded-lg transition-colors whitespace-nowrap"
              >
                Create Farmer Account
              </Link>
              <Link
                to="/auth?mode=register&role=owner"
                className="px-5 py-2.5 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors whitespace-nowrap"
              >
                Create Owner Account
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-200 bg-white py-10">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            <span className="font-semibold text-slate-900">KRISHISYNC</span>
            <span className="mx-2" aria-hidden="true">·</span>
            <span>Agricultural Equipment Sharing &amp; Intelligent Scheduling</span>
          </div>
          <div className="flex items-center gap-6">
            <Link to="/auth" className="hover:text-slate-900 transition-colors">
              Sign In
            </Link>
            <Link to="/app/equipment" className="hover:text-slate-900 transition-colors">
              Equipment Registry
            </Link>
            <Link to="/app/scheduler" className="hover:text-slate-900 transition-colors">
              Smart Scheduler
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
};
