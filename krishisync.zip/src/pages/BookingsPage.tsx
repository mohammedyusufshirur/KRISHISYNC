import React, { useCallback, useEffect, useState } from 'react';
import { Plus } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import { Modal } from '../components/Modal';
import { EmptyState, ErrorBanner, LoadingSkeleton, SuccessBanner } from '../components/PageState';
import { StatusIndicator, mapStatusToTone } from '../components/StatusIndicator';
import { useAuth } from '../context/AuthContext';
import { bookingService } from '../services/bookingService';
import { equipmentService } from '../services/equipmentService';
import { notificationService } from '../services/notificationService';
import { plotService } from '../services/plotService';
import {
  Booking,
  BookingInput,
  BookingPriority,
  BookingStatus,
  Equipment,
  OperationType,
  Plot,
} from '../types/domain';

const STATUS_TABS: Array<'All' | BookingStatus> = [
  'All',
  'Pending',
  'Confirmed',
  'Scheduled',
  'In Progress',
  'Completed',
  'Cancelled',
  'Disrupted',
];

const OPERATIONS: OperationType[] = [
  'Plowing',
  'Sowing',
  'Harvesting',
  'Spraying',
  'Soil Leveling',
  'Rotavation',
];

export const BookingsPage: React.FC = () => {
  const { user, isDemoMode, refreshUnreadCount } = useAuth();
  const isFarmer = (user?.role ?? 'farmer') === 'farmer';
  const isOwner = user?.role === 'owner';
  const [searchParams] = useSearchParams();
  const preselectedEquipmentId = searchParams.get('equipmentId') ?? '';

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [plots, setPlots] = useState<Plot[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<'All' | BookingStatus>('All');

  const [modalOpen, setModalOpen] = useState(Boolean(preselectedEquipmentId) && isFarmer);
  const [form, setForm] = useState<BookingInput>({
    equipmentId: preselectedEquipmentId,
    plotId: '',
    operationType: 'Sowing',
    requestedDate: '2026-11-19',
    deadline: '2026-11-21',
    priority: 'High',
    notes: '',
  });
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [bks, eqs, pls] = await Promise.all([
        bookingService.list(),
        equipmentService.list(),
        plotService.list(),
      ]);
      setBookings(bks);
      setEquipment(eqs);
      setPlots(pls);
      setForm((prev) => ({
        ...prev,
        equipmentId: prev.equipmentId || eqs.find((e) => e.status === 'Available')?.id || eqs[0]?.id || '',
        plotId: prev.plotId || pls[0]?.id || '',
      }));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load bookings.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const selectedEquipment = equipment.find((e) => e.id === form.equipmentId);
  const selectedPlot = plots.find((p) => p.id === form.plotId);
  const previewHours =
    selectedEquipment && selectedPlot
      ? Math.max(
          1,
          Math.ceil(
            selectedPlot.areaAcres / Math.max(0.5, selectedEquipment.workCapacityAcresPerHr)
          )
        )
      : 0;
  const previewCost = selectedEquipment ? previewHours * selectedEquipment.hourlyRateInr : 0;

  const handleCreateBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!form.equipmentId || !form.plotId) {
      setFormError('Select both an agricultural machine and a target plot.');
      return;
    }
    if (!form.requestedDate || !form.deadline) {
      setFormError('Provide both a requested operation date and a deadline.');
      return;
    }
    if (form.deadline < form.requestedDate) {
      setFormError('Operational deadline cannot precede the requested date.');
      return;
    }

    setSubmitting(true);
    try {
      const created = await bookingService.create(
        form,
        user?.id ?? 'usr-farmer-01',
        user?.name ?? 'Rajesh Deshmukh'
      );
      notificationService.pushNotification({
        category: 'Booking Update',
        severity: 'info',
        title: `New Booking Submitted (${created.id})`,
        message: `${created.equipmentName} requested for ${created.plotName} on ${created.requestedDate}.`,
        actionRoute: '/app/bookings',
        actionLabel: 'View Booking',
        relatedId: created.id,
      });
      await refreshUnreadCount();
      setModalOpen(false);
      await loadData();
      setActionSuccess(`Booking ${created.id} submitted successfully.`);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to create booking.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleStatusChange = async (id: string, nextStatus: BookingStatus) => {
    setBusyId(id);
    setActionError(null);
    setActionSuccess(null);
    try {
      await bookingService.updateStatus(id, nextStatus);
      notificationService.pushNotification({
        category: 'Booking Update',
        severity: nextStatus === 'Cancelled' ? 'warning' : 'info',
        title: `Booking ${id} Updated`,
        message: `Booking status transitioned to ${nextStatus}.`,
        actionRoute: '/app/bookings',
        actionLabel: 'Review Bookings',
        relatedId: id,
      });
      await refreshUnreadCount();
      await loadData();
      setActionSuccess(`Booking ${id} updated to ${nextStatus}.`);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : `Failed to update booking ${id}.`);
    } finally {
      setBusyId(null);
    }
  };

  if (loading) return <LoadingSkeleton />;
  if (error) return <ErrorBanner message={error} onRetry={loadData} />;

  const filtered = bookings.filter((b) =>
    statusFilter === 'All' ? true : b.status === statusFilter
  );

  return (
    <div className="space-y-6">
      {actionSuccess && (
        <SuccessBanner message={actionSuccess} onDismiss={() => setActionSuccess(null)} />
      )}
      {actionError && <ErrorBanner message={actionError} />}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            Booking Management
          </h2>
          <p className="text-sm text-slate-600">
            Request machinery for registered plots, estimate field hours, and track dispatch status.
          </p>
        </div>
        {isFarmer && (
          <button
            type="button"
            onClick={() => {
              setFormError(null);
              setModalOpen(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] rounded-lg transition-colors whitespace-nowrap self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Create Booking</span>
          </button>
        )}
      </div>

      {/* Status Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto">
        {STATUS_TABS.map((status) => (
          <button
            key={status}
            type="button"
            onClick={() => setStatusFilter(status)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              statusFilter === status
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {status}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          title="No bookings in this status"
          description="Select another status filter or submit a new equipment booking request."
          actionLabel={isFarmer ? 'Create Booking' : undefined}
          onAction={isFarmer ? () => setModalOpen(true) : undefined}
        />
      ) : (
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-4">ID &amp; Equipment</th>
                  <th className="py-3 px-4">Plot &amp; Operation</th>
                  <th className="py-3 px-4">Requested / Deadline</th>
                  <th className="py-3 px-4 text-right">Est. Cost</th>
                  <th className="py-3 px-4">Priority</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Workflow Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filtered.map((bk) => {
                  const canActAsOwner = isOwner && (isDemoMode || bk.ownerId === user?.id);
                  const canActAsFarmer = isFarmer && (isDemoMode || bk.farmerId === user?.id);
                  return (
                    <tr key={bk.id} className="hover:bg-slate-50/70">
                      <td className="py-3.5 px-4">
                        <p className="font-mono text-xs text-slate-500">{bk.id}</p>
                        <p className="font-semibold text-slate-900">{bk.equipmentName}</p>
                        <p className="text-xs text-slate-500">{bk.ownerName}</p>
                      </td>
                      <td className="py-3.5 px-4">
                        <p className="font-medium text-slate-900">{bk.plotName}</p>
                        <p className="text-xs text-slate-500">
                          {bk.operationType} · {bk.plotAreaAcres} ac · {bk.travelDistanceKm} km
                        </p>
                      </td>
                      <td className="py-3.5 px-4 font-mono text-xs tabular-nums whitespace-nowrap">
                        <p className="text-slate-900">Req: {bk.requestedDate}</p>
                        <p className="text-slate-500">Due: {bk.deadline}</p>
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono tabular-nums">
                        <p className="font-semibold text-slate-900">
                          ₹{bk.estimatedCostInr.toLocaleString('en-IN')}
                        </p>
                        <p className="text-xs text-slate-500">{bk.estimatedHours} hrs</p>
                      </td>
                      <td className="py-3.5 px-4">
                        <StatusIndicator
                          label={bk.priority}
                          tone={mapStatusToTone(bk.priority)}
                        />
                      </td>
                      <td className="py-3.5 px-4">
                        <StatusIndicator
                          label={bk.status}
                          tone={mapStatusToTone(bk.status)}
                        />
                      </td>
                      <td className="py-3.5 px-4 text-right whitespace-nowrap space-x-1.5">
                        {canActAsOwner && bk.status === 'Pending' && (
                          <>
                            <button
                              type="button"
                              disabled={busyId === bk.id}
                              onClick={() => handleStatusChange(bk.id, 'Confirmed')}
                              className="px-2.5 py-1 text-xs font-medium text-white bg-[#14532D] hover:bg-[#0B3B24] disabled:opacity-50 rounded-md"
                            >
                              Confirm
                            </button>
                            <button
                              type="button"
                              disabled={busyId === bk.id}
                              onClick={() => handleStatusChange(bk.id, 'Cancelled')}
                              className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-red-700 hover:bg-red-50 disabled:opacity-50 rounded-md"
                            >
                              Decline
                            </button>
                          </>
                        )}
                        {canActAsOwner &&
                          (bk.status === 'Confirmed' || bk.status === 'Scheduled') && (
                            <button
                              type="button"
                              disabled={busyId === bk.id}
                              onClick={() => handleStatusChange(bk.id, 'In Progress')}
                              className="px-2.5 py-1 text-xs font-medium text-[#14532D] bg-emerald-50 hover:bg-emerald-100 disabled:opacity-50 rounded-md"
                            >
                              Start
                            </button>
                          )}
                        {canActAsOwner && bk.status === 'In Progress' && (
                          <button
                            type="button"
                            disabled={busyId === bk.id}
                            onClick={() => handleStatusChange(bk.id, 'Completed')}
                            className="px-2.5 py-1 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 rounded-md"
                          >
                            Complete
                          </button>
                        )}
                        {canActAsFarmer &&
                          bk.status !== 'Completed' &&
                          bk.status !== 'Cancelled' && (
                            <button
                              type="button"
                              disabled={busyId === bk.id}
                              onClick={() => handleStatusChange(bk.id, 'Cancelled')}
                              className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-red-700 hover:bg-red-50 disabled:opacity-50 rounded-md"
                            >
                              Cancel
                            </button>
                          )}
                        {!canActAsOwner && !canActAsFarmer && (
                          <span className="text-xs text-slate-400">Read only</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* New Booking Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="New Equipment Booking Request"
        subtitle="Select equipment and plot to compute field duration and estimated cost."
      >
        {formError && (
          <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
            {formError}
          </div>
        )}
        <form onSubmit={handleCreateBooking} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Select Equipment
            </label>
            <select
              value={form.equipmentId}
              onChange={(e) => setForm({ ...form, equipmentId: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
            >
              <option value="">Choose agricultural machine...</option>
              {equipment.map((eq) => (
                <option key={eq.id} value={eq.id}>
                  {eq.name} ({eq.category} · ₹{eq.hourlyRateInr}/hr · {eq.status})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Select Registered Plot
            </label>
            <select
              value={form.plotId}
              onChange={(e) => {
                const plot = plots.find((p) => p.id === e.target.value);
                setForm({
                  ...form,
                  plotId: e.target.value,
                  operationType: plot?.operationType ?? form.operationType,
                  deadline: plot?.deadline ?? form.deadline,
                });
              }}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
            >
              <option value="">Choose plot...</option>
              {plots.map((pl) => (
                <option key={pl.id} value={pl.id}>
                  {pl.name} ({pl.areaAcres} ac · {pl.cropType} · Due {pl.deadline})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Operation Type
              </label>
              <select
                value={form.operationType}
                onChange={(e) =>
                  setForm({ ...form, operationType: e.target.value as OperationType })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                {OPERATIONS.map((op) => (
                  <option key={op} value={op}>
                    {op}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Priority Level
              </label>
              <select
                value={form.priority}
                onChange={(e) =>
                  setForm({ ...form, priority: e.target.value as BookingPriority })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                <option value="Critical">Critical (Deadline Sensitive)</option>
                <option value="High">High</option>
                <option value="Standard">Standard</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Requested Date
              </label>
              <input
                type="date"
                value={form.requestedDate}
                onChange={(e) => setForm({ ...form, requestedDate: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Operational Deadline
              </label>
              <input
                type="date"
                value={form.deadline}
                onChange={(e) => setForm({ ...form, deadline: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
          </div>

          {selectedEquipment && selectedPlot && (
            <div className="rounded-lg border border-emerald-200 bg-emerald-50/50 p-3.5 grid grid-cols-3 gap-3 text-xs">
              <div>
                <p className="text-slate-500">Est. Duration</p>
                <p className="font-mono font-semibold text-slate-900 tabular-nums">
                  {previewHours} hours
                </p>
              </div>
              <div>
                <p className="text-slate-500">Hourly Rate</p>
                <p className="font-mono font-semibold text-slate-900 tabular-nums">
                  ₹{selectedEquipment.hourlyRateInr}/hr
                </p>
              </div>
              <div>
                <p className="text-slate-500">Estimated Total</p>
                <p className="font-mono font-bold text-[#14532D] tabular-nums">
                  ₹{previewCost.toLocaleString('en-IN')}
                </p>
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Dispatch Notes
            </label>
            <textarea
              rows={2}
              value={form.notes ?? ''}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              placeholder="Preferred arrival gate or attachment instructions..."
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] disabled:opacity-60 rounded-lg"
            >
              {submitting ? 'Submitting...' : 'Submit Booking'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
