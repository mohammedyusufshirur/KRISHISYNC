import React, { useCallback, useEffect, useState } from 'react';
import { Eye, Pencil, Plus, Search, Tractor, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Modal } from '../components/Modal';
import { EmptyState, ErrorBanner, LoadingSkeleton, SuccessBanner } from '../components/PageState';
import { StatusIndicator, mapStatusToTone } from '../components/StatusIndicator';
import { useAuth } from '../context/AuthContext';
import { DEMO_IMAGES } from '../data/mockData';
import { equipmentService } from '../services/equipmentService';
import {
  Equipment,
  EquipmentCategory,
  EquipmentInput,
  EquipmentStatus,
} from '../types/domain';

const CATEGORIES: Array<'All' | EquipmentCategory> = [
  'All',
  'Tractor',
  'Harvester',
  'Sprayer Drone',
  'Planter & Seeder',
  'Rotavator',
  'Laser Leveler',
];

const DEFAULT_FORM: EquipmentInput = {
  name: '',
  model: '',
  category: 'Tractor',
  workCapacityAcresPerHr: 2.0,
  hourlyRateInr: 900,
  dailyRateInr: 6500,
  location: '',
  coordinates: { lat: 18.1517, lng: 74.5772 },
  status: 'Available',
  horsepowerOrSpec: '',
  imageUrl: DEMO_IMAGES.heroTractor,
  nextAvailableDate: '2026-11-18',
};

function defaultImageForCategory(category: EquipmentCategory): string {
  switch (category) {
    case 'Harvester':
      return DEMO_IMAGES.harvester;
    case 'Sprayer Drone':
      return DEMO_IMAGES.drone;
    case 'Rotavator':
    case 'Laser Leveler':
      return DEMO_IMAGES.rotavator;
    default:
      return DEMO_IMAGES.heroTractor;
  }
}

export const EquipmentRegistryPage: React.FC = () => {
  const { user, isDemoMode } = useAuth();
  const navigate = useNavigate();
  const isOwner = user?.role === 'owner';
  const [items, setItems] = useState<Equipment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'All' | EquipmentCategory>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | EquipmentStatus>('All');

  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<EquipmentInput>(DEFAULT_FORM);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [viewingItem, setViewingItem] = useState<Equipment | null>(null);

  const loadEquipment = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const list = await equipmentService.list();
      setItems(list);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to fetch equipment registry.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadEquipment();
  }, [loadEquipment]);

  const openAddModal = () => {
    setEditingId(null);
    setForm(DEFAULT_FORM);
    setFormError(null);
    setModalOpen(true);
  };

  const openEditModal = (eq: Equipment) => {
    setEditingId(eq.id);
    setForm({
      name: eq.name,
      model: eq.model,
      category: eq.category,
      workCapacityAcresPerHr: eq.workCapacityAcresPerHr,
      hourlyRateInr: eq.hourlyRateInr,
      dailyRateInr: eq.dailyRateInr,
      location: eq.location,
      coordinates: eq.coordinates,
      status: eq.status,
      horsepowerOrSpec: eq.horsepowerOrSpec,
      imageUrl: eq.imageUrl,
      nextAvailableDate: eq.nextAvailableDate,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!form.name.trim() || !form.model.trim() || !form.location.trim()) {
      setFormError('Machine name, model, and hub location are required.');
      return;
    }
    if (form.workCapacityAcresPerHr <= 0 || form.hourlyRateInr <= 0 || form.dailyRateInr <= 0) {
      setFormError('Work capacity and rental rates must be greater than zero.');
      return;
    }

    setSaving(true);
    try {
      const payload: EquipmentInput = {
        ...form,
        imageUrl: defaultImageForCategory(form.category),
      };
      if (editingId) {
        await equipmentService.update(editingId, payload);
      } else {
        await equipmentService.create(
          payload,
          user?.id ?? 'usr-owner-01',
          user?.organizationName ?? 'Gill Agro Fleet Services'
        );
      }
      setModalOpen(false);
      await loadEquipment();
      setActionSuccess(
        editingId ? 'Equipment record updated.' : 'New equipment registered.'
      );
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to save equipment.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    setActionError(null);
    setActionSuccess(null);
    try {
      await equipmentService.remove(id);
      setItems((prev) => prev.filter((item) => item.id !== id));
      setActionSuccess('Equipment removed from registry.');
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to delete equipment.');
    } finally {
      setDeletingId(null);
    }
  };

  const filtered = items.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.location.toLowerCase().includes(search.toLowerCase()) ||
      item.ownerName.toLowerCase().includes(search.toLowerCase());
    const matchesCat = categoryFilter === 'All' || item.category === categoryFilter;
    const matchesStatus = statusFilter === 'All' || item.status === statusFilter;
    return matchesSearch && matchesCat && matchesStatus;
  });

  if (loading) return <LoadingSkeleton />;
  if (error) return <ErrorBanner message={error} onRetry={loadEquipment} />;

  return (
    <div className="space-y-6">
      {actionSuccess && (
        <SuccessBanner message={actionSuccess} onDismiss={() => setActionSuccess(null)} />
      )}
      {actionError && <ErrorBanner message={actionError} />}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            Agricultural Equipment Registry
          </h2>
          <p className="text-sm text-slate-600">
            Manage tractors, harvesters, drones, and precision implements across regional hubs.
          </p>
        </div>
        {isOwner && (
          <button
            type="button"
            onClick={openAddModal}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] rounded-lg transition-colors whitespace-nowrap self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Add Equipment</span>
          </button>
        )}
      </div>

      {/* Filters Toolbar */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
        <div className="flex flex-col md:flex-row gap-3 justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search machine, hub location, or fleet owner..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          <div className="flex items-center gap-2">
            <label htmlFor="eq-status-filter" className="text-xs font-medium text-slate-500">
              Availability:
            </label>
            <select
              id="eq-status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as 'All' | EquipmentStatus)}
              className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-medium text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
            >
              <option value="All">All Statuses</option>
              <option value="Available">Available</option>
              <option value="Booked">Booked</option>
              <option value="In Operation">In Operation</option>
              <option value="Maintenance">Maintenance</option>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                categoryFilter === cat
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Equipment List */}
      {filtered.length === 0 ? (
        <EmptyState
          title="No matching equipment found"
          description="Try clearing your category or search filters, or register a new agricultural machine."
          actionLabel={isOwner ? 'Add Equipment' : undefined}
          onAction={isOwner ? openAddModal : undefined}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filtered.map((eq) => (
            <article
              key={eq.id}
              className="rounded-xl border border-slate-200 bg-white overflow-hidden flex flex-col"
            >
              <div className="aspect-[4/3] bg-emerald-950 relative overflow-hidden">
                <img
                  src={eq.imageUrl}
                  alt={eq.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center -z-10 text-emerald-200">
                  <Tractor className="w-10 h-10" />
                </div>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                    <span>
                      {eq.category} · {eq.model}
                    </span>
                    <StatusIndicator label={eq.status} tone={mapStatusToTone(eq.status)} />
                  </div>
                  <h3 className="mt-2 text-base font-semibold text-slate-900">{eq.name}</h3>
                  <p className="mt-1 text-xs text-slate-600">{eq.horsepowerOrSpec}</p>
                  <p className="mt-2 text-xs text-slate-500">
                    {eq.location} · Owner: {eq.ownerName}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-100 space-y-3">
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div>
                      <p className="text-slate-500">Capacity</p>
                      <p className="font-mono font-semibold text-slate-900 tabular-nums">
                        {eq.workCapacityAcresPerHr} ac/hr
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-500">Hourly</p>
                      <p className="font-mono font-semibold text-slate-900 tabular-nums">
                        ₹{eq.hourlyRateInr}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-500">Daily</p>
                      <p className="font-mono font-semibold text-slate-900 tabular-nums">
                        ₹{eq.dailyRateInr.toLocaleString('en-IN')}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setViewingItem(eq)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Details</span>
                    </button>
                    {isOwner && (isDemoMode || eq.ownerId === user?.id) ? (
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => openEditModal(eq)}
                          aria-label={`Edit ${eq.name}`}
                          className="p-2 text-slate-600 hover:text-[#14532D] hover:bg-emerald-50 rounded-lg transition-colors"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          disabled={deletingId === eq.id}
                          onClick={() => handleDelete(eq.id)}
                          aria-label={`Delete ${eq.name}`}
                          className="p-2 text-slate-600 hover:text-red-700 hover:bg-red-50 disabled:opacity-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ) : !isOwner && eq.status === 'Available' ? (
                      <button
                        type="button"
                        onClick={() => navigate(`/app/bookings?equipmentId=${eq.id}`)}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] rounded-lg transition-colors whitespace-nowrap"
                      >
                        Book Now
                      </button>
                    ) : null}
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      {/* Add / Edit Equipment Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingId ? 'Edit Equipment Details' : 'Register New Equipment'}
        subtitle="Provide accurate work capacity and hourly rates for scheduling estimates."
      >
        {formError && (
          <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
            {formError}
          </div>
        )}
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Equipment Name
              </label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="e.g. John Deere 5310 Tractor"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Model</label>
              <input
                type="text"
                value={form.model}
                onChange={(e) => setForm({ ...form, model: e.target.value })}
                placeholder="e.g. 5310 Trem IV (55 HP)"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Category</label>
              <select
                value={form.category}
                onChange={(e) =>
                  setForm({ ...form, category: e.target.value as EquipmentCategory })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                {CATEGORIES.filter((c) => c !== 'All').map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Availability Status
              </label>
              <select
                value={form.status}
                onChange={(e) =>
                  setForm({ ...form, status: e.target.value as EquipmentStatus })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                <option value="Available">Available</option>
                <option value="Booked">Booked</option>
                <option value="In Operation">In Operation</option>
                <option value="Maintenance">Maintenance</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Capacity (acres/hr)
              </label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                value={form.workCapacityAcresPerHr}
                onChange={(e) =>
                  setForm({
                    ...form,
                    workCapacityAcresPerHr: parseFloat(e.target.value) || 0,
                  })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Hourly Rate (INR)
              </label>
              <input
                type="number"
                min="100"
                value={form.hourlyRateInr}
                onChange={(e) =>
                  setForm({ ...form, hourlyRateInr: parseInt(e.target.value, 10) || 0 })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Daily Rate (INR)
              </label>
              <input
                type="number"
                min="500"
                value={form.dailyRateInr}
                onChange={(e) =>
                  setForm({ ...form, dailyRateInr: parseInt(e.target.value, 10) || 0 })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Hub Location
              </label>
              <input
                type="text"
                value={form.location}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
                placeholder="e.g. Baramati Hub · Sector 4"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Next Available Date
              </label>
              <input
                type="date"
                value={form.nextAvailableDate}
                onChange={(e) =>
                  setForm({ ...form, nextAvailableDate: e.target.value })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Technical Specification
            </label>
            <input
              type="text"
              value={form.horsepowerOrSpec}
              onChange={(e) => setForm({ ...form, horsepowerOrSpec: e.target.value })}
              placeholder="e.g. 55 HP · 4WD Auto-Steer Ready"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] disabled:opacity-60 rounded-lg"
            >
              {saving ? 'Saving...' : editingId ? 'Save Changes' : 'Register Equipment'}
            </button>
          </div>
        </form>
      </Modal>

      {/* View Equipment Details Modal */}
      <Modal
        open={Boolean(viewingItem)}
        onClose={() => setViewingItem(null)}
        title={viewingItem?.name ?? 'Equipment Details'}
        subtitle={viewingItem ? `${viewingItem.category} · ${viewingItem.model}` : undefined}
      >
        {viewingItem && (
          <div className="space-y-4">
            <img
              src={viewingItem.imageUrl}
              alt={viewingItem.name}
              referrerPolicy="no-referrer"
              className="w-full h-52 object-cover rounded-lg border border-slate-200"
            />
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-xs text-slate-500">Owner / Fleet</p>
                <p className="font-medium text-slate-900">{viewingItem.ownerName}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Status</p>
                <StatusIndicator
                  label={viewingItem.status}
                  tone={mapStatusToTone(viewingItem.status)}
                />
              </div>
              <div>
                <p className="text-xs text-slate-500">Hub Location</p>
                <p className="font-medium text-slate-900">{viewingItem.location}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Coordinates</p>
                <p className="font-mono text-xs text-slate-800">
                  {viewingItem.coordinates.lat.toFixed(4)}, {viewingItem.coordinates.lng.toFixed(4)}
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Work Capacity</p>
                <p className="font-mono font-semibold text-slate-900">
                  {viewingItem.workCapacityAcresPerHr} acres/hour
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Last Serviced</p>
                <p className="font-mono text-slate-800">{viewingItem.lastServicedDate}</p>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
