import React, { useCallback, useEffect, useState } from 'react';
import { Bell, CheckCheck, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { EmptyState, ErrorBanner, LoadingSkeleton } from '../components/PageState';
import { StatusIndicator } from '../components/StatusIndicator';
import { useAuth } from '../context/AuthContext';
import { notificationService } from '../services/notificationService';
import { AppNotification, NotificationCategory } from '../types/domain';

const CATEGORIES: Array<'All' | NotificationCategory> = [
  'All',
  'Booking Update',
  'Urgent Deadline',
  'Rescheduling',
];

export const NotificationsPage: React.FC = () => {
  const { refreshUnreadCount } = useAuth();
  const [items, setItems] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<'All' | NotificationCategory>('All');

  const loadNotifications = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const list = await notificationService.list();
      setItems(list);
      await refreshUnreadCount();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load notifications.');
    } finally {
      setLoading(false);
    }
  }, [refreshUnreadCount]);

  useEffect(() => {
    void loadNotifications();
  }, [loadNotifications]);

  const [actionError, setActionError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [markingAll, setMarkingAll] = useState(false);

  const handleMarkRead = async (id: string) => {
    setBusyId(id);
    setActionError(null);
    try {
      const updated = await notificationService.markAsRead(id);
      setItems(updated);
      await refreshUnreadCount();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Unable to mark notification read.');
    } finally {
      setBusyId(null);
    }
  };

  const handleMarkAllRead = async () => {
    setMarkingAll(true);
    setActionError(null);
    try {
      const updated = await notificationService.markAllRead();
      setItems(updated);
      await refreshUnreadCount();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Unable to mark all notifications read.');
    } finally {
      setMarkingAll(false);
    }
  };

  const handleDismiss = async (id: string) => {
    setBusyId(id);
    setActionError(null);
    try {
      const updated = await notificationService.dismiss(id);
      setItems(updated);
      await refreshUnreadCount();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Unable to dismiss notification.');
    } finally {
      setBusyId(null);
    }
  };

  if (loading) return <LoadingSkeleton rows={4} />;
  if (error) return <ErrorBanner message={error} onRetry={loadNotifications} />;

  const filtered = items.filter((n) => (filter === 'All' ? true : n.category === filter));
  const unreadCount = items.filter((n) => !n.read).length;

  return (
    <div className="space-y-6">
      {actionError && <ErrorBanner message={actionError} />}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            Operations Notifications
          </h2>
          <p className="text-sm text-slate-600">
            Booking confirmations, urgent plot deadlines, and automated rescheduling alerts.
          </p>
        </div>
        {unreadCount > 0 && (
          <button
            type="button"
            disabled={markingAll}
            onClick={handleMarkAllRead}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#14532D] bg-white border border-slate-200 hover:bg-slate-50 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap self-start sm:self-auto"
          >
            <CheckCheck className="w-4 h-4" />
            <span>{markingAll ? 'Updating...' : `Mark All Read (${unreadCount})`}</span>
          </button>
        )}
      </div>

      {/* Category Filter */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setFilter(cat)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              filter === cat
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          title="No notifications in this category"
          description="You are caught up on all booking updates, deadlines, and rescheduling notices."
        />
      ) : (
        <div className="rounded-xl border border-slate-200 bg-white divide-y divide-slate-100">
          {filtered.map((notif) => {
            const tone =
              notif.severity === 'critical'
                ? 'danger'
                : notif.severity === 'warning'
                ? 'warning'
                : 'info';

            return (
              <div
                key={notif.id}
                className={`p-5 flex flex-col sm:flex-row sm:items-start justify-between gap-4 transition-colors ${
                  notif.read ? 'bg-white' : 'bg-emerald-50/30'
                }`}
              >
                <div className="flex items-start gap-3.5 min-w-0">
                  <div className="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center text-[#14532D] shrink-0 mt-0.5">
                    <Bell className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                      <StatusIndicator label={notif.category} tone={tone} />
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">
                        {notif.timestamp.slice(0, 16).replace('T', ' ')}
                      </span>
                      {!notif.read && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-[#14532D]">Unread</span>
                        </>
                      )}
                    </div>
                    <h3 className="mt-1 text-sm font-semibold text-slate-900">
                      {notif.title}
                    </h3>
                    <p className="mt-1 text-sm text-slate-600 leading-relaxed">
                      {notif.message}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 sm:ml-4">
                  <Link
                    to={notif.actionRoute}
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] rounded-lg transition-colors whitespace-nowrap"
                  >
                    {notif.actionLabel}
                  </Link>
                  {!notif.read && (
                    <button
                      type="button"
                      disabled={busyId === notif.id}
                      onClick={() => handleMarkRead(notif.id)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap"
                    >
                      Mark Read
                    </button>
                  )}
                  <button
                    type="button"
                    disabled={busyId === notif.id}
                    onClick={() => handleDismiss(notif.id)}
                    aria-label="Dismiss notification"
                    className="p-1.5 text-slate-400 hover:text-red-700 disabled:opacity-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
