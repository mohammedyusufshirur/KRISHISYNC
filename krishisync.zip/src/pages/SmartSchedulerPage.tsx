import React, { useCallback, useEffect, useState } from 'react';
import { AlertTriangle, Calendar, CheckCircle2, RefreshCw, Truck } from 'lucide-react';
import { MetricCard } from '../components/MetricCard';
import { ErrorBanner, LoadingSkeleton, SuccessBanner } from '../components/PageState';
import { StatusIndicator, mapStatusToTone } from '../components/StatusIndicator';
import { useAuth } from '../context/AuthContext';
import { API_CONFIG } from '../services/apiConfig';
import { notificationService } from '../services/notificationService';
import { schedulingService } from '../services/schedulingService';
import { ScheduleGenerationParams, ScheduleGenerationResponse } from '../types/domain';

const CALENDAR_DAYS = ['All', '2026-11-18', '2026-11-19', '2026-11-20'];
const TIMELINE_START_HOUR = 6;
const TIMELINE_TOTAL_HOURS = 13; // 06:00 to 19:00

function formatHour(hourDecimal: number): string {
  const h = Math.floor(hourDecimal);
  const m = Math.round((hourDecimal - h) * 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export const SmartSchedulerPage: React.FC = () => {
  const { refreshUnreadCount } = useAuth();
  const [schedule, setSchedule] = useState<ScheduleGenerationResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [selectedDay, setSelectedDay] = useState<string>('All');

  const [params, setParams] = useState<ScheduleGenerationParams>({
    startDate: '2026-11-18',
    horizonDays: 5,
    prioritizeDeadlines: true,
    includeTravelBuffers: true,
    bufferMinutesPer10Km: 25,
  });

  const loadSchedule = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await schedulingService.getCurrentSchedule();
      setSchedule(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to fetch schedule.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadSchedule();
  }, [loadSchedule]);

  const handleGenerateSchedule = async () => {
    setGenerating(true);
    setError(null);
    setSuccessMsg(null);
    try {
      const response = await schedulingService.requestScheduleGeneration(params);
      setSchedule(response);
      setSuccessMsg(
        response.sourceMode === 'external-api'
          ? 'Schedule synchronized from External Scheduling API.'
          : response.sourceMode === 'supabase-rpc'
          ? 'Schedule optimized and persisted to Supabase PostgreSQL.'
          : 'Schedule refreshed with priority & travel buffer rules.'
      );
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'External scheduling API request failed.'
      );
    } finally {
      setGenerating(false);
    }
  };

  const handleResolveConflict = async (conflictId: string) => {
    setGenerating(true);
    setError(null);
    setSuccessMsg(null);
    try {
      const updated = await schedulingService.resolveConflict(conflictId);
      setSchedule(updated);
      notificationService.pushNotification({
        category: 'Rescheduling',
        severity: 'info',
        title: 'Schedule Conflict Resolved',
        message: 'Combine dispatch window shifted to 10:00–16:00 to clear transit overlap.',
        actionRoute: '/app/scheduler',
        actionLabel: 'Inspect Timeline',
        relatedId: conflictId,
      });
      await refreshUnreadCount();
      setSuccessMsg(`Conflict ${conflictId} resolved and dispatch timeline updated.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to resolve conflict.');
    } finally {
      setGenerating(false);
    }
  };

  if (loading) return <LoadingSkeleton />;
  if (error && !schedule) return <ErrorBanner message={error} onRetry={loadSchedule} />;
  if (!schedule) return null;

  const visibleSlots = schedule.slots.filter((s) =>
    selectedDay === 'All' ? true : s.date === selectedDay
  );

  return (
    <div className="space-y-6">
      {/* Header & Integration Transparency Notice */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            Smart Scheduler &amp; Machine Allocation Timeline
          </h2>
          <p className="text-sm text-slate-600">
            Calendar slots, transit travel buffers, priority dispatch labels, and conflict resolution.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-slate-600">
            Source:{' '}
            {schedule.sourceMode === 'external-api'
              ? 'External Scheduling API'
              : schedule.sourceMode === 'supabase-rpc'
              ? 'Supabase Scheduling Engine (Live)'
              : API_CONFIG.isSchedulerApiConfigured && API_CONFIG.hasVerifiedSchedulerContract
              ? 'External Scheduling API'
              : 'Demo Scheduling Adapter'}
          </span>
          <button
            type="button"
            onClick={handleGenerateSchedule}
            disabled={generating}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${generating ? 'animate-spin' : ''}`} />
            <span>{generating ? 'Syncing Schedule...' : 'Generate Schedule'}</span>
          </button>
        </div>
      </div>

      {successMsg && (
        <SuccessBanner message={successMsg} onDismiss={() => setSuccessMsg(null)} />
      )}
      {error && <ErrorBanner message={error} onRetry={handleGenerateSchedule} />}

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          label="Allocated Machine Hours"
          value={`${schedule.summary.totalAllocatedHours} hrs`}
          context="Across active cluster horizon"
        />
        <MetricCard
          label="Total Travel Buffers"
          value={`${schedule.summary.totalTravelBufferMinutes} min`}
          context="Inter-plot transit allowances"
        />
        <MetricCard
          label="Deadline Compliance"
          value={`${schedule.summary.onTimeDeadlineRatePercent}%`}
          context="Projected on-time field completion"
          accent
        />
        <MetricCard
          label="Conflict Warnings"
          value={schedule.summary.unresolvedConflicts}
          context="Requiring dispatch shift or reassignment"
        />
      </div>

      {/* Schedule Parameters & Calendar Filter */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 flex-1">
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">
              Horizon Start Date
            </label>
            <input
              type="date"
              value={params.startDate}
              onChange={(e) => setParams({ ...params, startDate: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-mono"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">
              Buffer per 10 km (min)
            </label>
            <input
              type="number"
              min="5"
              max="90"
              value={params.bufferMinutesPer10Km}
              onChange={(e) =>
                setParams({
                  ...params,
                  bufferMinutesPer10Km: parseInt(e.target.value, 10) || 20,
                })
              }
              className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-mono"
            />
          </div>
          <div className="flex items-center gap-4 pt-4">
            <label className="inline-flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={params.prioritizeDeadlines}
                onChange={(e) =>
                  setParams({ ...params, prioritizeDeadlines: e.target.checked })
                }
                className="rounded border-slate-300 text-[#14532D] focus:ring-emerald-600"
              />
              <span>Priority Deadlines</span>
            </label>
            <label className="inline-flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={params.includeTravelBuffers}
                onChange={(e) =>
                  setParams({ ...params, includeTravelBuffers: e.target.checked })
                }
                className="rounded border-slate-300 text-[#14532D] focus:ring-emerald-600"
              />
              <span>Transit Buffers</span>
            </label>
          </div>
        </div>

        {/* Calendar Day Filter */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start lg:self-auto">
          {CALENDAR_DAYS.map((day) => (
            <button
              key={day}
              type="button"
              onClick={() => setSelectedDay(day)}
              className={`px-3 py-1.5 text-xs font-mono font-medium rounded-md transition-colors whitespace-nowrap ${
                selectedDay === day
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {day === 'All' ? 'All Dates' : day.slice(5)}
            </button>
          ))}
        </div>
      </div>

      {/* Conflict Warnings Panel */}
      {schedule.conflicts.length > 0 && (
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <h3 className="text-base font-semibold text-slate-900">
                Schedule Conflict Warnings
              </h3>
            </div>
            <span className="text-xs font-mono text-slate-500">
              {schedule.summary.unresolvedConflicts} unresolved
            </span>
          </div>
          <div className="divide-y divide-slate-100">
            {schedule.conflicts.map((conf) => (
              <div
                key={conf.id}
                className="px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="font-semibold text-slate-900">{conf.equipmentName}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">{conf.date}</span>
                    <span aria-hidden="true">·</span>
                    <StatusIndicator
                      label={conf.resolved ? 'Resolved' : `${conf.severity} Conflict`}
                      tone={conf.resolved ? 'success' : 'danger'}
                    />
                  </div>
                  <p className="mt-1 text-sm text-slate-800">{conf.summary}</p>
                  <p className="mt-0.5 text-xs text-slate-600">
                    Recommended: {conf.recommendedAction}
                  </p>
                </div>

                {!conf.resolved ? (
                  <button
                    type="button"
                    onClick={() => handleResolveConflict(conf.id)}
                    disabled={generating}
                    className="px-3.5 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] rounded-lg transition-colors whitespace-nowrap shrink-0"
                  >
                    Apply Shift &amp; Resolve
                  </button>
                ) : (
                  <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 shrink-0">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Shifted to 10:00</span>
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Machine Allocation Timeline (Gantt) */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 overflow-x-auto">
        <div className="flex items-center justify-between mb-4 min-w-[720px]">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#14532D]" />
            <h3 className="text-base font-semibold text-slate-900">
              Machine Allocation Timeline (06:00 – 19:00)
            </h3>
          </div>
          <div className="flex items-center gap-4 text-xs text-slate-600">
            <span className="inline-flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-amber-300 inline-block" />
              Travel Buffer
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-[#14532D] inline-block" />
              Allocated Operation
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-red-600 inline-block" />
              Conflict Window
            </span>
          </div>
        </div>

        <div className="min-w-[760px] space-y-3">
          {/* Hour Axis */}
          <div className="grid grid-cols-12 gap-4 pb-2 border-b border-slate-200 text-xs font-mono text-slate-400">
            <div className="col-span-4">Machine &amp; Plot</div>
            <div className="col-span-8 flex justify-between">
              {['06:00', '08:00', '10:00', '12:00', '14:00', '16:00', '18:00'].map((hr) => (
                <span key={hr}>{hr}</span>
              ))}
            </div>
          </div>

          {visibleSlots.map((slot) => {
            const bufferHours = slot.travelBufferMinutes / 60;
            const bufferStart = Math.max(TIMELINE_START_HOUR, slot.startHour - bufferHours);
            const bufferLeftPct =
              ((bufferStart - TIMELINE_START_HOUR) / TIMELINE_TOTAL_HOURS) * 100;
            const bufferWidthPct = (bufferHours / TIMELINE_TOTAL_HOURS) * 100;

            const workLeftPct =
              ((slot.startHour - TIMELINE_START_HOUR) / TIMELINE_TOTAL_HOURS) * 100;
            const workWidthPct = (slot.durationHours / TIMELINE_TOTAL_HOURS) * 100;

            const barColor =
              slot.status === 'Conflict'
                ? 'bg-red-600 text-white'
                : slot.status === 'Revised'
                ? 'bg-emerald-600 text-white'
                : 'bg-[#14532D] text-white';

            return (
              <div
                key={slot.id}
                className="grid grid-cols-12 gap-4 items-center py-2.5 border-b border-slate-100 last:border-b-0"
              >
                <div className="col-span-4 pr-2">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-semibold text-slate-900 truncate">
                      {slot.equipmentName}
                    </p>
                    <StatusIndicator
                      label={slot.priority}
                      tone={mapStatusToTone(slot.priority)}
                    />
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5 truncate">
                    {slot.plotName} · {slot.operationType} ·{' '}
                    <span className="font-mono">{slot.date}</span>
                  </p>
                  <p className="text-xs text-slate-400 inline-flex items-center gap-1 mt-0.5">
                    <Truck className="w-3 h-3" />
                    <span>
                      {slot.travelOriginLabel} · {slot.travelBufferMinutes}m buffer
                    </span>
                  </p>
                </div>

                <div className="col-span-8 relative h-10 rounded-lg bg-slate-50 border border-slate-200 overflow-hidden">
                  {/* Travel Buffer Block */}
                  {params.includeTravelBuffers && (
                    <div
                      style={{
                        left: `${Math.max(0, bufferLeftPct)}%`,
                        width: `${Math.max(2, bufferWidthPct)}%`,
                      }}
                      title={`Travel Buffer: ${slot.travelBufferMinutes} min`}
                      className="absolute top-1.5 bottom-1.5 bg-amber-300/90 rounded-l-md"
                    />
                  )}
                  {/* Operation Allocation Block */}
                  <div
                    style={{
                      left: `${Math.max(0, workLeftPct)}%`,
                      width: `${Math.min(100 - workLeftPct, workWidthPct)}%`,
                    }}
                    className={`absolute top-1.5 bottom-1.5 rounded-md px-2.5 flex items-center justify-between text-xs font-mono font-medium overflow-hidden ${barColor}`}
                  >
                    <span className="truncate">
                      {formatHour(slot.startHour)}–{formatHour(slot.startHour + slot.durationHours)}
                    </span>
                    <span className="ml-2 text-[11px] opacity-90 shrink-0">
                      {slot.status}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
