import React, { useCallback, useEffect, useState } from 'react';
import { MapPin, Pencil, Plus, Trash2 } from 'lucide-react';
import { Modal } from '../components/Modal';
import { EmptyState, ErrorBanner, LoadingSkeleton, SuccessBanner } from '../components/PageState';
import { StatusIndicator } from '../components/StatusIndicator';
import { useAuth } from '../context/AuthContext';
import { plotService } from '../services/plotService';
import { CropType, OperationType, Plot, PlotInput } from '../types/domain';

const CROPS: CropType[] = ['Wheat', 'Paddy Rice', 'Sugarcane', 'Soybean', 'Cotton', 'Maize'];
const OPERATIONS: OperationType[] = [
  'Plowing',
  'Sowing',
  'Harvesting',
  'Spraying',
  'Soil Leveling',
  'Rotavation',
];

const DEFAULT_PLOT: PlotInput = {
  name: '',
  areaAcres: 10,
  cropType: 'Wheat',
  locationLabel: '',
  coordinates: { lat: 18.145, lng: 74.555 },
  operationType: 'Sowing',
  deadline: '2026-11-22',
  soilMoisturePercent: 25,
  notes: '',
};

export const PlotRegistryPage: React.FC = () => {
  const { user, isDemoMode } = useAuth();
  const isFarmer = (user?.role ?? 'farmer') === 'farmer';
  const [plots, setPlots] = useState<Plot[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<PlotInput>(DEFAULT_PLOT);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [selectedPlotId, setSelectedPlotId] = useState<string | null>(null);

  const loadPlots = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const list = await plotService.list();
      setPlots(list);
      if (list.length > 0 && !selectedPlotId) {
        setSelectedPlotId(list[0].id);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load plot registry.');
    } finally {
      setLoading(false);
    }
  }, [selectedPlotId]);

  useEffect(() => {
    void loadPlots();
  }, [loadPlots]);

  const openAdd = () => {
    setEditingId(null);
    setForm(DEFAULT_PLOT);
    setFormError(null);
    setModalOpen(true);
  };

  const openEdit = (plot: Plot) => {
    setEditingId(plot.id);
    setForm({
      name: plot.name,
      areaAcres: plot.areaAcres,
      cropType: plot.cropType,
      locationLabel: plot.locationLabel,
      coordinates: plot.coordinates,
      operationType: plot.operationType,
      deadline: plot.deadline,
      soilMoisturePercent: plot.soilMoisturePercent,
      notes: plot.notes,
    });
    setFormError(null);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!form.name.trim() || !form.locationLabel.trim()) {
      setFormError('Plot name and village/sector location are required.');
      return;
    }
    if (form.areaAcres <= 0) {
      setFormError('Plot area must be greater than 0 acres.');
      return;
    }
    if (
      Number.isNaN(form.coordinates.lat) ||
      Number.isNaN(form.coordinates.lng) ||
      form.coordinates.lat < -90 ||
      form.coordinates.lat > 90
    ) {
      setFormError('Enter valid GPS latitude and longitude coordinates.');
      return;
    }

    setSaving(true);
    try {
      if (editingId) {
        await plotService.update(editingId, form);
      } else {
        await plotService.create(
          form,
          user?.id ?? 'usr-farmer-01',
          user?.name ?? 'Rajesh Deshmukh'
        );
      }
      setModalOpen(false);
      await loadPlots();
      setActionSuccess(editingId ? 'Plot details updated.' : 'New plot registered.');
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to save plot.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    setActionError(null);
    setActionSuccess(null);
    try {
      await plotService.remove(id);
      setPlots((prev) => prev.filter((p) => p.id !== id));
      setActionSuccess('Plot removed from registry.');
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to delete plot.');
    } finally {
      setDeletingId(null);
    }
  };

  if (loading) return <LoadingSkeleton />;
  if (error) return <ErrorBanner message={error} onRetry={loadPlots} />;

  // Compute bounding box for clean interactive SVG coordinate map
  const lats = plots.map((p) => p.coordinates.lat);
  const lngs = plots.map((p) => p.coordinates.lng);
  const minLat = Math.min(...lats, 17.95);
  const maxLat = Math.max(...lats, 18.22);
  const minLng = Math.min(...lngs, 74.4);
  const maxLng = Math.max(...lngs, 74.7);

  const projectPoint = (lat: number, lng: number) => {
    const x = ((lng - minLng) / Math.max(0.01, maxLng - minLng)) * 340 + 30;
    const y = 210 - ((lat - minLat) / Math.max(0.01, maxLat - minLat)) * 170;
    return { x, y };
  };

  const selectedPlot = plots.find((p) => p.id === selectedPlotId) ?? plots[0];

  return (
    <div className="space-y-6">
      {actionSuccess && (
        <SuccessBanner message={actionSuccess} onDismiss={() => setActionSuccess(null)} />
      )}
      {actionError && <ErrorBanner message={actionError} />}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            Agricultural Plot Registry
          </h2>
          <p className="text-sm text-slate-600">
            Register farm blocks, GPS coordinates, crop stages, and critical operational deadlines.
          </p>
        </div>
        {isFarmer && (
          <button
            type="button"
            onClick={openAdd}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] rounded-lg transition-colors whitespace-nowrap self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Register Plot</span>
          </button>
        )}
      </div>

      {plots.length === 0 ? (
        <EmptyState
          title="No farm plots registered"
          description="Add your first plot with acreage, crop type, and GPS coordinates to start scheduling machinery."
          actionLabel={isFarmer ? 'Register Plot' : undefined}
          onAction={isFarmer ? openAdd : undefined}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Plot Table */}
          <div className="lg:col-span-8 rounded-xl border border-slate-200 bg-white overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4">Plot &amp; Location</th>
                    <th className="py-3 px-4 text-right">Area</th>
                    <th className="py-3 px-4">Crop &amp; Operation</th>
                    <th className="py-3 px-4">Coordinates</th>
                    <th className="py-3 px-4">Deadline</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {plots.map((plot) => {
                    const urgentThreshold = new Date(Date.now() + 3 * 86400000)
                      .toISOString()
                      .slice(0, 10);
                    const isUrgent = plot.deadline <= urgentThreshold;
                    const active = selectedPlot?.id === plot.id;
                    const canManagePlot = isFarmer && (isDemoMode || plot.farmerId === user?.id);
                    return (
                      <tr
                        key={plot.id}
                        onClick={() => setSelectedPlotId(plot.id)}
                        className={`cursor-pointer transition-colors ${
                          active ? 'bg-emerald-50/50' : 'hover:bg-slate-50/70'
                        }`}
                      >
                        <td className="py-3.5 px-4">
                          <p className="font-semibold text-slate-900">{plot.name}</p>
                          <p className="text-xs text-slate-500">{plot.locationLabel}</p>
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-900">
                          {plot.areaAcres.toFixed(1)} ac
                        </td>
                        <td className="py-3.5 px-4">
                          <p className="text-slate-900 font-medium">{plot.cropType}</p>
                          <p className="text-xs text-slate-500">{plot.operationType}</p>
                        </td>
                        <td className="py-3.5 px-4 font-mono text-xs text-slate-600 tabular-nums whitespace-nowrap">
                          {plot.coordinates.lat.toFixed(4)}, {plot.coordinates.lng.toFixed(4)}
                        </td>
                        <td className="py-3.5 px-4">
                          <p className="font-mono text-xs font-semibold text-slate-900 tabular-nums">
                            {plot.deadline}
                          </p>
                          <StatusIndicator
                            label={isUrgent ? 'Urgent' : 'Scheduled'}
                            tone={isUrgent ? 'danger' : 'success'}
                          />
                        </td>
                        <td
                          className="py-3.5 px-4 text-right whitespace-nowrap"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {canManagePlot && (
                            <>
                              <button
                                type="button"
                                onClick={() => openEdit(plot)}
                                aria-label={`Edit ${plot.name}`}
                                className="p-1.5 text-slate-600 hover:text-[#14532D] rounded-md"
                              >
                                <Pencil className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                disabled={deletingId === plot.id}
                                onClick={() => handleDelete(plot.id)}
                                aria-label={`Delete ${plot.name}`}
                                className="p-1.5 text-slate-600 hover:text-red-700 disabled:opacity-50 rounded-md ml-1"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Spatial Coordinate Grid Inspector */}
          <div className="lg:col-span-4 rounded-xl border border-slate-200 bg-white p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-base font-semibold text-slate-900">
                  Cluster Coordinate Map
                </h3>
                <span className="text-xs font-mono text-slate-500">WGS84</span>
              </div>
              <div className="rounded-lg border border-slate-200 bg-[#F8FAFC] p-2">
                <svg
                  viewBox="0 0 400 240"
                  className="w-full h-52"
                  role="img"
                  aria-label="Relative GPS positions of registered plots"
                >
                  {/* Grid Lines */}
                  {[40, 90, 140, 190].map((y) => (
                    <line
                      key={y}
                      x1="15"
                      y1={y}
                      x2="385"
                      y2={y}
                      stroke="#E2E8F0"
                      strokeWidth="1"
                    />
                  ))}
                  {[60, 140, 220, 300].map((x) => (
                    <line
                      key={x}
                      x1={x}
                      y1="15"
                      x2={x}
                      y2="225"
                      stroke="#E2E8F0"
                      strokeWidth="1"
                    />
                  ))}
                  {plots.map((plot) => {
                    const { x, y } = projectPoint(plot.coordinates.lat, plot.coordinates.lng);
                    const isSelected = selectedPlot?.id === plot.id;
                    return (
                      <g
                        key={plot.id}
                        className="cursor-pointer"
                        onClick={() => setSelectedPlotId(plot.id)}
                      >
                        <circle
                          cx={x}
                          cy={y}
                          r={isSelected ? 10 : 7}
                          fill={isSelected ? '#14532D' : '#10B981'}
                          stroke="#FFFFFF"
                          strokeWidth="2"
                        />
                        <text
                          x={x}
                          y={y - 14}
                          textAnchor="middle"
                          fontSize="10"
                          fontWeight="600"
                          fill="#0F172A"
                        >
                          {plot.name.split(' ').slice(0, 2).join(' ')}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>
            </div>

            {selectedPlot && (
              <div className="mt-4 pt-4 border-t border-slate-100 space-y-2 text-xs">
                <div className="flex items-center gap-1.5 font-semibold text-slate-900 text-sm">
                  <MapPin className="w-4 h-4 text-[#14532D]" />
                  <span>{selectedPlot.name}</span>
                </div>
                <p className="text-slate-600">{selectedPlot.notes || 'No field notes recorded.'}</p>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div>
                    <span className="text-slate-500">Soil Moisture</span>
                    <p className="font-mono font-semibold text-slate-900">
                      {selectedPlot.soilMoisturePercent}%
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-500">Farmer</span>
                    <p className="font-medium text-slate-900">{selectedPlot.farmerName}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add / Edit Plot Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingId ? 'Edit Agricultural Plot' : 'Register New Plot'}
        subtitle="Specify coordinates and deadlines so the scheduler can calculate transit buffers."
      >
        {formError && (
          <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
            {formError}
          </div>
        )}
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Plot Name</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="e.g. Nira Canal Block A-12"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Village / Sector
              </label>
              <input
                type="text"
                value={form.locationLabel}
                onChange={(e) => setForm({ ...form, locationLabel: e.target.value })}
                placeholder="e.g. Malegaon Bk, Baramati"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Area (acres)
              </label>
              <input
                type="number"
                step="0.1"
                min="0.5"
                value={form.areaAcres}
                onChange={(e) =>
                  setForm({ ...form, areaAcres: parseFloat(e.target.value) || 0 })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Crop Type</label>
              <select
                value={form.cropType}
                onChange={(e) => setForm({ ...form, cropType: e.target.value as CropType })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                {CROPS.map((crop) => (
                  <option key={crop} value={crop}>
                    {crop}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Required Operation
              </label>
              <select
                value={form.operationType}
                onChange={(e) =>
                  setForm({ ...form, operationType: e.target.value as OperationType })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                {OPERATIONS.map((op) => (
                  <option key={op} value={op}>
                    {op}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Latitude</label>
              <input
                type="number"
                step="0.0001"
                value={form.coordinates.lat}
                onChange={(e) =>
                  setForm({
                    ...form,
                    coordinates: {
                      ...form.coordinates,
                      lat: parseFloat(e.target.value) || 0,
                    },
                  })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Longitude</label>
              <input
                type="number"
                step="0.0001"
                value={form.coordinates.lng}
                onChange={(e) =>
                  setForm({
                    ...form,
                    coordinates: {
                      ...form.coordinates,
                      lng: parseFloat(e.target.value) || 0,
                    },
                  })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Target Deadline
              </label>
              <input
                type="date"
                value={form.deadline}
                onChange={(e) => setForm({ ...form, deadline: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Agronomic Notes
            </label>
            <textarea
              rows={2}
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              placeholder="Access gate details, soil moisture conditions, or preferred dispatch hours..."
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] disabled:opacity-60 rounded-lg"
            >
              {saving ? 'Saving...' : editingId ? 'Save Plot' : 'Register Plot'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
