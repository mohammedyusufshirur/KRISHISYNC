import React, { useCallback, useEffect, useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { MetricCard } from '../components/MetricCard';
import { ErrorBanner, LoadingSkeleton } from '../components/PageState';
import { StatusIndicator, mapStatusToTone } from '../components/StatusIndicator';
import { bookingService } from '../services/bookingService';
import { equipmentService } from '../services/equipmentService';
import { farmerService } from '../services/farmerService';
import { plotService } from '../services/plotService';
import { Booking, Equipment, FarmerDashboardData, Plot } from '../types/domain';

export const FarmerDashboardPage: React.FC = () => {
  const [dashboard, setDashboard] = useState<FarmerDashboardData | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [plots, setPlots] = useState<Plot[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [dash, bks, pls, eqs] = await Promise.all([
        farmerService.getDashboardData(),
        bookingService.list(),
        plotService.list(),
        equipmentService.list(),
      ]);
      setDashboard(dash);
      setBookings(bks);
      setPlots(pls);
      setEquipment(eqs);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load farmer dashboard.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  if (loading) return <LoadingSkeleton />;
  if (error || !dashboard) {
    return <ErrorBanner message={error ?? 'Dashboard data unavailable.'} onRetry={loadData} />;
  }

  const upcomingBookings = bookings.filter(
    (b) => b.status !== 'Completed' && b.status !== 'Cancelled'
  );
  const urgentPlots = [...plots].sort((a, b) => a.deadline.localeCompare(b.deadline));
  const availableEquipment = equipment.filter((e) => e.status === 'Available');

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            Farm Operations Overview
          </h2>
          <p className="text-sm text-slate-600">
            Track upcoming field schedules, urgent crop deadlines, and nearby ready machinery.
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <Link
            to="/app/plots"
            className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap"
          >
            Manage Plots
          </Link>
          <Link
            to="/app/bookings"
            className="px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] rounded-lg transition-colors whitespace-nowrap"
          >
            Book Equipment
          </Link>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          label="Total Bookings"
          value={dashboard.metrics.totalBookings}
          context="Active & historical field requests"
        />
        <MetricCard
          label="Upcoming Operations"
          value={dashboard.metrics.upcomingOperations}
          context="Pending, confirmed & in-field tasks"
          accent
        />
        <MetricCard
          label="Urgent Deadlines"
          value={dashboard.metrics.urgentDeadlines}
          context="Plots due within next 3 days"
        />
        <MetricCard
          label="Available Equipment"
          value={dashboard.metrics.availableEquipmentCount}
          context="Ready for regional dispatch today"
        />
      </div>

      {/* Chart + Recent Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 rounded-xl border border-slate-200 bg-white p-6">
          <div className="flex items-center justify-between gap-4 mb-5">
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                Weekly Field Operations &amp; Acreage Covered
              </h3>
              <p className="text-xs text-slate-500">
                Scheduled machine hours vs completed acres across registered plots
              </p>
            </div>
            <span className="text-xs font-mono text-slate-500">7-Day Operations Window</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dashboard.weeklyOperationsChart}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                <XAxis
                  dataKey="day"
                  tick={{ fontSize: 12, fill: '#64748B' }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 12, fill: '#64748B' }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    borderRadius: '8px',
                    border: '1px solid #E2E8F0',
                    fontSize: '12px',
                  }}
                />
                <Bar
                  dataKey="completedAcres"
                  name="Completed Acres"
                  fill="#14532D"
                  radius={[4, 4, 0, 0]}
                />
                <Bar
                  dataKey="scheduledHours"
                  name="Machine Hours"
                  fill="#10B981"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-4 rounded-xl border border-slate-200 bg-white p-6 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-slate-900">Recent Activities</h3>
            <Link
              to="/app/bookings"
              className="text-xs font-medium text-[#14532D] hover:underline"
            >
              All Bookings
            </Link>
          </div>
          <div className="divide-y divide-slate-100 flex-1">
            {dashboard.recentActivities.map((act) => (
              <div key={act.id} className="py-3 first:pt-0 last:pb-0">
                <p className="text-sm font-medium text-slate-900">{act.title}</p>
                <p className="text-xs text-slate-600 mt-0.5">{act.detail}</p>
                <p className="text-xs font-mono text-slate-400 mt-1 tabular-nums">
                  {act.timestamp}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Upcoming Operations & Urgent Deadlines */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-900">Upcoming Operations</h3>
            <Link
              to="/app/scheduler"
              className="text-xs font-medium text-[#14532D] hover:underline"
            >
              Open Smart Scheduler
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-4">Plot &amp; Operation</th>
                  <th className="py-2.5 px-4">Equipment</th>
                  <th className="py-2.5 px-4">Date</th>
                  <th className="py-2.5 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {upcomingBookings.slice(0, 5).map((bk) => (
                  <tr key={bk.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4">
                      <p className="font-medium text-slate-900">{bk.plotName}</p>
                      <p className="text-xs text-slate-500">
                        {bk.operationType} · {bk.plotAreaAcres} ac
                      </p>
                    </td>
                    <td className="py-3 px-4 text-slate-700">{bk.equipmentName}</td>
                    <td className="py-3 px-4 font-mono text-xs text-slate-600 tabular-nums whitespace-nowrap">
                      {bk.requestedDate}
                    </td>
                    <td className="py-3 px-4">
                      <StatusIndicator
                        label={bk.status}
                        tone={mapStatusToTone(bk.status)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="lg:col-span-5 rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-900">Urgent Plot Deadlines</h3>
            <Link
              to="/app/plots"
              className="text-xs font-medium text-[#14532D] hover:underline"
            >
              Plot Registry
            </Link>
          </div>
          <div className="divide-y divide-slate-100">
            {urgentPlots.map((plot) => {
              const urgentThreshold = new Date(Date.now() + 3 * 86400000)
                .toISOString()
                .slice(0, 10);
              const isUrgent = plot.deadline <= urgentThreshold;
              return (
                <div
                  key={plot.id}
                  className="px-6 py-3.5 flex items-center justify-between gap-4 hover:bg-slate-50/70"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-900 truncate">{plot.name}</p>
                    <p className="text-xs text-slate-500">
                      {plot.cropType} · {plot.operationType} · {plot.areaAcres} ac
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs font-mono font-semibold text-slate-900 tabular-nums">
                      {plot.deadline}
                    </p>
                    <StatusIndicator
                      label={isUrgent ? 'Critical Window' : 'On Track'}
                      tone={isUrgent ? 'danger' : 'success'}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Available Equipment Strip */}
      <div className="rounded-xl border border-slate-200 bg-white p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              Available Equipment Near Baramati Cluster
            </h3>
            <p className="text-xs text-slate-500">
              Ready for immediate booking based on verified fleet status
            </p>
          </div>
          <Link
            to="/app/equipment"
            className="inline-flex items-center gap-1 text-xs font-medium text-[#14532D] hover:underline"
          >
            <span>Full Registry</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {availableEquipment.slice(0, 3).map((eq) => (
            <div
              key={eq.id}
              className="rounded-lg border border-slate-200 p-4 flex flex-col justify-between gap-3"
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-medium text-slate-500">{eq.category}</span>
                  <StatusIndicator label={eq.status} tone="success" />
                </div>
                <h4 className="mt-1.5 text-sm font-semibold text-slate-900">{eq.name}</h4>
                <p className="text-xs text-slate-500 mt-0.5">{eq.location}</p>
              </div>
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs font-mono font-semibold text-slate-900 tabular-nums">
                  ₹{eq.hourlyRateInr}/hr · {eq.workCapacityAcresPerHr} ac/hr
                </span>
                <button
                  type="button"
                  onClick={() => navigate(`/app/bookings?equipmentId=${eq.id}`)}
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] rounded-md transition-colors whitespace-nowrap"
                >
                  Book
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
