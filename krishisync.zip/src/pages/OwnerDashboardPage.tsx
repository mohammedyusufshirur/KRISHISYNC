import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { MetricCard } from '../components/MetricCard';
import { ErrorBanner, LoadingSkeleton, SuccessBanner } from '../components/PageState';
import { StatusIndicator, mapStatusToTone } from '../components/StatusIndicator';
import { bookingService } from '../services/bookingService';
import { equipmentService } from '../services/equipmentService';
import { notificationService } from '../services/notificationService';
import { useAuth } from '../context/AuthContext';
import { Booking, Equipment, OwnerDashboardData } from '../types/domain';

export const OwnerDashboardPage: React.FC = () => {
  const [data, setData] = useState<OwnerDashboardData | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const { user, isDemoMode, refreshUnreadCount } = useAuth();
  const isOwner = user?.role === 'owner';

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [ownerDash, bks, eqs] = await Promise.all([
        bookingService.getOwnerDashboardData(),
        bookingService.list(),
        equipmentService.list(),
      ]);
      setData(ownerDash);
      setBookings(bks);
      setEquipment(eqs);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load owner dashboard.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const handleRequestAction = async (
    booking: Booking,
    decision: 'Confirmed' | 'Cancelled'
  ) => {
    setBusyId(booking.id);
    setActionError(null);
    setActionSuccess(null);
    try {
      await bookingService.updateStatus(booking.id, decision);
      notificationService.pushNotification({
        category: 'Booking Update',
        severity: decision === 'Confirmed' ? 'info' : 'warning',
        title:
          decision === 'Confirmed'
            ? `Booking ${booking.id} Confirmed`
            : `Booking ${booking.id} Declined`,
        message: `${booking.equipmentName} for ${booking.plotName} was marked ${decision}.`,
        actionRoute: '/app/bookings',
        actionLabel: 'View Bookings',
        relatedId: booking.id,
      });
      await refreshUnreadCount();
      await loadData();
      setActionSuccess(`Booking ${booking.id} marked as ${decision}.`);
    } catch (err) {
      setActionError(
        err instanceof Error ? err.message : `Failed to update booking ${booking.id}.`
      );
    } finally {
      setBusyId(null);
    }
  };

  if (loading) return <LoadingSkeleton />;
  if (error || !data) {
    return <ErrorBanner message={error ?? 'Owner dashboard unavailable.'} onRetry={loadData} />;
  }

  const pendingRequests = bookings.filter((b) => b.status === 'Pending');
  const upcomingSchedules = bookings.filter(
    (b) => b.status === 'Confirmed' || b.status === 'Scheduled' || b.status === 'In Progress'
  );

  return (
    <div className="space-y-6">
      {actionSuccess && (
        <SuccessBanner message={actionSuccess} onDismiss={() => setActionSuccess(null)} />
      )}
      {actionError && <ErrorBanner message={actionError} />}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">
            Fleet Operations &amp; Dispatch Console
          </h2>
          <p className="text-sm text-slate-600">
            Monitor machine utilization, approve pending farmer requests, and oversee schedules.
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <Link
            to="/app/emergencies"
            className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap"
          >
            Report Breakdown
          </Link>
          <Link
            to="/app/equipment"
            className="px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] rounded-lg transition-colors whitespace-nowrap"
          >
            Manage Fleet
          </Link>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          label="Registered Machines"
          value={data.metrics.registeredMachines}
          context="Total agricultural units in network"
        />
        <MetricCard
          label="Available Equipment"
          value={data.metrics.availableEquipment}
          context="Idle & ready for immediate dispatch"
          accent
        />
        <MetricCard
          label="Pending Requests"
          value={data.metrics.pendingRequests}
          context="Awaiting fleet owner confirmation"
        />
        <MetricCard
          label="Upcoming Schedules"
          value={data.metrics.upcomingSchedules}
          context="Confirmed & allocated machine slots"
        />
      </div>

      {/* Utilization Chart & Fleet Snapshot */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 rounded-xl border border-slate-200 bg-white p-6">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                Fleet Revenue &amp; Utilization Trend
              </h3>
              <p className="text-xs text-slate-500">
                Monthly gross rental earnings (INR) across active hubs
              </p>
            </div>
            <span className="text-xs font-mono text-emerald-700 font-semibold">
              91% Nov Peak
            </span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.revenueUtilizationChart}>
                <defs>
                  <linearGradient id="krishiRevGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#14532D" stopOpacity={0.22} />
                    <stop offset="95%" stopColor="#14532D" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                <XAxis
                  dataKey="month"
                  tick={{ fontSize: 12, fill: '#64748B' }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 12, fill: '#64748B' }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v) => `₹${Math.round(v / 1000)}k`}
                />
                <Tooltip
                  formatter={(value) => [
                    `₹${Number(value ?? 0).toLocaleString('en-IN')}`,
                    'Revenue',
                  ]}
                  contentStyle={{
                    borderRadius: '8px',
                    border: '1px solid #E2E8F0',
                    fontSize: '12px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="revenueInr"
                  stroke="#14532D"
                  strokeWidth={2}
                  fill="url(#krishiRevGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-4 rounded-xl border border-slate-200 bg-white p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-slate-900">Machine Status</h3>
            <Link
              to="/app/equipment"
              className="text-xs font-medium text-[#14532D] hover:underline"
            >
              View All
            </Link>
          </div>
          <div className="divide-y divide-slate-100">
            {equipment.slice(0, 5).map((eq) => (
              <div key={eq.id} className="py-3 first:pt-0 last:pb-0 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-slate-900 truncate">{eq.name}</p>
                  <p className="text-xs text-slate-500 truncate">
                    {eq.category} · {eq.utilizationPercent}% utilized
                  </p>
                </div>
                <StatusIndicator label={eq.status} tone={mapStatusToTone(eq.status)} />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Pending Requests + Upcoming Schedules */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-900">Pending Booking Requests</h3>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              {pendingRequests.length} waiting
            </span>
          </div>
          {pendingRequests.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              All incoming booking requests have been reviewed.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {pendingRequests.map((bk) => (
                <div
                  key={bk.id}
                  className="px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div>
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="font-mono">{bk.id}</span>
                      <span aria-hidden="true">·</span>
                      <span>{bk.farmerName}</span>
                      <span aria-hidden="true">·</span>
                      <StatusIndicator label={bk.priority} tone={mapStatusToTone(bk.priority)} />
                    </div>
                    <p className="mt-1 text-sm font-semibold text-slate-900">
                      {bk.equipmentName}
                    </p>
                    <p className="text-xs text-slate-600 mt-0.5">
                      {bk.plotName} ({bk.plotAreaAcres} ac) · Requested{' '}
                      <span className="font-mono">{bk.requestedDate}</span> · Est. ₹
                      {bk.estimatedCostInr.toLocaleString('en-IN')}
                    </p>
                  </div>
                  {(isOwner && (isDemoMode || bk.ownerId === user?.id)) && (
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        disabled={busyId === bk.id}
                        onClick={() => handleRequestAction(bk, 'Confirmed')}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap"
                      >
                        Approve
                      </button>
                      <button
                        type="button"
                        disabled={busyId === bk.id}
                        onClick={() => handleRequestAction(bk, 'Cancelled')}
                        className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap"
                      >
                        Decline
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="lg:col-span-6 rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-base font-semibold text-slate-900">Upcoming Fleet Schedules</h3>
            <Link
              to="/app/scheduler"
              className="text-xs font-medium text-[#14532D] hover:underline"
            >
              Timeline View
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-4">Machine</th>
                  <th className="py-2.5 px-4">Plot &amp; Distance</th>
                  <th className="py-2.5 px-4">Date</th>
                  <th className="py-2.5 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {upcomingSchedules.map((bk) => (
                  <tr key={bk.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-medium text-slate-900">
                      {bk.equipmentName}
                    </td>
                    <td className="py-3 px-4">
                      <p className="text-slate-700">{bk.plotName}</p>
                      <p className="text-xs font-mono text-slate-500">
                        {bk.travelDistanceKm} km transit
                      </p>
                    </td>
                    <td className="py-3 px-4 font-mono text-xs text-slate-600 tabular-nums whitespace-nowrap">
                      {bk.requestedDate}
                    </td>
                    <td className="py-3 px-4">
                      <StatusIndicator label={bk.status} tone={mapStatusToTone(bk.status)} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
