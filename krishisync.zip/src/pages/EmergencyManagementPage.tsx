import React, { useCallback, useEffect, useState } from 'react';
import { AlertOctagon, ArrowRight, CheckCircle2, CloudRain, Wrench } from 'lucide-react';
import { ErrorBanner, LoadingSkeleton, SuccessBanner } from '../components/PageState';
import { StatusIndicator, mapStatusToTone } from '../components/StatusIndicator';
import { useAuth } from '../context/AuthContext';
import { bookingService } from '../services/bookingService';
import { disruptionService } from '../services/disruptionService';
import { equipmentService } from '../services/equipmentService';
import { notificationService } from '../services/notificationService';
import {
  Booking,
  DisruptionInput,
  DisruptionReport,
  DisruptionSeverity,
  DisruptionType,
  Equipment,
} from '../types/domain';

export const EmergencyManagementPage: React.FC = () => {
  const { user, refreshUnreadCount } = useAuth();
  const [reports, setReports] = useState<DisruptionReport[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  const [form, setForm] = useState<DisruptionInput>({
    type: 'Machine Breakdown',
    severity: 'Critical',
    equipmentId: '',
    affectedRegion: 'Baramati & Indapur Belt',
    description: '',
  });
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [applyingId, setApplyingId] = useState<string | null>(null);
  const [restoringId, setRestoringId] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [dis, eqs, bks] = await Promise.all([
        disruptionService.list(),
        equipmentService.list(),
        bookingService.list(),
      ]);
      setReports(dis);
      setEquipment(eqs);
      setBookings(bks);
      setForm((prev) => ({
        ...prev,
        equipmentId: prev.equipmentId || eqs[0]?.id || '',
      }));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load emergency console.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const handleSubmitDisruption = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!form.affectedRegion.trim() || !form.description.trim()) {
      setFormError('Specify the affected region and describe the disruption.');
      return;
    }
    if (form.type === 'Machine Breakdown' && !form.equipmentId) {
      setFormError('Select the machine experiencing a breakdown.');
      return;
    }

    setSubmitting(true);
    try {
      const created = await disruptionService.reportDisruption(
        form,
        user?.name ?? 'Vikramjit Singh Gill'
      );
      notificationService.pushNotification({
        category: 'Rescheduling',
        severity: 'critical',
        title: `${created.type} Reported (${created.id})`,
        message: `${created.affectedBookingIds.length} booking(s) impacted in ${created.affectedRegion}. Alternative equipment surfaced.`,
        actionRoute: '/app/emergencies',
        actionLabel: 'Review Mitigation',
        relatedId: created.id,
      });
      await refreshUnreadCount();
      setForm((prev) => ({ ...prev, description: '' }));
      await loadData();
      setActionSuccess(`Disruption ${created.id} logged and impact assessed.`);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to log disruption.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleApplyRevisedPlan = async (disruptionId: string) => {
    setApplyingId(disruptionId);
    setActionError(null);
    setActionSuccess(null);
    try {
      await disruptionService.applyRevisedPlan(disruptionId);
      notificationService.pushNotification({
        category: 'Rescheduling',
        severity: 'info',
        title: `Mitigation Plan Applied (${disruptionId})`,
        message: 'Affected bookings have been reassigned to backup regional equipment.',
        actionRoute: '/app/bookings',
        actionLabel: 'View Bookings',
        relatedId: disruptionId,
      });
      await refreshUnreadCount();
      await loadData();
      setActionSuccess(`Revised schedule applied for disruption ${disruptionId}.`);
    } catch (err) {
      setActionError(
        err instanceof Error ? err.message : 'Failed to apply revised mitigation plan.'
      );
    } finally {
      setApplyingId(null);
    }
  };

  const handleRestoreEquipment = async (equipmentId: string, disruptionId: string) => {
    setRestoringId(disruptionId);
    setActionError(null);
    setActionSuccess(null);
    try {
      await disruptionService.restoreEquipment(equipmentId, disruptionId);
      notificationService.pushNotification({
        category: 'Rescheduling',
        severity: 'info',
        title: `Equipment Restored (${equipmentId})`,
        message: 'Repaired machine returned to Available status for regional scheduling.',
        actionRoute: '/app/equipment',
        actionLabel: 'View Equipment',
        relatedId: equipmentId,
      });
      await refreshUnreadCount();
      await loadData();
      setActionSuccess('Equipment marked repaired and restored to Available status.');
    } catch (err) {
      setActionError(
        err instanceof Error ? err.message : 'Failed to restore equipment availability.'
      );
    } finally {
      setRestoringId(null);
    }
  };

  if (loading) return <LoadingSkeleton />;
  if (error) return <ErrorBanner message={error} onRetry={loadData} />;

  return (
    <div className="space-y-6">
      {actionSuccess && (
        <SuccessBanner message={actionSuccess} onDismiss={() => setActionSuccess(null)} />
      )}
      {actionError && <ErrorBanner message={actionError} />}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900">
          Emergency &amp; Disruption Management
        </h2>
        <p className="text-sm text-slate-600">
          Report mechanical breakdowns or severe weather events, inspect affected bookings, and
          apply backup equipment reassignments.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Report Disruption Form */}
        <div className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-6 self-start">
          <div className="flex items-center gap-2 mb-4">
            <AlertOctagon className="w-4 h-4 text-red-700" />
            <h3 className="text-base font-semibold text-slate-900">
              Report Operational Disruption
            </h3>
          </div>

          {formError && (
            <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
              {formError}
            </div>
          )}

          <form onSubmit={handleSubmitDisruption} className="space-y-4">
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-lg">
              {(['Machine Breakdown', 'Severe Weather'] as DisruptionType[]).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setForm({ ...form, type })}
                  className={`inline-flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-md transition-colors ${
                    form.type === type
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {type === 'Machine Breakdown' ? (
                    <Wrench className="w-3.5 h-3.5" />
                  ) : (
                    <CloudRain className="w-3.5 h-3.5" />
                  )}
                  <span>{type}</span>
                </button>
              ))}
            </div>

            {form.type === 'Machine Breakdown' && (
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Affected Equipment
                </label>
                <select
                  value={form.equipmentId ?? ''}
                  onChange={(e) => setForm({ ...form, equipmentId: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  {equipment.map((eq) => (
                    <option key={eq.id} value={eq.id}>
                      {eq.name} ({eq.status})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Severity
                </label>
                <select
                  value={form.severity}
                  onChange={(e) =>
                    setForm({ ...form, severity: e.target.value as DisruptionSeverity })
                  }
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  <option value="Critical">Critical (Immediate Halt)</option>
                  <option value="Moderate">Moderate (Delayed Window)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Affected Cluster / Region
                </label>
                <input
                  type="text"
                  value={form.affectedRegion}
                  onChange={(e) => setForm({ ...form, affectedRegion: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Incident Description
              </label>
              <textarea
                rows={3}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder={
                  form.type === 'Machine Breakdown'
                    ? 'Describe hydraulic, engine, or header issue and estimated repair window...'
                    : 'Specify rainfall intensity, wind speed threshold, or field waterlogging...'
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-red-700 hover:bg-red-800 disabled:opacity-60 rounded-lg transition-colors"
            >
              {submitting ? 'Logging & Assessing Impact...' : `Report ${form.type}`}
            </button>
          </form>
        </div>

        {/* Active Disruptions & Mitigation Plans */}
        <div className="lg:col-span-7 space-y-6">
          {reports.map((report) => {
            const impactedBookings = bookings.filter((b) =>
              report.affectedBookingIds.includes(b.id)
            );
            return (
              <div
                key={report.id}
                className="rounded-xl border border-slate-200 bg-white overflow-hidden"
              >
                <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="font-mono">{report.id}</span>
                      <span aria-hidden="true">·</span>
                      <span>{report.type}</span>
                      <span aria-hidden="true">·</span>
                      <span>{report.affectedRegion}</span>
                    </div>
                    <h3 className="mt-1 text-base font-semibold text-slate-900">
                      {report.equipmentName ?? 'Regional Weather Advisory'}
                    </h3>
                  </div>
                  <div className="flex flex-wrap items-center gap-3">
                    <StatusIndicator
                      label={report.status}
                      tone={mapStatusToTone(report.status)}
                    />
                    {report.status === 'Active' && report.revisedPlan.length > 0 && (
                      <button
                        type="button"
                        onClick={() => handleApplyRevisedPlan(report.id)}
                        disabled={applyingId === report.id}
                        className="px-3.5 py-1.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap"
                      >
                        {applyingId === report.id ? 'Applying...' : 'Apply Revised Plan'}
                      </button>
                    )}
                    {user?.role === 'owner' &&
                      report.equipmentId &&
                      equipment.find((eq) => eq.id === report.equipmentId)?.status ===
                        'Maintenance' && (
                        <button
                          type="button"
                          onClick={() =>
                            handleRestoreEquipment(report.equipmentId!, report.id)
                          }
                          disabled={restoringId === report.id}
                          className="px-3.5 py-1.5 text-xs font-semibold text-[#14532D] bg-emerald-50 border border-emerald-200 hover:bg-emerald-100 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap"
                        >
                          {restoringId === report.id
                            ? 'Restoring...'
                            : 'Mark Repaired & Restore'}
                        </button>
                      )}
                  </div>
                </div>

                <div className="p-6 space-y-5">
                  <p className="text-sm text-slate-700">{report.description}</p>

                  {/* Affected Bookings */}
                  <div>
                    <h4 className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">
                      Affected Bookings ({impactedBookings.length})
                    </h4>
                    {impactedBookings.length === 0 ? (
                      <p className="text-xs text-slate-500">
                        No open bookings directly overlap this incident.
                      </p>
                    ) : (
                      <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg">
                        {impactedBookings.map((bk) => (
                          <div
                            key={bk.id}
                            className="px-4 py-2.5 flex items-center justify-between text-xs"
                          >
                            <div>
                              <span className="font-mono font-semibold text-slate-900">
                                {bk.id}
                              </span>
                              <span className="mx-2 text-slate-300">·</span>
                              <span className="font-medium text-slate-800">
                                {bk.plotName}
                              </span>
                              <span className="mx-2 text-slate-300">·</span>
                              <span className="text-slate-600">
                                Due {bk.deadline}
                              </span>
                            </div>
                            <StatusIndicator
                              label={bk.status}
                              tone={mapStatusToTone(bk.status)}
                            />
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Alternative Equipment */}
                  <div>
                    <h4 className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">
                      Recommended Alternative Equipment
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {report.alternatives.map((alt) => (
                        <div
                          key={alt.equipmentId}
                          className="rounded-lg border border-slate-200 p-3.5 text-xs"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-semibold text-slate-900">
                              {alt.equipmentName}
                            </span>
                            <span className="font-mono text-emerald-700 font-semibold">
                              {alt.distanceKm} km
                            </span>
                          </div>
                          <p className="text-slate-600 mt-1">{alt.compatibilityNote}</p>
                          <p className="font-mono text-slate-500 mt-1.5">
                            Earliest: {alt.earliestWindow} · ₹{alt.hourlyRateInr}/hr
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Revised Schedules */}
                  {report.revisedPlan.length > 0 && (
                    <div>
                      <h4 className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">
                        Revised Dispatch Schedule
                      </h4>
                      <div className="overflow-x-auto border border-slate-200 rounded-lg">
                        <table className="w-full text-left border-collapse text-xs">
                          <thead>
                            <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                              <th className="py-2 px-3">Booking / Plot</th>
                              <th className="py-2 px-3">Equipment Reassignment</th>
                              <th className="py-2 px-3">Revised Window</th>
                              <th className="py-2 px-3">State</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {report.revisedPlan.map((item) => (
                              <tr key={item.bookingId}>
                                <td className="py-2.5 px-3 font-medium text-slate-900">
                                  <span className="font-mono">{item.bookingId}</span> ·{' '}
                                  {item.plotName}
                                </td>
                                <td className="py-2.5 px-3 text-slate-700">
                                  <span className="line-through text-slate-400">
                                    {item.previousEquipmentName}
                                  </span>
                                  <ArrowRight className="w-3 h-3 inline mx-1.5 text-emerald-700" />
                                  <span className="font-semibold text-[#14532D]">
                                    {item.newEquipmentName}
                                  </span>
                                </td>
                                <td className="py-2.5 px-3 font-mono text-slate-700">
                                  {item.revisedWindow}
                                </td>
                                <td className="py-2.5 px-3">
                                  {item.status === 'Applied' ? (
                                    <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                                      <CheckCircle2 className="w-3.5 h-3.5" />
                                      Applied
                                    </span>
                                  ) : (
                                    <StatusIndicator label="Proposed" tone="warning" />
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
