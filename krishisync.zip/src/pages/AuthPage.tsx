import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, Sprout, Tractor } from 'lucide-react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types/domain';

export const AuthPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const initialMode = searchParams.get('mode') === 'register' ? 'register' : 'login';
  const initialRole: UserRole =
    searchParams.get('role') === 'owner' ? 'owner' : 'farmer';

  const [mode, setMode] = useState<'login' | 'register' | 'reset'>(initialMode);
  const [role, setRole] = useState<UserRole>(initialRole);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('rajesh.deshmukh@krishisync.in');
  const [phone, setPhone] = useState('');
  const [region, setRegion] = useState('Baramati Cluster, Pune');
  const [organizationName, setOrganizationName] = useState('');
  const [password, setPassword] = useState('krishi2026');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const { login, register, resetPassword, switchRoleDemo } = useAuth();
  const navigate = useNavigate();

  const validateForm = (): string | null => {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email.trim())) {
      return 'Enter a valid email address.';
    }
    if (mode === 'reset') {
      return null;
    }
    if (password.length < 6) {
      return 'Password must be at least 6 characters.';
    }
    if (mode === 'register') {
      if (name.trim().length < 2) {
        return 'Enter your full name.';
      }
      if (phone.trim().replace(/\D/g, '').length < 10) {
        return 'Enter a valid 10-digit phone number.';
      }
      if (region.trim().length < 2) {
        return 'Enter your farming cluster or service region.';
      }
      if (password !== confirmPassword) {
        return 'Password confirmation does not match.';
      }
    }
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }

    setSubmitting(true);
    try {
      if (mode === 'reset') {
        const message = await resetPassword(email);
        setNotice(message);
        setMode('login');
        return;
      }

      const authSession =
        mode === 'login'
          ? await login({ email, password, role })
          : await register({
              name,
              email,
              phone,
              password,
              role,
              region,
              organizationName,
            });
      navigate(
        authSession.user.role === 'farmer'
          ? '/app/farmer-dashboard'
          : '/app/owner-dashboard'
      );
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to authenticate.';
      if (msg.toLowerCase().includes('verify your email')) {
        setNotice(msg);
        setMode('login');
      } else {
        setError(msg);
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleQuickDemo = (demoRole: UserRole) => {
    switchRoleDemo(demoRole);
    navigate(demoRole === 'farmer' ? '/app/farmer-dashboard' : '/app/owner-dashboard');
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col">
      <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-8 flex items-center justify-between">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to KRISHISYNC</span>
        </Link>
        <span className="font-bold text-base tracking-tight text-[#0B3B24]">KRISHISYNC</span>
      </header>

      <div className="flex-1 flex items-center justify-center px-4 py-10">
        <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 rounded-xl border border-slate-200 bg-white overflow-hidden">
          {/* Left Context Panel */}
          <div className="lg:col-span-5 bg-[#0B3B24] text-white p-8 flex flex-col justify-between">
            <div>
              <p className="text-xs font-medium text-emerald-300">Unified Cluster Access</p>
              <h1 className="mt-3 text-2xl font-bold tracking-tight">
                {mode === 'login'
                  ? 'Sign in to your agricultural operations hub'
                  : 'Join the KRISHISYNC mechanization network'}
              </h1>
              <p className="mt-3 text-sm text-emerald-100/90 leading-relaxed">
                Coordinate plot schedules, verify machine availability, and mitigate field
                disruptions from one synchronized workspace.
              </p>

              <ul className="mt-8 space-y-3 text-sm text-emerald-50">
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Role-tailored dashboards for farmers and fleet owners</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Supabase Auth &amp; external Scheduling API ready</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Instant breakdown alerts and alternative rig dispatch</span>
                </li>
              </ul>
            </div>

            <div className="mt-10 pt-6 border-t border-emerald-800/80">
              <p className="text-xs font-medium text-emerald-200 mb-2.5">
                Quick Demo Access
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleQuickDemo('farmer')}
                  className="px-3 py-2 text-xs font-medium bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg transition-colors whitespace-nowrap"
                >
                  Enter as Farmer
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickDemo('owner')}
                  className="px-3 py-2 text-xs font-medium bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors whitespace-nowrap"
                >
                  Enter as Owner
                </button>
              </div>
            </div>
          </div>

          {/* Right Form Panel */}
          <div className="lg:col-span-7 p-6 sm:p-8">
            {/* Mode Switch */}
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg mb-6">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError(null);
                  setNotice(null);
                }}
                className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors ${
                  mode === 'login' || mode === 'reset'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setError(null);
                  setNotice(null);
                }}
                className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors ${
                  mode === 'register'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Create Account
              </button>
            </div>

            {/* Role Selector */}
            {mode !== 'reset' && (
              <div className="mb-5">
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  Select Account Role
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setRole('farmer');
                      if (mode === 'login') setEmail('rajesh.deshmukh@krishisync.in');
                    }}
                    className={`flex items-center gap-3 p-3 rounded-lg border text-left transition-colors ${
                      role === 'farmer'
                        ? 'border-[#14532D] bg-emerald-50/60 text-[#0B3B24]'
                        : 'border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <Sprout className="w-4 h-4 shrink-0" />
                    <div>
                      <p className="text-sm font-semibold">Farmer</p>
                      <p className="text-xs text-slate-500">Plots &amp; bookings</p>
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setRole('owner');
                      if (mode === 'login') setEmail('vikram.gill@krishisync.in');
                    }}
                    className={`flex items-center gap-3 p-3 rounded-lg border text-left transition-colors ${
                      role === 'owner'
                        ? 'border-[#14532D] bg-emerald-50/60 text-[#0B3B24]'
                        : 'border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <Tractor className="w-4 h-4 shrink-0" />
                    <div>
                      <p className="text-sm font-semibold">Equipment Owner</p>
                      <p className="text-xs text-slate-500">Fleet &amp; dispatch</p>
                    </div>
                  </button>
                </div>
              </div>
            )}

            {notice && (
              <div
                role="status"
                className="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 px-3.5 py-2.5 text-xs font-medium text-emerald-800"
              >
                {notice}
              </div>
            )}

            {error && (
              <div
                role="alert"
                className="mb-4 rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs font-medium text-red-700"
              >
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4" noValidate>
              {mode === 'register' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="auth-name" className="block text-xs font-medium text-slate-700 mb-1">
                      Full Name
                    </label>
                    <input
                      id="auth-name"
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Suresh Patil"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                  </div>
                  <div>
                    <label htmlFor="auth-phone" className="block text-xs font-medium text-slate-700 mb-1">
                      Mobile Number
                    </label>
                    <input
                      id="auth-phone"
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+91 98230 00000"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                  </div>
                </div>
              )}

              <div>
                <label htmlFor="auth-email" className="block text-xs font-medium text-slate-700 mb-1">
                  Email Address
                </label>
                <input
                  id="auth-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@krishisync.in"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              {mode === 'register' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="auth-org" className="block text-xs font-medium text-slate-700 mb-1">
                      {role === 'farmer' ? 'Farm / Co-op Name' : 'Fleet Company Name'}
                    </label>
                    <input
                      id="auth-org"
                      type="text"
                      value={organizationName}
                      onChange={(e) => setOrganizationName(e.target.value)}
                      placeholder={role === 'farmer' ? 'Sahyadri Farms' : 'Gill Agro Fleet'}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                  </div>
                  <div>
                    <label htmlFor="auth-region" className="block text-xs font-medium text-slate-700 mb-1">
                      Cluster / District
                    </label>
                    <input
                      id="auth-region"
                      type="text"
                      value={region}
                      onChange={(e) => setRegion(e.target.value)}
                      placeholder="Baramati Cluster, Pune"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                  </div>
                </div>
              )}

              {mode !== 'reset' && (
                <div className={`grid grid-cols-1 ${mode === 'register' ? 'sm:grid-cols-2' : ''} gap-4`}>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label htmlFor="auth-password" className="block text-xs font-medium text-slate-700">
                        Password
                      </label>
                      {mode === 'login' && (
                        <button
                          type="button"
                          onClick={() => {
                            setMode('reset');
                            setError(null);
                            setNotice(null);
                          }}
                          className="text-xs font-medium text-[#14532D] hover:underline"
                        >
                          Forgot password?
                        </button>
                      )}
                    </div>
                    <input
                      id="auth-password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Minimum 6 characters"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                  </div>
                  {mode === 'register' && (
                    <div>
                      <label htmlFor="auth-confirm" className="block text-xs font-medium text-slate-700 mb-1">
                        Confirm Password
                      </label>
                      <input
                        id="auth-confirm"
                        type="password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="Re-enter password"
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                      />
                    </div>
                  )}
                </div>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-[#14532D] hover:bg-[#0B3B24] disabled:opacity-60 rounded-lg transition-colors"
              >
                {submitting
                  ? 'Authenticating...'
                  : mode === 'reset'
                  ? 'Send Password Reset Link'
                  : mode === 'login'
                  ? `Sign In as ${role === 'farmer' ? 'Farmer' : 'Equipment Owner'}`
                  : `Register ${role === 'farmer' ? 'Farmer' : 'Equipment Owner'} Account`}
              </button>

              {mode === 'reset' && (
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setError(null);
                  }}
                  className="w-full py-2 text-xs font-medium text-slate-600 hover:text-slate-900"
                >
                  Return to Sign In
                </button>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
