import React, { useState } from 'react';
import {
  AlertOctagon,
  Bell,
  CalendarClock,
  ClipboardList,
  LayoutDashboard,
  LogOut,
  MapPin,
  Menu,
  Sprout,
  Tractor,
  X,
} from 'lucide-react';
import { Link, NavLink, Navigate, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getMissingIntegrationRequirements } from '../services/apiConfig';

interface NavItem {
  to: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badgeCount?: number;
}

const ROUTE_TITLES: Record<string, string> = {
  '/app/farmer-dashboard': 'Farmer Dashboard',
  '/app/owner-dashboard': 'Equipment Owner Dashboard',
  '/app/equipment': 'Equipment Registry',
  '/app/plots': 'Plot Registry',
  '/app/bookings': 'Booking Management',
  '/app/scheduler': 'Smart Scheduler',
  '/app/emergencies': 'Emergency Management',
  '/app/notifications': 'Notifications',
};

export const AppLayout: React.FC = () => {
  const {
    user,
    initializing,
    isDemoMode,
    unreadNotifications,
    switchRoleDemo,
    toggleDemoMode,
    logout,
  } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  if (!isDemoMode && !initializing && !user) {
    return <Navigate to="/auth" replace />;
  }

  const activeUser = user ?? {
    id: 'usr-farmer-01',
    name: 'Rajesh Deshmukh',
    email: 'rajesh.deshmukh@krishisync.in',
    phone: '+91 98230 44120',
    role: 'farmer' as const,
    region: 'Baramati Cluster, Pune',
    organizationName: 'Sahyadri Progressive Farms',
    avatarInitials: 'RD',
    createdAt: '',
  };

  const navItems: NavItem[] = [
    {
      to: '/app/farmer-dashboard',
      label: 'Farmer Dashboard',
      icon: LayoutDashboard,
    },
    {
      to: '/app/owner-dashboard',
      label: 'Owner Dashboard',
      icon: Sprout,
    },
    {
      to: '/app/equipment',
      label: 'Equipment Registry',
      icon: Tractor,
    },
    {
      to: '/app/plots',
      label: 'Plot Registry',
      icon: MapPin,
    },
    {
      to: '/app/bookings',
      label: 'Bookings',
      icon: ClipboardList,
    },
    {
      to: '/app/scheduler',
      label: 'Smart Scheduler',
      icon: CalendarClock,
    },
    {
      to: '/app/emergencies',
      label: 'Emergencies',
      icon: AlertOctagon,
    },
    {
      to: '/app/notifications',
      label: 'Notifications',
      icon: Bell,
      badgeCount: unreadNotifications,
    },
  ];

  const currentPageTitle = ROUTE_TITLES[location.pathname] ?? 'Workspace';
  const missingReqs = getMissingIntegrationRequirements();

  const handleRoleSwitch = (role: 'farmer' | 'owner') => {
    switchRoleDemo(role);
    if (role === 'farmer' && location.pathname === '/app/owner-dashboard') {
      navigate('/app/farmer-dashboard');
    } else if (role === 'owner' && location.pathname === '/app/farmer-dashboard') {
      navigate('/app/owner-dashboard');
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const renderSidebarLinks = (onNavigate?: () => void) => (
    <nav className="flex-1 px-3 py-4 space-y-1" aria-label="Workspace navigation">
      {navItems.map((item) => {
        const Icon = item.icon;
        return (
          <NavLink
            key={item.to}
            to={item.to}
            onClick={onNavigate}
            className={({ isActive }) =>
              `flex items-center justify-between gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                isActive
                  ? 'bg-[#14532D] text-white'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`
            }
          >
            <span className="flex items-center gap-3 min-w-0">
              <Icon className="w-4 h-4 shrink-0" />
              <span className="truncate">{item.label}</span>
            </span>
            {typeof item.badgeCount === 'number' && item.badgeCount > 0 && (
              <span className="font-mono tabular-nums text-xs font-semibold px-1.5 py-0.5 rounded bg-emerald-600 text-white">
                {item.badgeCount}
              </span>
            )}
          </NavLink>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 border-r border-slate-200 bg-white">
        <div className="h-16 flex items-center px-6 border-b border-slate-200">
          <Link
            to="/"
            className="font-bold text-lg tracking-tight text-[#0B3B24] whitespace-nowrap"
          >
            KRISHISYNC
          </Link>
        </div>

        {renderSidebarLinks()}

        <div className="border-t border-slate-200 p-4 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#14532D] text-white flex items-center justify-center text-xs font-semibold shrink-0">
              {activeUser.avatarInitials}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-slate-900 truncate">
                {activeUser.name}
              </p>
              <p className="text-xs text-slate-500 truncate">
                {activeUser.role === 'farmer' ? 'Farmer Account' : 'Fleet Owner'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/40"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-10 w-72 max-w-[85vw] bg-white border-r border-slate-200 flex flex-col">
            <div className="h-16 flex items-center justify-between px-5 border-b border-slate-200">
              <Link
                to="/"
                className="font-bold text-lg tracking-tight text-[#0B3B24]"
                onClick={() => setMobileMenuOpen(false)}
              >
                KRISHISYNC
              </Link>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close navigation menu"
                className="p-2 text-slate-600 hover:text-slate-900 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            {renderSidebarLinks(() => setMobileMenuOpen(false))}
            <div className="border-t border-slate-200 p-4">
              <button
                type="button"
                onClick={handleLogout}
                className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Viewport */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <header className="h-16 sticky top-0 z-30 bg-white border-b border-slate-200 px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation menu"
              className="lg:hidden p-2 -ml-2 text-slate-600 hover:text-slate-900 rounded-lg"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="hidden sm:inline text-slate-400">Workspace</span>
              <span className="hidden sm:inline text-slate-300">/</span>
              <h1 className="font-semibold text-slate-900 truncate">{currentPageTitle}</h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {/* Functional role switcher for seamless hackathon walkthroughs */}
            <div
              className="hidden sm:flex items-center gap-1 p-1 bg-slate-100 rounded-lg"
              role="group"
              aria-label="Active workspace role"
            >
              <button
                type="button"
                onClick={() => handleRoleSwitch('farmer')}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  activeUser.role === 'farmer'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Farmer View
              </button>
              <button
                type="button"
                onClick={() => handleRoleSwitch('owner')}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  activeUser.role === 'owner'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Owner View
              </button>
            </div>

            <Link
              to="/app/bookings"
              className="px-3.5 py-2 text-xs font-medium text-white bg-[#14532D] hover:bg-[#0B3B24] rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              New Booking
            </Link>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1440px] w-full mx-auto space-y-5">
          {isDemoMode ? (
            <div className="rounded-xl border border-amber-200 bg-amber-50/70 px-4 py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-amber-900">
              <div>
                <span className="font-semibold">Demo Fallback Mode</span>
                <span className="mx-1.5" aria-hidden="true">·</span>
                <span>
                  {missingReqs.length > 0
                    ? `${missingReqs[0]} Showing separated demo dataset.`
                    : 'Running with separated demo fixtures.'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  toggleDemoMode(false);
                  window.location.reload();
                }}
                className="px-3 py-1 font-medium bg-white border border-amber-300 hover:bg-amber-100 rounded-md transition-colors whitespace-nowrap self-start sm:self-auto"
              >
                Switch to Live Backend
              </button>
            </div>
          ) : (
            missingReqs.length > 0 && (
              <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-red-900">
                <div>
                  <span className="font-semibold">Live Backend Mode Active</span>
                  <span className="mx-1.5" aria-hidden="true">·</span>
                  <span>{missingReqs[0]}</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    toggleDemoMode(true);
                    window.location.reload();
                  }}
                  className="px-3 py-1 font-medium bg-white border border-red-300 hover:bg-red-100 rounded-md transition-colors whitespace-nowrap self-start sm:self-auto"
                >
                  Enable Demo Fallback
                </button>
              </div>
            )
          )}
          <Outlet />
        </main>
      </div>
    </div>
  );
};
