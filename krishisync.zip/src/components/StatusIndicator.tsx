import React from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Info,
  Wrench,
  XCircle,
} from 'lucide-react';

export type SemanticTone = 'success' | 'warning' | 'danger' | 'info' | 'neutral';

interface StatusIndicatorProps {
  label: string;
  tone: SemanticTone;
}

const TONE_MAP: Record<
  SemanticTone,
  { text: string; Icon: React.ComponentType<{ className?: string }> }
> = {
  success: { text: 'text-emerald-700', Icon: CheckCircle2 },
  warning: { text: 'text-amber-700', Icon: Clock },
  danger: { text: 'text-red-700', Icon: AlertTriangle },
  info: { text: 'text-forest-800', Icon: Info },
  neutral: { text: 'text-slate-600', Icon: Wrench },
};

export function mapStatusToTone(status: string): SemanticTone {
  switch (status) {
    case 'Available':
    case 'Confirmed':
    case 'Completed':
    case 'Allocated':
    case 'Mitigated':
    case 'Applied':
      return 'success';
    case 'Pending':
    case 'Booked':
    case 'High':
    case 'Moderate':
    case 'Proposed':
    case 'Revised':
      return 'warning';
    case 'Maintenance':
    case 'Cancelled':
    case 'Disrupted':
    case 'Conflict':
    case 'Critical':
      return 'danger';
    case 'In Operation':
    case 'In Progress':
    case 'Scheduled':
    case 'Active':
      return 'info';
    default:
      return 'neutral';
  }
}

/**
 * Unboxed inline semantic status indicator (zero-pill discipline: icon + label, no capsule wrapper).
 */
export const StatusIndicator: React.FC<StatusIndicatorProps> = ({ label, tone }) => {
  const { text, Icon } = TONE_MAP[tone];
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-medium whitespace-nowrap ${text}`}>
      <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
      <span>{label}</span>
    </span>
  );
};
