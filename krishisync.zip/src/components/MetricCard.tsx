import React from 'react';

interface MetricCardProps {
  label: string;
  value: string | number;
  context: string;
  accent?: boolean;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  label,
  value,
  context,
  accent = false,
}) => {
  return (
    <div
      className={`rounded-xl border p-5 transition-colors ${
        accent
          ? 'border-emerald-200 bg-emerald-50/40'
          : 'border-slate-200 bg-white'
      }`}
    >
      <p className="text-xs font-medium text-slate-500 truncate">{label}</p>
      <p className="mt-2 text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 font-mono tabular-nums">
        {value}
      </p>
      <p className="mt-1.5 text-xs text-slate-600 truncate">{context}</p>
    </div>
  );
};
