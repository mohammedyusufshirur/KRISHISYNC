import { createClient, SupabaseClient } from '@supabase/supabase-js';

const rawSupabaseUrl =
  (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.trim() ?? '';
const rawSupabaseAnonKey =
  (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined)?.trim() ?? '';

export function isValidHttpUrl(value: string): boolean {
  if (!value) return false;
  try {
    const parsed = new URL(value);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

let clientInstance: SupabaseClient | null = null;
let initError: string | null = null;

if (rawSupabaseUrl || rawSupabaseAnonKey) {
  if (!isValidHttpUrl(rawSupabaseUrl)) {
    initError =
      'VITE_SUPABASE_URL is not a valid HTTP/HTTPS URL. Update your environment configuration.';
  } else if (!rawSupabaseAnonKey) {
    initError = 'VITE_SUPABASE_ANON_KEY is missing.';
  } else {
    try {
      clientInstance = createClient(rawSupabaseUrl, rawSupabaseAnonKey, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: true,
        },
      });
    } catch (err) {
      initError =
        err instanceof Error ? err.message : 'Failed to initialize Supabase client.';
      clientInstance = null;
    }
  }
}

export const isSupabaseEnvConfigured = Boolean(clientInstance);
export const supabaseConfigError: string | null = initError;

/**
 * Central Supabase Client Configuration
 * -------------------------------------
 * Uses ONLY the public client-safe anon key (`VITE_SUPABASE_ANON_KEY`).
 * Never reference `SUPABASE_SERVICE_ROLE_KEY` or private secrets in browser code.
 */
export const supabase: SupabaseClient | null = clientInstance;

export function requireSupabaseClient(): SupabaseClient {
  if (!supabase) {
    throw new Error(
      supabaseConfigError ??
        'Supabase client is not initialized. Set valid VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY values.'
    );
  }
  return supabase;
}
