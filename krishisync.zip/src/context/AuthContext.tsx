import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { subscribeToNotifications } from '../backend/services/notificationBackendService';
import { isDemoModeActive, setDemoModeActive } from '../services/apiConfig';
import { authService } from '../services/authService';
import { notificationService } from '../services/notificationService';
import {
  AuthSession,
  LoginCredentials,
  RegisterPayload,
  User,
  UserRole,
} from '../types/domain';

interface AuthContextValue {
  session: AuthSession | null;
  user: User | null;
  initializing: boolean;
  isDemoMode: boolean;
  unreadNotifications: number;
  login: (credentials: LoginCredentials) => Promise<AuthSession>;
  register: (payload: RegisterPayload) => Promise<AuthSession>;
  resetPassword: (email: string) => Promise<string>;
  switchRoleDemo: (role: UserRole) => AuthSession;
  toggleDemoMode: (enabled: boolean) => void;
  logout: () => Promise<void>;
  refreshUnreadCount: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<AuthSession | null>(() =>
    authService.getStoredSession()
  );
  const [initializing, setInitializing] = useState<boolean>(true);
  const [isDemoMode, setIsDemoMode] = useState<boolean>(() => isDemoModeActive());
  const [unreadNotifications, setUnreadNotifications] = useState<number>(0);

  const refreshUnreadCount = useCallback(async () => {
    try {
      const list = await notificationService.list();
      setUnreadNotifications(list.filter((n) => !n.read).length);
    } catch {
      setUnreadNotifications(0);
    }
  }, []);

  useEffect(() => {
    let mounted = true;
    authService
      .restoreSession()
      .then((restored) => {
        if (mounted && restored) {
          setSession(restored);
        }
      })
      .catch(() => {
        // Ignore session restore failure when backend env is unconfigured
      })
      .finally(() => {
        if (mounted) {
          setInitializing(false);
        }
      });

    const unsubscribe = authService.onAuthStateChange((nextSession) => {
      if (mounted) {
        setSession(nextSession);
        setIsDemoMode(isDemoModeActive());
      }
    });

    void refreshUnreadCount();
    return () => {
      mounted = false;
      unsubscribe();
    };
  }, [refreshUnreadCount]);

  // Subscribe to Supabase Realtime notifications when authenticated in live backend mode
  useEffect(() => {
    if (isDemoMode || !session?.user?.id) {
      return;
    }
    try {
      const unsubscribe = subscribeToNotifications(session.user.id, () => {
        void refreshUnreadCount();
      });
      return unsubscribe;
    } catch {
      return;
    }
  }, [isDemoMode, session?.user?.id, refreshUnreadCount]);

  const login = useCallback(async (credentials: LoginCredentials) => {
    const newSession = await authService.login(credentials);
    setSession(newSession);
    setIsDemoMode(isDemoModeActive());
    return newSession;
  }, []);

  const register = useCallback(async (payload: RegisterPayload) => {
    const newSession = await authService.register(payload);
    setSession(newSession);
    setIsDemoMode(isDemoModeActive());
    return newSession;
  }, []);

  const resetPassword = useCallback(async (email: string) => {
    return authService.resetPassword(email);
  }, []);

  const switchRoleDemo = useCallback((role: UserRole) => {
    const next = authService.switchRoleDemo(role);
    setSession(next);
    setIsDemoMode(true);
    return next;
  }, []);

  const toggleDemoMode = useCallback((enabled: boolean) => {
    setDemoModeActive(enabled);
    setIsDemoMode(enabled);
  }, []);

  const logout = useCallback(async () => {
    await authService.logout();
    setSession(null);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        session,
        user: session?.user ?? null,
        initializing,
        isDemoMode,
        unreadNotifications,
        login,
        register,
        resetPassword,
        switchRoleDemo,
        toggleDemoMode,
        logout,
        refreshUnreadCount,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return ctx;
}
