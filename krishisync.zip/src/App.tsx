/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AppLayout } from './components/AppLayout';
import { AuthProvider } from './context/AuthContext';
import { AuthPage } from './pages/AuthPage';
import { BookingsPage } from './pages/BookingsPage';
import { EmergencyManagementPage } from './pages/EmergencyManagementPage';
import { EquipmentRegistryPage } from './pages/EquipmentRegistryPage';
import { FarmerDashboardPage } from './pages/FarmerDashboardPage';
import { LandingPage } from './pages/LandingPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { OwnerDashboardPage } from './pages/OwnerDashboardPage';
import { PlotRegistryPage } from './pages/PlotRegistryPage';
import { SmartSchedulerPage } from './pages/SmartSchedulerPage';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/auth" element={<AuthPage />} />

          <Route path="/app" element={<AppLayout />}>
            <Route index element={<Navigate to="/app/farmer-dashboard" replace />} />
            <Route path="farmer-dashboard" element={<FarmerDashboardPage />} />
            <Route path="owner-dashboard" element={<OwnerDashboardPage />} />
            <Route path="equipment" element={<EquipmentRegistryPage />} />
            <Route path="plots" element={<PlotRegistryPage />} />
            <Route path="bookings" element={<BookingsPage />} />
            <Route path="scheduler" element={<SmartSchedulerPage />} />
            <Route path="emergencies" element={<EmergencyManagementPage />} />
            <Route path="notifications" element={<NotificationsPage />} />
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
