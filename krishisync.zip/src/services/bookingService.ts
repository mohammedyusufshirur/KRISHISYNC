import { INITIAL_BOOKINGS, OWNER_REVENUE_UTILIZATION_DEMO } from '../data/mockData';
import { requireSupabaseClient } from '../lib/supabaseClient';
import {
  Booking,
  BookingInput,
  BookingPriority,
  BookingStatus,
  OperationType,
  OwnerDashboardData,
} from '../types/domain';
import { isDemoModeActive, simulateNetworkDelay } from './apiConfig';
import { requireVerifiedTable } from './backendContract';
import { equipmentService, toFrontendEquipmentType } from './equipmentService';
import { plotService } from './plotService';

let demoBookingStore: Booking[] = [...INITIAL_BOOKINGS];

function haversineDistanceKm(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number }
): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const sinLat = Math.sin(dLat / 2);
  const sinLng = Math.sin(dLng / 2);
  const h =
    sinLat * sinLat + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * sinLng * sinLng;
  return Math.round(2 * R * Math.asin(Math.sqrt(h)) * 10) / 10;
}

function toFrontendBookingPriority(score: number): BookingPriority {
  if (score >= 80) return 'Critical';
  if (score >= 60) return 'High';
  return 'Standard';
}

function toDbPriorityScore(priority: BookingPriority): number {
  if (priority === 'Critical') return 90;
  if (priority === 'High') return 70;
  return 50;
}

function toFrontendBookingStatus(raw: unknown): BookingStatus {
  switch (String(raw ?? '').toLowerCase()) {
    case 'accepted':
      return 'Confirmed';
    case 'scheduled':
      return 'Scheduled';
    case 'in_progress':
      return 'In Progress';
    case 'completed':
      return 'Completed';
    case 'cancelled':
    case 'rejected':
      return 'Cancelled';
    case 'rescheduling_required':
      return 'Disrupted';
    default:
      return 'Pending';
  }
}

function toDbBookingStatus(status: BookingStatus): string {
  switch (status) {
    case 'Confirmed':
      return 'accepted';
    case 'Scheduled':
      return 'scheduled';
    case 'In Progress':
      return 'in_progress';
    case 'Completed':
      return 'completed';
    case 'Cancelled':
      return 'cancelled';
    case 'Disrupted':
      return 'rescheduling_required';
    default:
      return 'pending';
  }
}

const BOOKING_SELECT =
  '*, farmer:profiles(full_name), equipment(owner_id, equipment_name, equipment_type, hourly_rate, latitude, longitude, owner:profiles(full_name)), plots(plot_name, area_acres, latitude, longitude)';

function mapBookingRow(
  row: Record<string, unknown>,
  cols: {
    id: string;
    farmerId: string;
    equipmentId: string;
    plotId: string;
    operationType: string;
    requestedDate: string;
    deadline: string;
    estimatedDurationHours: string;
    priorityScore: string;
    status: string;
  }
): Booking {
  const joinedFarmer = (row.farmer ?? {}) as Record<string, unknown>;
  const joinedEq = (row.equipment ?? {}) as Record<string, unknown>;
  const joinedOwner = (joinedEq.owner ?? {}) as Record<string, unknown>;
  const joinedPlot = (row.plots ?? {}) as Record<string, unknown>;
  const estHours = Number(row[cols.estimatedDurationHours] ?? row.estimated_hours ?? 1);
  const hourlyRate = Number(joinedEq.hourly_rate ?? 0);
  const priorityScore = Number(row[cols.priorityScore] ?? 50);

  const eqLat = Number(joinedEq.latitude);
  const eqLng = Number(joinedEq.longitude);
  const plotLat = Number(joinedPlot.latitude);
  const plotLng = Number(joinedPlot.longitude);
  const computedDistance =
    !Number.isNaN(eqLat) &&
    !Number.isNaN(eqLng) &&
    !Number.isNaN(plotLat) &&
    !Number.isNaN(plotLng)
      ? haversineDistanceKm({ lat: eqLat, lng: eqLng }, { lat: plotLat, lng: plotLng })
      : 0;

  return {
    id: String(row[cols.id]),
    farmerId: String(row[cols.farmerId] ?? ''),
    farmerName: String(joinedFarmer.full_name ?? row.farmer_name ?? 'Farmer'),
    ownerId: String(joinedEq.owner_id ?? row.owner_id ?? ''),
    ownerName: String(joinedOwner.full_name ?? row.owner_name ?? 'Fleet Owner'),
    equipmentId: String(row[cols.equipmentId] ?? ''),
    equipmentName: String(joinedEq.equipment_name ?? row.equipment_name ?? 'Equipment'),
    equipmentCategory: toFrontendEquipmentType(joinedEq.equipment_type ?? row.equipment_category),
    plotId: String(row[cols.plotId] ?? ''),
    plotName: String(joinedPlot.plot_name ?? row.plot_name ?? 'Registered Plot'),
    plotAreaAcres: Number(joinedPlot.area_acres ?? row.plot_area_acres ?? 0),
    operationType: (row[cols.operationType] as OperationType) ?? 'Sowing',
    requestedDate: String(row[cols.requestedDate] ?? '').slice(0, 10),
    deadline: String(row[cols.deadline] ?? '').slice(0, 10),
    estimatedHours: estHours,
    estimatedCostInr:
      row.estimated_cost_inr !== undefined
        ? Number(row.estimated_cost_inr)
        : Math.round(estHours * hourlyRate),
    priority: toFrontendBookingPriority(priorityScore),
    status: toFrontendBookingStatus(row[cols.status]),
    travelDistanceKm: Number(row.travel_distance_km ?? computedDistance),
    notes: typeof row.rejection_reason === 'string' ? row.rejection_reason : undefined,
    createdAt: String(row.created_at ?? new Date().toISOString()),
  };
}

export const bookingService = {
  async list(): Promise<Booking[]> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('bookings');
      const { data, error } = await client
        .from(tableName)
        .select(BOOKING_SELECT)
        .order('created_at', { ascending: false });
      if (error) {
        throw new Error(`Failed to fetch bookings from ${tableName}: ${error.message}`);
      }
      return ((data ?? []) as Record<string, unknown>[]).map((r) =>
        mapBookingRow(r, columns)
      );
    }

    await simulateNetworkDelay(160);
    return [...demoBookingStore];
  },

  async create(
    input: BookingInput,
    farmerId: string,
    farmerName: string
  ): Promise<Booking> {
    if (!input.equipmentId || !input.plotId || !input.requestedDate || !input.deadline) {
      throw new Error('Equipment, plot, requested date, and deadline are required.');
    }
    if (input.deadline < input.requestedDate) {
      throw new Error('Operational deadline cannot be earlier than the requested date.');
    }

    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('bookings');
      const { data, error } = await client.rpc('create_booking_request', {
        p_equipment_id: input.equipmentId,
        p_plot_id: input.plotId,
        p_operation_type: input.operationType,
        p_requested_start_time: `${input.requestedDate}T08:00:00Z`,
        p_requested_deadline: `${input.deadline}T18:00:00Z`,
        p_priority_score: toDbPriorityScore(input.priority),
      });
      if (error) {
        throw new Error(`Failed to create booking: ${error.message}`);
      }
      const createdId = (data as Record<string, unknown>)?.id;
      if (createdId) {
        const { data: hydrated } = await client
          .from(tableName)
          .select(BOOKING_SELECT)
          .eq(columns.id, createdId)
          .maybeSingle();
        if (hydrated) {
          return mapBookingRow(hydrated as Record<string, unknown>, columns);
        }
      }
      return mapBookingRow(data as Record<string, unknown>, columns);
    }

    const eq = equipmentService.getSnapshot().find((e) => e.id === input.equipmentId);
    const plot = plotService.getSnapshot().find((p) => p.id === input.plotId);

    if (!eq || !plot) {
      throw new Error('Selected equipment or plot could not be found.');
    }
    if (eq.status === 'Maintenance') {
      throw new Error(
        `${eq.name} is currently under maintenance and cannot accept new bookings.`
      );
    }

    const overlapping = demoBookingStore.find(
      (b) =>
        b.equipmentId === eq.id &&
        b.status !== 'Cancelled' &&
        b.status !== 'Completed' &&
        b.requestedDate === input.requestedDate
    );
    if (overlapping) {
      throw new Error(
        `Conflict detected: ${eq.name} already has booking ${overlapping.id} (${overlapping.plotName}) on ${input.requestedDate}.`
      );
    }

    await simulateNetworkDelay(200);
    const estimatedHours = Math.max(
      1,
      Math.ceil(plot.areaAcres / Math.max(0.5, eq.workCapacityAcresPerHr))
    );
    const estimatedCostInr = estimatedHours * eq.hourlyRateInr;
    const travelDistanceKm = haversineDistanceKm(eq.coordinates, plot.coordinates);

    const created: Booking = {
      id: `bk-${Date.now().toString().slice(-3)}`,
      farmerId,
      farmerName,
      ownerId: eq.ownerId,
      ownerName: eq.ownerName,
      equipmentId: eq.id,
      equipmentName: eq.name,
      equipmentCategory: eq.category,
      plotId: plot.id,
      plotName: plot.name,
      plotAreaAcres: plot.areaAcres,
      operationType: input.operationType,
      requestedDate: input.requestedDate,
      deadline: input.deadline,
      estimatedHours,
      estimatedCostInr,
      priority: input.priority,
      status: 'Pending',
      travelDistanceKm,
      notes: input.notes,
      createdAt: new Date().toISOString(),
    };

    demoBookingStore = [created, ...demoBookingStore];
    return created;
  },

  async updateStatus(id: string, status: BookingStatus): Promise<Booking> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('bookings');
      if (status === 'Confirmed') {
        const { data, error } = await client.rpc('respond_to_booking', {
          p_booking_id: id,
          p_decision: 'accept',
          p_rejection_reason: null,
        });
        if (error) {
          throw new Error(`Failed to confirm booking ${id}: ${error.message}`);
        }
        const { data: hydrated } = await client
          .from(tableName)
          .select(BOOKING_SELECT)
          .eq(columns.id, id)
          .maybeSingle();
        return mapBookingRow((hydrated ?? data) as Record<string, unknown>, columns);
      }

      if (status === 'Cancelled') {
        const [{ data: authData }, { data: currentRow }] = await Promise.all([
          client.auth.getUser(),
          client
            .from(tableName)
            .select('id, status, equipment(owner_id)')
            .eq(columns.id, id)
            .maybeSingle(),
        ]);
        const currentOwnerId = (
          (currentRow as Record<string, unknown> | null)?.equipment as
            | Record<string, unknown>
            | undefined
        )?.owner_id;
        if (
          authData.user?.id &&
          currentOwnerId === authData.user.id &&
          currentRow?.status === 'pending'
        ) {
          const { data, error } = await client.rpc('respond_to_booking', {
            p_booking_id: id,
            p_decision: 'reject',
            p_rejection_reason: 'Declined by equipment owner',
          });
          if (error) {
            throw new Error(`Failed to decline booking ${id}: ${error.message}`);
          }
          const { data: hydrated } = await client
            .from(tableName)
            .select(BOOKING_SELECT)
            .eq(columns.id, id)
            .maybeSingle();
          return mapBookingRow((hydrated ?? data) as Record<string, unknown>, columns);
        }
      }

      const { data, error } = await client
        .from(tableName)
        .update({ [columns.status]: toDbBookingStatus(status) })
        .eq(columns.id, id)
        .select(BOOKING_SELECT)
        .single();
      if (error) {
        throw new Error(`Failed to update booking ${id} status: ${error.message}`);
      }
      return mapBookingRow(data as Record<string, unknown>, columns);
    }

    await simulateNetworkDelay(160);
    const existing = demoBookingStore.find((b) => b.id === id);
    if (!existing) {
      throw new Error(`Booking ${id} not found.`);
    }
    const updated: Booking = { ...existing, status };
    demoBookingStore = demoBookingStore.map((b) => (b.id === id ? updated : b));
    return updated;
  },

  async reassignEquipment(
    id: string,
    newEquipmentId: string,
    newEquipmentName: string
  ): Promise<Booking> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('bookings');
      const { data, error } = await client
        .from(tableName)
        .update({
          [columns.equipmentId]: newEquipmentId,
          [columns.status]: 'scheduled',
        })
        .eq(columns.id, id)
        .select(BOOKING_SELECT)
        .single();
      if (error) {
        throw new Error(`Failed to reassign booking ${id}: ${error.message}`);
      }
      return mapBookingRow(data as Record<string, unknown>, columns);
    }

    await simulateNetworkDelay(160);
    const existing = demoBookingStore.find((b) => b.id === id);
    if (!existing) throw new Error(`Booking ${id} not found.`);
    const updated: Booking = {
      ...existing,
      equipmentId: newEquipmentId,
      equipmentName: newEquipmentName,
      status: 'Scheduled',
    };
    demoBookingStore = demoBookingStore.map((b) => (b.id === id ? updated : b));
    return updated;
  },

  async getOwnerDashboardData(): Promise<OwnerDashboardData> {
    if (!isDemoModeActive()) {
      const [equipment, bookings] = await Promise.all([
        equipmentService.list(),
        this.list(),
      ]);

      const monthlyBuckets = new Map<string, { revenueInr: number; count: number }>();
      bookings.forEach((b) => {
        const month = new Date(b.requestedDate).toLocaleString('en-US', { month: 'short' });
        if (month !== 'Invalid Date') {
          const prev = monthlyBuckets.get(month) ?? { revenueInr: 0, count: 0 };
          monthlyBuckets.set(month, {
            revenueInr: prev.revenueInr + b.estimatedCostInr,
            count: prev.count + 1,
          });
        }
      });

      const revenueUtilizationChart = Array.from(monthlyBuckets.entries()).map(
        ([month, val]) => ({
          month,
          revenueInr: val.revenueInr,
          utilizationPercent: Math.min(100, val.count * 15),
        })
      );

      return {
        metrics: {
          registeredMachines: equipment.length,
          availableEquipment: equipment.filter((e) => e.status === 'Available').length,
          pendingRequests: bookings.filter((b) => b.status === 'Pending').length,
          upcomingSchedules: bookings.filter(
            (b) =>
              b.status === 'Confirmed' ||
              b.status === 'Scheduled' ||
              b.status === 'In Progress'
          ).length,
        },
        revenueUtilizationChart,
      };
    }

    await simulateNetworkDelay(180);
    const equipment = equipmentService.getSnapshot();
    const bookings = [...demoBookingStore];

    return {
      metrics: {
        registeredMachines: equipment.length,
        availableEquipment: equipment.filter((e) => e.status === 'Available').length,
        pendingRequests: bookings.filter((b) => b.status === 'Pending').length,
        upcomingSchedules: bookings.filter(
          (b) => b.status === 'Confirmed' || b.status === 'Scheduled' || b.status === 'In Progress'
        ).length,
      },
      revenueUtilizationChart: OWNER_REVENUE_UTILIZATION_DEMO,
    };
  },

  getSnapshot(): Booking[] {
    return [...demoBookingStore];
  },
};
