/**
 * Backend Schema & API Contract Registry
 * --------------------------------------
 * Populated strictly with the exact Supabase PostgreSQL table names and columns
 * defined in `supabase/migrations/001` through `006` (Member 2 Backend).
 * Scheduling Engine HTTP endpoints (`schedulerEndpoints`) remain `verified: false`
 * until Member 3 supplies their external Scheduling Engine API route paths.
 */

export interface TableContract<TColumns extends Record<string, string>> {
  verified: boolean;
  tableName: string | null;
  columns: TColumns | null;
}

export interface EndpointContract {
  verified: boolean;
  method: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
  path: string | null;
}

export interface BackendContractRegistry {
  tables: {
    profiles: TableContract<{
      id: string;
      name: string;
      email: string;
      phone: string;
      role: string;
      address: string;
      latitude: string;
      longitude: string;
    }>;
    equipment: TableContract<{
      id: string;
      ownerId: string;
      name: string;
      category: string;
      brand: string;
      model: string;
      description: string;
      workCapacityAcresPerHr: string;
      hourlyRateInr: string;
      perAcreRateInr: string;
      lat: string;
      lng: string;
      location: string;
      status: string;
    }>;
    plots: TableContract<{
      id: string;
      farmerId: string;
      name: string;
      areaAcres: string;
      cropType: string;
      operationType: string;
      lat: string;
      lng: string;
      locationLabel: string;
      preferredStartTime: string;
      deadline: string;
    }>;
    bookings: TableContract<{
      id: string;
      farmerId: string;
      equipmentId: string;
      plotId: string;
      operationType: string;
      requestedDate: string;
      deadline: string;
      estimatedDurationHours: string;
      priorityScore: string;
      status: string;
      assignedStartTime: string;
      assignedEndTime: string;
      rejectionReason: string;
    }>;
    schedules: TableContract<{
      id: string;
      bookingId: string;
      equipmentId: string;
      farmerId: string;
      plotId: string;
      scheduledStart: string;
      scheduledEnd: string;
      travelBufferMinutes: string;
      estimatedTravelDistanceKm: string;
      status: string;
      schedulingReason: string;
    }>;
    disruptions: TableContract<{
      id: string;
      equipmentId: string;
      type: string;
      description: string;
      startTime: string;
      endTime: string;
      affectedRegion: string;
      status: string;
      reportedBy: string;
    }>;
    notifications: TableContract<{
      id: string;
      userId: string;
      title: string;
      message: string;
      category: string;
      relatedBookingId: string;
      read: string;
    }>;
  };
  schedulerEndpoints: {
    getCurrentSchedule: EndpointContract;
    generateSchedule: EndpointContract;
    resolveConflict: EndpointContract;
    reportDisruptionReschedule: EndpointContract;
    applyRevisedSchedule: EndpointContract;
  };
}

export const BACKEND_CONTRACT: BackendContractRegistry = {
  tables: {
    profiles: {
      verified: true,
      tableName: 'profiles',
      columns: {
        id: 'id',
        name: 'full_name',
        email: 'email',
        phone: 'phone',
        role: 'role',
        address: 'address',
        latitude: 'latitude',
        longitude: 'longitude',
      },
    },
    equipment: {
      verified: true,
      tableName: 'equipment',
      columns: {
        id: 'id',
        ownerId: 'owner_id',
        name: 'equipment_name',
        category: 'equipment_type',
        brand: 'brand',
        model: 'model',
        description: 'description',
        workCapacityAcresPerHr: 'work_rate_acres_per_hour',
        hourlyRateInr: 'hourly_rate',
        perAcreRateInr: 'per_acre_rate',
        lat: 'latitude',
        lng: 'longitude',
        location: 'address',
        status: 'availability_status',
      },
    },
    plots: {
      verified: true,
      tableName: 'plots',
      columns: {
        id: 'id',
        farmerId: 'farmer_id',
        name: 'plot_name',
        areaAcres: 'area_acres',
        cropType: 'crop_type',
        operationType: 'operation_type',
        lat: 'latitude',
        lng: 'longitude',
        locationLabel: 'address',
        preferredStartTime: 'preferred_start_time',
        deadline: 'deadline',
      },
    },
    bookings: {
      verified: true,
      tableName: 'bookings',
      columns: {
        id: 'id',
        farmerId: 'farmer_id',
        equipmentId: 'equipment_id',
        plotId: 'plot_id',
        operationType: 'operation_type',
        requestedDate: 'requested_start_time',
        deadline: 'requested_deadline',
        estimatedDurationHours: 'estimated_duration_hours',
        priorityScore: 'priority_score',
        status: 'status',
        assignedStartTime: 'assigned_start_time',
        assignedEndTime: 'assigned_end_time',
        rejectionReason: 'rejection_reason',
      },
    },
    schedules: {
      verified: true,
      tableName: 'schedules',
      columns: {
        id: 'id',
        bookingId: 'booking_id',
        equipmentId: 'equipment_id',
        farmerId: 'farmer_id',
        plotId: 'plot_id',
        scheduledStart: 'scheduled_start',
        scheduledEnd: 'scheduled_end',
        travelBufferMinutes: 'travel_buffer_minutes',
        estimatedTravelDistanceKm: 'estimated_travel_distance_km',
        status: 'status',
        schedulingReason: 'scheduling_reason',
      },
    },
    disruptions: {
      verified: true,
      tableName: 'disruptions',
      columns: {
        id: 'id',
        equipmentId: 'equipment_id',
        type: 'disruption_type',
        description: 'description',
        startTime: 'start_time',
        endTime: 'end_time',
        affectedRegion: 'affected_area',
        status: 'status',
        reportedBy: 'reported_by',
      },
    },
    notifications: {
      verified: true,
      tableName: 'notifications',
      columns: {
        id: 'id',
        userId: 'user_id',
        title: 'title',
        message: 'message',
        category: 'notification_type',
        relatedBookingId: 'related_booking_id',
        read: 'is_read',
      },
    },
  },
  schedulerEndpoints: {
    getCurrentSchedule: { verified: false, method: 'GET', path: null },
    generateSchedule: { verified: false, method: 'POST', path: null },
    resolveConflict: { verified: false, method: 'POST', path: null },
    reportDisruptionReschedule: { verified: false, method: 'POST', path: null },
    applyRevisedSchedule: { verified: false, method: 'POST', path: null },
  },
};

export class MissingBackendContractError extends Error {
  readonly contractKey: string;
  constructor(contractKey: string, detail: string) {
    super(`Backend contract pending for "${contractKey}": ${detail}`);
    this.name = 'MissingBackendContractError';
    this.contractKey = contractKey;
  }
}

export function requireVerifiedTable<K extends keyof BackendContractRegistry['tables']>(
  key: K
): { tableName: string; columns: NonNullable<BackendContractRegistry['tables'][K]['columns']> } {
  const entry = BACKEND_CONTRACT.tables[key];
  if (!entry.verified || !entry.tableName || !entry.columns) {
    throw new MissingBackendContractError(
      `supabase.tables.${key}`,
      'Exact Supabase table name and column mappings have not been supplied by the backend developer.'
    );
  }
  return { tableName: entry.tableName, columns: entry.columns };
}

export function requireVerifiedSchedulerEndpoint(
  key: keyof BackendContractRegistry['schedulerEndpoints']
): { method: EndpointContract['method']; path: string } {
  const entry = BACKEND_CONTRACT.schedulerEndpoints[key];
  if (!entry.verified || !entry.path) {
    throw new MissingBackendContractError(
      `scheduler.${key}`,
      'Exact Scheduling API endpoint path and request/response contract have not been supplied by Member 3.'
    );
  }
  return { method: entry.method, path: entry.path };
}
