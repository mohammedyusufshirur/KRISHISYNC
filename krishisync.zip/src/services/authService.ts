import type { Session as SupabaseSession, User as SupabaseUser } from '@supabase/supabase-js';
import { INITIAL_USERS } from '../data/mockData';
import { isSupabaseEnvConfigured, requireSupabaseClient, supabase } from '../lib/supabaseClient';
import { AuthSession, LoginCredentials, RegisterPayload, User, UserRole } from '../types/domain';
import { BACKEND_CONTRACT } from './backendContract';
import { isDemoModeActive, setDemoModeActive, simulateNetworkDelay } from './apiConfig';

const SESSION_STORAGE_KEY = 'krishisync_session_v1';
let demoUsers: User[] = [...INITIAL_USERS];

function toFrontendRole(rawRole: unknown, fallbackRole?: UserRole): UserRole {
  if (rawRole === 'owner' || rawRole === 'equipment_owner') return 'owner';
  if (rawRole === 'farmer') return 'farmer';
  return fallbackRole ?? 'farmer';
}

function toDbRole(role: UserRole): 'farmer' | 'equipment_owner' {
  return role === 'owner' ? 'equipment_owner' : 'farmer';
}

function mapSupabaseUser(sbUser: SupabaseUser, fallbackRole?: UserRole): User {
  const meta = (sbUser.user_metadata ?? {}) as Record<string, unknown>;
  const fullName =
    (typeof meta.full_name === 'string' && meta.full_name.trim()) ||
    (typeof meta.name === 'string' && meta.name.trim()) ||
    sbUser.email?.split('@')[0] ||
    'KRISHISYNC User';
  const role = toFrontendRole(meta.role, fallbackRole);
  const initials = fullName
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? '')
    .join('');

  return {
    id: sbUser.id,
    name: fullName,
    email: sbUser.email ?? '',
    phone: typeof meta.phone === 'string' ? meta.phone : '',
    role,
    region:
      (typeof meta.address === 'string' && meta.address) ||
      (typeof meta.region === 'string' ? meta.region : ''),
    organizationName:
      typeof meta.organizationName === 'string' ? meta.organizationName : '',
    avatarInitials: initials || 'KS',
    createdAt: sbUser.created_at ?? new Date().toISOString(),
  };
}

function mapSupabaseSession(sbSession: SupabaseSession, fallbackRole?: UserRole): AuthSession {
  return {
    user: mapSupabaseUser(sbSession.user, fallbackRole),
    accessToken: sbSession.access_token,
    expiresAt: sbSession.expires_at
      ? new Date(sbSession.expires_at * 1000).toISOString()
      : new Date(Date.now() + 1000 * 60 * 60 * 12).toISOString(),
  };
}

async function syncVerifiedProfileRow(user: User): Promise<User> {
  const contract = BACKEND_CONTRACT.tables.profiles;
  if (!supabase || !contract.verified || !contract.tableName || !contract.columns) {
    return user;
  }

  const cols = contract.columns;
  const { data, error } = await supabase
    .from(contract.tableName)
    .select('*')
    .eq(cols.id, user.id)
    .maybeSingle();

  if (error) {
    throw new Error(`Failed to fetch profile from ${contract.tableName}: ${error.message}`);
  }

  if (data) {
    const row = data as Record<string, unknown>;
    return {
      ...user,
      name: String(row[cols.name] ?? user.name),
      email: String(row[cols.email] ?? user.email),
      phone: String(row[cols.phone] ?? user.phone),
      role: toFrontendRole(row[cols.role], user.role),
      region: String(row[cols.address] ?? user.region),
    };
  }

  const insertPayload: Record<string, unknown> = {
    [cols.id]: user.id,
    [cols.name]: user.name,
    [cols.email]: user.email,
    [cols.phone]: user.phone,
    [cols.role]: toDbRole(user.role),
    [cols.address]: user.region,
  };

  const { error: upsertError } = await supabase
    .from(contract.tableName)
    .upsert(insertPayload);

  if (upsertError) {
    throw new Error(`Failed to save profile to ${contract.tableName}: ${upsertError.message}`);
  }

  return user;
}

export const authService = {
  getStoredSession(): AuthSession | null {
    try {
      const raw = localStorage.getItem(SESSION_STORAGE_KEY);
      if (!raw) return null;
      return JSON.parse(raw) as AuthSession;
    } catch {
      return null;
    }
  },

  async restoreSession(): Promise<AuthSession | null> {
    if (isSupabaseEnvConfigured && supabase && !isDemoModeActive()) {
      const { data, error } = await supabase.auth.getSession();
      if (error) {
        throw new Error(error.message);
      }
      if (!data.session) {
        localStorage.removeItem(SESSION_STORAGE_KEY);
        return null;
      }
      const mapped = mapSupabaseSession(data.session);
      mapped.user = await syncVerifiedProfileRow(mapped.user);
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(mapped));
      return mapped;
    }
    return this.getStoredSession();
  },

  onAuthStateChange(callback: (session: AuthSession | null) => void): () => void {
    if (!supabase) return () => {};
    const { data } = supabase.auth.onAuthStateChange((_event, sbSession) => {
      if (!sbSession) {
        if (!isDemoModeActive()) {
          localStorage.removeItem(SESSION_STORAGE_KEY);
          callback(null);
        }
        return;
      }
      const mapped = mapSupabaseSession(sbSession);
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(mapped));
      callback(mapped);
    });
    return () => data.subscription.unsubscribe();
  },

  async login(credentials: LoginCredentials): Promise<AuthSession> {
    if (!credentials.email.trim() || !credentials.password.trim()) {
      throw new Error('Email and password are required.');
    }

    if (isSupabaseEnvConfigured) {
      const client = requireSupabaseClient();
      const { data, error } = await client.auth.signInWithPassword({
        email: credentials.email.trim(),
        password: credentials.password,
      });

      if (error) {
        throw new Error(error.message);
      }
      if (!data.session) {
        throw new Error('Supabase did not return an active session.');
      }

      setDemoModeActive(false);
      const session = mapSupabaseSession(data.session, credentials.role);
      session.user = await syncVerifiedProfileRow(session.user);
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
      return session;
    }

    if (!isDemoModeActive()) {
      throw new Error(
        'Supabase environment variables (VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY) are not configured.'
      );
    }

    await simulateNetworkDelay(240);
    const matched = demoUsers.find(
      (u) => u.email.toLowerCase() === credentials.email.trim().toLowerCase()
    );
    const user: User = matched
      ? { ...matched, role: credentials.role }
      : {
          id: `usr-${credentials.role}-demo`,
          name: credentials.role === 'farmer' ? 'Rajesh Deshmukh' : 'Vikramjit Singh Gill',
          email: credentials.email.trim(),
          phone: '+91 98230 44120',
          role: credentials.role,
          region: 'Baramati Cluster, Pune',
          organizationName:
            credentials.role === 'farmer'
              ? 'Sahyadri Progressive Farms'
              : 'Gill Agro Fleet Services',
          avatarInitials: credentials.role === 'farmer' ? 'RD' : 'VG',
          createdAt: new Date().toISOString(),
        };

    const session: AuthSession = {
      user,
      accessToken: `demo_session_${Date.now()}`,
      expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 12).toISOString(),
    };

    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
    return session;
  },

  async register(payload: RegisterPayload): Promise<AuthSession> {
    if (!payload.name.trim() || !payload.email.trim() || payload.password.length < 6) {
      throw new Error(
        'Please complete all required fields with a password of at least 6 characters.'
      );
    }

    if (isSupabaseEnvConfigured) {
      const client = requireSupabaseClient();
      const { data, error } = await client.auth.signUp({
        email: payload.email.trim(),
        password: payload.password,
        options: {
          data: {
            full_name: payload.name.trim(),
            name: payload.name.trim(),
            phone: payload.phone.trim(),
            role: toDbRole(payload.role),
            address: payload.region.trim(),
            organizationName: payload.organizationName.trim(),
          },
        },
      });

      if (error) {
        throw new Error(error.message);
      }

      if (!data.session) {
        throw new Error(
          'Registration succeeded. Please verify your email address before signing in.'
        );
      }

      setDemoModeActive(false);
      const session = mapSupabaseSession(data.session, payload.role);
      session.user = await syncVerifiedProfileRow(session.user);
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
      return session;
    }

    if (!isDemoModeActive()) {
      throw new Error(
        'Supabase environment variables (VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY) are not configured.'
      );
    }

    await simulateNetworkDelay(280);
    const initials = payload.name
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase() ?? '')
      .join('');

    const newUser: User = {
      id: `usr-${payload.role}-${Date.now()}`,
      name: (payload.name ?? '').trim(),
      email: (payload.email ?? '').trim(),
      phone: (payload.phone ?? '').trim(),
      role: payload.role,
      region: (payload.region ?? '').trim() || 'Baramati Cluster, Pune',
      organizationName: (payload.organizationName ?? '').trim() || `${(payload.name ?? '').trim()} Farms`,
      avatarInitials: initials || 'KS',
      createdAt: new Date().toISOString(),
    };

    demoUsers = [newUser, ...demoUsers];
    const session: AuthSession = {
      user: newUser,
      accessToken: `demo_session_${Date.now()}`,
      expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 12).toISOString(),
    };

    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
    return session;
  },

  async resetPassword(email: string): Promise<string> {
    if (!email.trim()) {
      throw new Error('Enter your registered email address to reset your password.');
    }
    if (isSupabaseEnvConfigured) {
      const client = requireSupabaseClient();
      const { error } = await client.auth.resetPasswordForEmail(email.trim(), {
        redirectTo: `${window.location.origin}/auth`,
      });
      if (error) {
        throw new Error(error.message);
      }
      return `Password reset instructions sent to ${email.trim()}.`;
    }
    await simulateNetworkDelay(160);
    return `Demo mode: password reset simulated for ${email.trim()}.`;
  },

  switchRoleDemo(role: UserRole): AuthSession {
    setDemoModeActive(true);
    const template = INITIAL_USERS.find((u) => u.role === role) ?? INITIAL_USERS[0];
    const session: AuthSession = {
      user: { ...template, role },
      accessToken: `demo_session_${Date.now()}`,
      expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 12).toISOString(),
    };
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
    return session;
  },

  async logout(): Promise<void> {
    if (supabase) {
      await supabase.auth.signOut().catch(() => {});
    }
    localStorage.removeItem(SESSION_STORAGE_KEY);
  },
};
