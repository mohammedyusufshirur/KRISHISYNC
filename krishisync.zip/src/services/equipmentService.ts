import { DEMO_IMAGES, INITIAL_EQUIPMENT } from '../data/mockData';
import { requireSupabaseClient } from '../lib/supabaseClient';
import { Equipment, EquipmentCategory, EquipmentInput, EquipmentStatus } from '../types/domain';
import { isDemoModeActive, simulateNetworkDelay } from './apiConfig';
import { requireVerifiedTable } from './backendContract';

let demoEquipmentStore: Equipment[] = [...INITIAL_EQUIPMENT];

export function toFrontendEquipmentType(raw: unknown): EquipmentCategory {
  switch (String(raw ?? '')) {
    case 'Harvester':
      return 'Harvester';
    case 'Sprayer':
    case 'Sprayer Drone':
      return 'Sprayer Drone';
    case 'Seeder':
    case 'Planter & Seeder':
      return 'Planter & Seeder';
    case 'Plough':
    case 'Rotavator':
      return 'Rotavator';
    case 'Other':
    case 'Laser Leveler':
      return 'Laser Leveler';
    default:
      return 'Tractor';
  }
}

export function toDbEquipmentType(category: EquipmentCategory): string {
  switch (category) {
    case 'Harvester':
      return 'Harvester';
    case 'Sprayer Drone':
      return 'Sprayer';
    case 'Planter & Seeder':
      return 'Seeder';
    case 'Rotavator':
      return 'Plough';
    case 'Laser Leveler':
      return 'Other';
    default:
      return 'Tractor';
  }
}

function defaultImageForCategory(category: EquipmentCategory): string {
  switch (category) {
    case 'Harvester':
      return DEMO_IMAGES.harvester;
    case 'Sprayer Drone':
      return DEMO_IMAGES.drone;
    case 'Rotavator':
    case 'Laser Leveler':
      return DEMO_IMAGES.rotavator;
    default:
      return DEMO_IMAGES.heroTractor;
  }
}

function toFrontendEquipmentStatus(raw: unknown): EquipmentStatus {
  switch (String(raw ?? '').toLowerCase()) {
    case 'booked':
      return 'Booked';
    case 'in_operation':
      return 'In Operation';
    case 'maintenance':
    case 'unavailable':
      return 'Maintenance';
    default:
      return 'Available';
  }
}

function toDbEquipmentStatus(status: EquipmentStatus): string {
  switch (status) {
    case 'Booked':
      return 'booked';
    case 'In Operation':
      return 'in_operation';
    case 'Maintenance':
      return 'maintenance';
    default:
      return 'available';
  }
}

function mapEquipmentRow(
  row: Record<string, unknown>,
  cols: {
    id: string;
    ownerId: string;
    name: string;
    model: string;
    category: string;
    workCapacityAcresPerHr: string;
    hourlyRateInr: string;
    perAcreRateInr: string;
    lat: string;
    lng: string;
    location: string;
    status: string;
  }
): Equipment {
  const category = toFrontendEquipmentType(row[cols.category]);
  const hourly = Number(row[cols.hourlyRateInr] ?? 0);
  const perAcre = Number(row[cols.perAcreRateInr] ?? 0);
  return {
    id: String(row[cols.id]),
    ownerId: String(row[cols.ownerId] ?? ''),
    ownerName: String(row.owner_name ?? 'Fleet Owner'),
    name: String(row[cols.name] ?? ''),
    model: String(row[cols.model] ?? ''),
    category,
    workCapacityAcresPerHr: Number(row[cols.workCapacityAcresPerHr] ?? 0),
    hourlyRateInr: hourly,
    dailyRateInr: perAcre > 0 ? perAcre : hourly * 8,
    location: String(row[cols.location] ?? ''),
    coordinates: {
      lat: Number(row[cols.lat] ?? 18.1517),
      lng: Number(row[cols.lng] ?? 74.5772),
    },
    status: toFrontendEquipmentStatus(row[cols.status]),
    horsepowerOrSpec: String(row.description ?? row.horsepower_or_spec ?? ''),
    imageUrl: String(row.image_url ?? defaultImageForCategory(category)),
    utilizationPercent: Number(row.utilization_percent ?? 0),
    nextAvailableDate: String(row.next_available_date ?? new Date().toISOString().slice(0, 10)),
    lastServicedDate: String(row.last_serviced_date ?? new Date().toISOString().slice(0, 10)),
  };
}

export const equipmentService = {
  async list(): Promise<Equipment[]> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('equipment');
      const { data, error } = await client
        .from(tableName)
        .select('*')
        .order('created_at', { ascending: false });
      if (error) {
        throw new Error(`Failed to load equipment from ${tableName}: ${error.message}`);
      }
      return ((data ?? []) as Record<string, unknown>[]).map((r) =>
        mapEquipmentRow(r, columns)
      );
    }

    await simulateNetworkDelay(160);
    return [...demoEquipmentStore];
  },

  async create(input: EquipmentInput, ownerId: string, ownerName: string): Promise<Equipment> {
    if (!input.name.trim() || input.workCapacityAcresPerHr <= 0 || input.hourlyRateInr <= 0) {
      throw new Error('Equipment name, positive work capacity, and hourly rate are required.');
    }

    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('equipment');
      const { data: authData } = await client.auth.getUser();
      const effectiveOwnerId = authData.user?.id ?? ownerId;
      const insertRow: Record<string, unknown> = {
        [columns.ownerId]: effectiveOwnerId,
        [columns.name]: input.name.trim(),
        [columns.model]: input.model.trim(),
        [columns.category]: toDbEquipmentType(input.category),
        [columns.description]: input.horsepowerOrSpec.trim(),
        [columns.workCapacityAcresPerHr]: input.workCapacityAcresPerHr,
        [columns.hourlyRateInr]: input.hourlyRateInr,
        [columns.perAcreRateInr]: input.dailyRateInr,
        [columns.lat]: input.coordinates.lat,
        [columns.lng]: input.coordinates.lng,
        [columns.location]: input.location.trim(),
        [columns.status]: toDbEquipmentStatus(input.status),
      };
      const { data, error } = await client
        .from(tableName)
        .insert(insertRow)
        .select('*')
        .single();
      if (error) {
        throw new Error(`Failed to register equipment in ${tableName}: ${error.message}`);
      }
      return mapEquipmentRow(data as Record<string, unknown>, columns);
    }

    await simulateNetworkDelay(200);
    const created: Equipment = {
      ...input,
      id: `eq-${Date.now().toString().slice(-4)}`,
      ownerId,
      ownerName,
      utilizationPercent: 0,
      lastServicedDate: new Date().toISOString().slice(0, 10),
    };
    demoEquipmentStore = [created, ...demoEquipmentStore];
    return created;
  },

  async update(id: string, patch: Partial<EquipmentInput>): Promise<Equipment> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('equipment');
      const updatePayload: Record<string, unknown> = {};
      if (patch.name !== undefined) updatePayload[columns.name] = patch.name;
      if (patch.model !== undefined) updatePayload[columns.model] = patch.model;
      if (patch.category !== undefined) {
        updatePayload[columns.category] = toDbEquipmentType(patch.category);
      }
      if (patch.horsepowerOrSpec !== undefined) {
        updatePayload[columns.description] = patch.horsepowerOrSpec;
      }
      if (patch.workCapacityAcresPerHr !== undefined) {
        updatePayload[columns.workCapacityAcresPerHr] = patch.workCapacityAcresPerHr;
      }
      if (patch.hourlyRateInr !== undefined) {
        updatePayload[columns.hourlyRateInr] = patch.hourlyRateInr;
      }
      if (patch.dailyRateInr !== undefined) {
        updatePayload[columns.perAcreRateInr] = patch.dailyRateInr;
      }
      if (patch.coordinates !== undefined) {
        updatePayload[columns.lat] = patch.coordinates.lat;
        updatePayload[columns.lng] = patch.coordinates.lng;
      }
      if (patch.location !== undefined) updatePayload[columns.location] = patch.location;
      if (patch.status !== undefined) updatePayload[columns.status] = toDbEquipmentStatus(patch.status);

      const { data, error } = await client
        .from(tableName)
        .update(updatePayload)
        .eq(columns.id, id)
        .select('*')
        .single();

      if (error) {
        throw new Error(`Failed to update equipment ${id}: ${error.message}`);
      }
      return mapEquipmentRow(data as Record<string, unknown>, columns);
    }

    await simulateNetworkDelay(160);
    const idx = demoEquipmentStore.findIndex((item) => item.id === id);
    if (idx === -1) {
      throw new Error(`Equipment ${id} not found.`);
    }
    const updated: Equipment = { ...demoEquipmentStore[idx], ...patch };
    demoEquipmentStore = demoEquipmentStore.map((item) => (item.id === id ? updated : item));
    return updated;
  },

  async updateStatus(id: string, status: EquipmentStatus): Promise<Equipment> {
    return this.update(id, { status });
  },

  async remove(id: string): Promise<void> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('equipment');
      const { error } = await client.from(tableName).delete().eq(columns.id, id);
      if (error) {
        throw new Error(`Failed to delete equipment ${id}: ${error.message}`);
      }
      return;
    }

    await simulateNetworkDelay(140);
    demoEquipmentStore = demoEquipmentStore.filter((item) => item.id !== id);
  },

  getSnapshot(): Equipment[] {
    return [...demoEquipmentStore];
  },
};
