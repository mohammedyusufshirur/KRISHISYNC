import {
  isSupabaseEnvConfigured,
  isValidHttpUrl,
  supabaseConfigError,
} from '../lib/supabaseClient';
import { BACKEND_CONTRACT } from './backendContract';

const DEMO_MODE_STORAGE_KEY = 'krishisync_demo_mode_v1';

const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.trim() ?? '';
const supabaseAnonKey =
  (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined)?.trim() ?? '';
const schedulerApiUrl =
  (import.meta.env.VITE_SCHEDULER_API_URL as string | undefined)?.trim() ?? '';

export interface ExternalIntegrationConfig {
  supabaseUrl: string;
  supabaseAnonKey: string;
  schedulerApiUrl: string;
  isSupabaseConfigured: boolean;
  isSchedulerApiConfigured: boolean;
  hasVerifiedDatabaseContract: boolean;
  hasVerifiedSchedulerContract: boolean;
}

export const API_CONFIG: ExternalIntegrationConfig = {
  supabaseUrl,
  supabaseAnonKey,
  schedulerApiUrl,
  isSupabaseConfigured: isSupabaseEnvConfigured,
  isSchedulerApiConfigured: isValidHttpUrl(schedulerApiUrl),
  hasVerifiedDatabaseContract: Object.values(BACKEND_CONTRACT.tables).every((t) => t.verified),
  hasVerifiedSchedulerContract: Object.values(BACKEND_CONTRACT.schedulerEndpoints).every(
    (e) => e.verified
  ),
};

export function isDemoModeActive(): boolean {
  try {
    const stored = localStorage.getItem(DEMO_MODE_STORAGE_KEY);
    if (stored === 'true') return true;
    if (stored === 'false') return false;
  } catch {
    // Ignore storage read errors
  }
  // Automatically use demo fallback only when external env vars or backend contracts are missing
  return !API_CONFIG.isSupabaseConfigured || !API_CONFIG.hasVerifiedDatabaseContract;
}

export function setDemoModeActive(enabled: boolean): void {
  try {
    localStorage.setItem(DEMO_MODE_STORAGE_KEY, String(enabled));
  } catch {
    // Ignore storage write errors
  }
}

export function getMissingIntegrationRequirements(): string[] {
  const missing: string[] = [];
  if (supabaseConfigError) {
    missing.push(supabaseConfigError);
  } else if (!API_CONFIG.isSupabaseConfigured) {
    missing.push(
      'VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are not set in the runtime environment.'
    );
  }
  if (!API_CONFIG.hasVerifiedDatabaseContract) {
    missing.push('Exact Supabase table names and column schemas have not been supplied.');
  }
  return missing;
}

export async function simulateNetworkDelay(ms = 180): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, ms));
}
