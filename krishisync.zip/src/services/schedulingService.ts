import { INITIAL_CONFLICTS, INITIAL_SCHEDULE_SLOTS } from '../data/mockData';
import { requireSupabaseClient, supabase } from '../lib/supabaseClient';
import {
  BookingPriority,
  OperationType,
  ScheduleConflict,
  ScheduleGenerationParams,
  ScheduleGenerationResponse,
  ScheduleSlot,
} from '../types/domain';
import { API_CONFIG, isDemoModeActive, simulateNetworkDelay } from './apiConfig';
import { requireVerifiedSchedulerEndpoint } from './backendContract';
import { bookingService } from './bookingService';
import { equipmentService } from './equipmentService';
import { plotService } from './plotService';

let demoSlotStore: ScheduleSlot[] = [...INITIAL_SCHEDULE_SLOTS];
let demoConflictStore: ScheduleConflict[] = [...INITIAL_CONFLICTS];

function haversineDistanceKm(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number }
): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const sinLat = Math.sin(dLat / 2);
  const sinLng = Math.sin(dLng / 2);
  const h =
    sinLat * sinLat + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * sinLng * sinLng;
  return Math.round(2 * R * Math.asin(Math.sqrt(h)) * 10) / 10;
}

function scoreToPriority(score: number): BookingPriority {
  if (score >= 80) return 'Critical';
  if (score >= 60) return 'High';
  return 'Standard';
}

function isoToDateAndHour(iso: string): { date: string; hour: number } {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) {
    return { date: iso.slice(0, 10), hour: 8 };
  }
  const date = d.toISOString().slice(0, 10);
  const hour = d.getUTCHours() + d.getUTCMinutes() / 60;
  return { date, hour };
}

async function buildSchedulerHeaders(): Promise<Record<string, string>> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (supabase) {
    const { data } = await supabase.auth.getSession();
    if (data.session?.access_token) {
      headers['Authorization'] = `Bearer ${data.session.access_token}`;
    }
  }
  return headers;
}

function assertSchedulerBaseUrl(): string {
  if (!API_CONFIG.isSchedulerApiConfigured) {
    throw new Error(
      'VITE_SCHEDULER_API_URL is not configured in the runtime environment.'
    );
  }
  return API_CONFIG.schedulerApiUrl.replace(/\/+$/, '');
}

async function loadSupabaseScheduleState(
  extraConflicts: ScheduleConflict[] = []
): Promise<ScheduleGenerationResponse> {
  const client = requireSupabaseClient();
  const [{ data: schedRows, error: schedErr }, { data: pendingRows, error: pendErr }] =
    await Promise.all([
      client
        .from('schedules')
        .select(
          '*, equipment(equipment_name, address), plots(plot_name), farmer:profiles(full_name), booking:bookings(operation_type, priority_score, requested_deadline)'
        )
        .in('status', ['scheduled', 'in_progress', 'rescheduling_required'])
        .order('scheduled_start', { ascending: true }),
      client
        .from('bookings')
        .select(
          'id, equipment_id, requested_start_time, requested_deadline, status, priority_score, equipment(equipment_name, availability_status), plots(plot_name)'
        )
        .in('status', ['rescheduling_required', 'accepted', 'pending'])
        .order('priority_score', { ascending: false })
        .order('requested_deadline', { ascending: true }),
    ]);

  if (schedErr) {
    throw new Error(`Failed to fetch schedules: ${schedErr.message}`);
  }
  if (pendErr) {
    throw new Error(`Failed to fetch booking queue: ${pendErr.message}`);
  }

  const slots: ScheduleSlot[] = ((schedRows ?? []) as Record<string, unknown>[]).map((r) => {
    const eq = (r.equipment ?? {}) as Record<string, unknown>;
    const plot = (r.plots ?? {}) as Record<string, unknown>;
    const farmer = (r.farmer ?? {}) as Record<string, unknown>;
    const booking = (r.booking ?? {}) as Record<string, unknown>;
    const start = isoToDateAndHour(String(r.scheduled_start));
    const endMs = new Date(String(r.scheduled_end)).getTime();
    const startMs = new Date(String(r.scheduled_start)).getTime();
    const durationHours = Math.max(0.5, Math.round(((endMs - startMs) / 3600000) * 10) / 10);
    const rawStatus = String(r.status ?? 'scheduled').toLowerCase();

    return {
      id: String(r.id),
      bookingId: String(r.booking_id),
      equipmentId: String(r.equipment_id),
      equipmentName: String(eq.equipment_name ?? 'Equipment'),
      plotId: String(r.plot_id),
      plotName: String(plot.plot_name ?? 'Plot'),
      farmerName: String(farmer.full_name ?? 'Farmer'),
      operationType: (booking.operation_type as OperationType) ?? 'Sowing',
      date: start.date,
      startHour: start.hour,
      durationHours,
      travelBufferMinutes: Number(r.travel_buffer_minutes ?? 0),
      travelOriginLabel: String(eq.address ?? 'Regional Hub'),
      priority: scoreToPriority(Number(booking.priority_score ?? 50)),
      status:
        rawStatus === 'rescheduling_required'
          ? 'Conflict'
          : String(r.scheduling_reason ?? '').toLowerCase().includes('shift') ||
            String(r.scheduling_reason ?? '').toLowerCase().includes('backup')
          ? 'Revised'
          : 'Allocated',
    };
  });

  const derivedConflicts: ScheduleConflict[] = [...extraConflicts];
  ((pendingRows ?? []) as Record<string, unknown>[]).forEach((b) => {
    if (b.status === 'rescheduling_required') {
      const eq = (b.equipment ?? {}) as Record<string, unknown>;
      const plot = (b.plots ?? {}) as Record<string, unknown>;
      derivedConflicts.push({
        id: `conf-${String(b.id)}`,
        severity: 'High',
        equipmentId: String(b.equipment_id),
        equipmentName: String(eq.equipment_name ?? 'Equipment'),
        date: String(b.requested_start_time ?? '').slice(0, 10),
        summary: `Booking for ${String(plot.plot_name ?? 'Plot')} requires rescheduling due to disruption or window overlap.`,
        affectedBookingIds: [String(b.id)],
        recommendedAction: 'Generate schedule or reassign an available machine.',
        resolved: false,
      });
    }
  });

  const totalAllocatedHours =
    Math.round(slots.reduce((sum, s) => sum + s.durationHours, 0) * 10) / 10;
  const totalTravelBufferMinutes = slots.reduce((sum, s) => sum + s.travelBufferMinutes, 0);
  const unresolvedConflicts = derivedConflicts.filter((c) => !c.resolved).length;

  return {
    sourceMode: 'supabase-rpc',
    generatedAt: new Date().toISOString(),
    slots,
    conflicts: derivedConflicts,
    summary: {
      totalAllocatedHours,
      totalTravelBufferMinutes,
      onTimeDeadlineRatePercent:
        slots.length === 0 ? 100 : unresolvedConflicts === 0 ? 100 : Math.max(70, 100 - unresolvedConflicts * 10),
      unresolvedConflicts,
    },
  };
}

/**
 * Scheduling Service Adapter
 * --------------------------
 * Uses Member 3's external Scheduling Engine HTTP API when both `VITE_SCHEDULER_API_URL`
 * and verified endpoint paths are configured; otherwise operates directly on the
 * Supabase PostgreSQL `schedules` table and `save_schedule_allocation` RPC (or Demo Mode).
 */
export const schedulingService = {
  async getCurrentSchedule(): Promise<ScheduleGenerationResponse> {
    if (!isDemoModeActive()) {
      if (API_CONFIG.isSchedulerApiConfigured && API_CONFIG.hasVerifiedSchedulerContract) {
        const baseUrl = assertSchedulerBaseUrl();
        const endpoint = requireVerifiedSchedulerEndpoint('getCurrentSchedule');
        const headers = await buildSchedulerHeaders();

        const res = await fetch(`${baseUrl}${endpoint.path}`, {
          method: endpoint.method,
          headers,
        });
        if (!res.ok) {
          throw new Error(`Scheduling API returned HTTP ${res.status} on current schedule.`);
        }
        return (await res.json()) as ScheduleGenerationResponse;
      }

      return loadSupabaseScheduleState();
    }

    await simulateNetworkDelay(180);
    return this.buildDemoResponse('demo-adapter');
  },

  async requestScheduleGeneration(
    params: ScheduleGenerationParams
  ): Promise<ScheduleGenerationResponse> {
    if (!isDemoModeActive()) {
      if (API_CONFIG.isSchedulerApiConfigured && API_CONFIG.hasVerifiedSchedulerContract) {
        const baseUrl = assertSchedulerBaseUrl();
        const endpoint = requireVerifiedSchedulerEndpoint('generateSchedule');
        const headers = await buildSchedulerHeaders();

        const res = await fetch(`${baseUrl}${endpoint.path}`, {
          method: endpoint.method,
          headers,
          body: JSON.stringify(params),
        });
        if (!res.ok) {
          throw new Error(`Scheduling API returned HTTP ${res.status} during schedule generation.`);
        }
        return (await res.json()) as ScheduleGenerationResponse;
      }

      const client = requireSupabaseClient();
      const [bookingsRes, eqRes, plotsRes, schedRes] = await Promise.all([
        client
          .from('bookings')
          .select('*')
          .in('status', ['accepted', 'pending', 'rescheduling_required']),
        client.from('equipment').select('*'),
        client.from('plots').select('*'),
        client
          .from('schedules')
          .select('id, equipment_id, scheduled_start, scheduled_end, status')
          .in('status', ['scheduled', 'in_progress']),
      ]);

      if (bookingsRes.error) throw new Error(bookingsRes.error.message);
      if (eqRes.error) throw new Error(eqRes.error.message);
      if (plotsRes.error) throw new Error(plotsRes.error.message);
      if (schedRes.error) throw new Error(schedRes.error.message);

      const eqMap = new Map(
        ((eqRes.data ?? []) as Record<string, unknown>[]).map((e) => [String(e.id), e])
      );
      const plotMap = new Map(
        ((plotsRes.data ?? []) as Record<string, unknown>[]).map((p) => [String(p.id), p])
      );
      const occupiedByEquipment = new Map<string, Array<{ startMs: number; endMs: number }>>();
      ((schedRes.data ?? []) as Record<string, unknown>[]).forEach((s) => {
        const eqId = String(s.equipment_id);
        const list = occupiedByEquipment.get(eqId) ?? [];
        list.push({
          startMs: new Date(String(s.scheduled_start)).getTime(),
          endMs: new Date(String(s.scheduled_end)).getTime(),
        });
        occupiedByEquipment.set(eqId, list);
      });

      const candidates = [...((bookingsRes.data ?? []) as Record<string, unknown>[])];
      candidates.sort((a, b) => {
        if (params.prioritizeDeadlines) {
          const pDiff = Number(b.priority_score ?? 50) - Number(a.priority_score ?? 50);
          if (pDiff !== 0) return pDiff;
          return String(a.requested_deadline).localeCompare(String(b.requested_deadline));
        }
        return String(a.requested_start_time).localeCompare(String(b.requested_start_time));
      });

      const conflicts: ScheduleConflict[] = [];

      for (const bk of candidates) {
        const eq = eqMap.get(String(bk.equipment_id));
        const plot = plotMap.get(String(bk.plot_id));
        if (!eq || !plot) continue;

        const eqStatus = String(eq.availability_status ?? '');
        if (eqStatus === 'maintenance' || eqStatus === 'unavailable') {
          conflicts.push({
            id: `conf-${String(bk.id)}`,
            severity: 'High',
            equipmentId: String(eq.id),
            equipmentName: String(eq.equipment_name),
            date: String(bk.requested_start_time).slice(0, 10),
            summary: `${String(eq.equipment_name)} is ${eqStatus}; cannot confirm booking for ${String(plot.plot_name)}.`,
            affectedBookingIds: [String(bk.id)],
            recommendedAction: 'Use Emergency Management to reassign to an available backup unit.',
            resolved: false,
          });
          continue;
        }

        const distanceKm = haversineDistanceKm(
          { lat: Number(eq.latitude), lng: Number(eq.longitude) },
          { lat: Number(plot.latitude), lng: Number(plot.longitude) }
        );
        const bufferMinutes = params.includeTravelBuffers
          ? Math.max(10, Math.round((distanceKm / 10) * params.bufferMinutesPer10Km))
          : 0;
        const durationHours = Math.max(1, Number(bk.estimated_duration_hours ?? 2));
        const durationMs = durationHours * 3600000;
        const bufferMs = bufferMinutes * 60000;

        const reqDate = String(bk.requested_start_time).slice(0, 10);
        const minDate = reqDate >= params.startDate ? reqDate : params.startDate;
        const deadlineMs = new Date(String(bk.requested_deadline)).getTime();

        const existingWindows = occupiedByEquipment.get(String(eq.id)) ?? [];
        let allocatedStartMs: number | null = null;

        for (let dayOffset = 0; dayOffset < Math.max(1, params.horizonDays); dayOffset++) {
          const dayBase = new Date(`${minDate}T07:00:00Z`);
          dayBase.setUTCDate(dayBase.getUTCDate() + dayOffset);
          const dayStart = dayBase.getTime();
          const dayLatestEnd = dayStart + 12 * 3600000;

          let candidateStart = dayStart + bufferMs;
          while (candidateStart + durationMs <= dayLatestEnd) {
            const candidateEnd = candidateStart + durationMs;
            const overlaps = existingWindows.some(
              (w) => candidateStart < w.endMs && candidateEnd > w.startMs
            );
            if (!overlaps && candidateEnd <= deadlineMs) {
              allocatedStartMs = candidateStart;
              break;
            }
            candidateStart += 3600000;
          }
          if (allocatedStartMs !== null) break;
        }

        if (allocatedStartMs === null) {
          conflicts.push({
            id: `conf-${String(bk.id)}`,
            severity: 'High',
            equipmentId: String(eq.id),
            equipmentName: String(eq.equipment_name),
            date: minDate,
            summary: `No conflict-free slot found for ${String(plot.plot_name)} before deadline ${String(bk.requested_deadline).slice(0, 10)}.`,
            affectedBookingIds: [String(bk.id)],
            recommendedAction: 'Extend horizon or reassign an idle regional machine.',
            resolved: false,
          });
          continue;
        }

        const startIso = new Date(allocatedStartMs).toISOString();
        const endIso = new Date(allocatedStartMs + durationMs).toISOString();
        const reason = `Priority ${Number(bk.priority_score ?? 50)} · ${distanceKm} km transit · ${bufferMinutes}m buffer`;

        const { error: saveErr } = await client.rpc('save_schedule_allocation', {
          p_booking_id: String(bk.id),
          p_equipment_id: String(eq.id),
          p_scheduled_start: startIso,
          p_scheduled_end: endIso,
          p_travel_buffer_minutes: bufferMinutes,
          p_estimated_travel_distance_km: distanceKm,
          p_scheduling_reason: reason,
        });

        if (saveErr) {
          conflicts.push({
            id: `conf-${String(bk.id)}`,
            severity: 'High',
            equipmentId: String(eq.id),
            equipmentName: String(eq.equipment_name),
            date: minDate,
            summary: saveErr.message,
            affectedBookingIds: [String(bk.id)],
            recommendedAction: 'Resolve overlapping window and regenerate.',
            resolved: false,
          });
        } else {
          existingWindows.push({
            startMs: allocatedStartMs,
            endMs: allocatedStartMs + durationMs,
          });
          occupiedByEquipment.set(String(eq.id), existingWindows);
        }
      }

      return loadSupabaseScheduleState(conflicts);
    }

    await simulateNetworkDelay(280);

    const allEq = equipmentService.getSnapshot();
    const allPlots = plotService.getSnapshot();
    const allBookings = bookingService.getSnapshot();

    if (params.includeTravelBuffers) {
      demoSlotStore = demoSlotStore.map((slot) => ({
        ...slot,
        travelBufferMinutes: Math.max(15, slot.travelBufferMinutes),
      }));
    }

    const allocatedBookingIds = new Set(demoSlotStore.map((s) => s.bookingId));
    const unallocatedBookings = allBookings
      .filter(
        (b) =>
          (b.status === 'Pending' || b.status === 'Confirmed') &&
          !allocatedBookingIds.has(b.id)
      )
      .sort((a, b) => {
        if (params.prioritizeDeadlines) {
          const rank = { Critical: 3, High: 2, Standard: 1 };
          const pDiff = rank[b.priority] - rank[a.priority];
          if (pDiff !== 0) return pDiff;
          return a.deadline.localeCompare(b.deadline);
        }
        return a.requestedDate.localeCompare(b.requestedDate);
      });

    for (const bk of unallocatedBookings) {
      const eq = allEq.find((e) => e.id === bk.equipmentId);
      const plot = allPlots.find((p) => p.id === bk.plotId);
      if (!eq || !plot || eq.status === 'Maintenance') continue;

      const distanceKm = haversineDistanceKm(eq.coordinates, plot.coordinates);
      const bufferMinutes = params.includeTravelBuffers
        ? Math.max(10, Math.round((distanceKm / 10) * params.bufferMinutesPer10Km))
        : 0;
      const daySlots = demoSlotStore.filter(
        (s) => s.equipmentId === eq.id && s.date === bk.requestedDate
      );

      let startHour = 7;
      while (startHour + bk.estimatedHours <= 19) {
        const endHour = startHour + bk.estimatedHours;
        const overlaps = daySlots.some(
          (s) => startHour < s.startHour + s.durationHours && endHour > s.startHour
        );
        if (!overlaps) break;
        startHour += 1;
      }

      if (startHour + bk.estimatedHours <= 19) {
        demoSlotStore = [
          ...demoSlotStore,
          {
            id: `sl-${Date.now().toString().slice(-4)}-${bk.id}`,
            bookingId: bk.id,
            equipmentId: eq.id,
            equipmentName: eq.name,
            plotId: plot.id,
            plotName: plot.name,
            farmerName: bk.farmerName,
            operationType: bk.operationType,
            date: bk.requestedDate,
            startHour,
            durationHours: bk.estimatedHours,
            travelBufferMinutes: bufferMinutes,
            travelOriginLabel: eq.location,
            priority: bk.priority,
            status: 'Allocated',
          },
        ];
        await bookingService.updateStatus(bk.id, 'Scheduled');
      } else {
        demoConflictStore = [
          ...demoConflictStore,
          {
            id: `conf-${bk.id}`,
            severity: 'High',
            equipmentId: eq.id,
            equipmentName: eq.name,
            date: bk.requestedDate,
            summary: `Insufficient free hours on ${bk.requestedDate} for ${plot.name}.`,
            affectedBookingIds: [bk.id],
            recommendedAction: 'Shift to next available morning slot or reassign unit.',
            resolved: false,
          },
        ];
      }
    }

    return this.buildDemoResponse('demo-adapter');
  },

  async resolveConflict(conflictId: string): Promise<ScheduleGenerationResponse> {
    if (!isDemoModeActive()) {
      if (API_CONFIG.isSchedulerApiConfigured && API_CONFIG.hasVerifiedSchedulerContract) {
        const baseUrl = assertSchedulerBaseUrl();
        const endpoint = requireVerifiedSchedulerEndpoint('resolveConflict');
        const headers = await buildSchedulerHeaders();

        const res = await fetch(`${baseUrl}${endpoint.path}`, {
          method: endpoint.method,
          headers,
          body: JSON.stringify({ conflictId }),
        });
        if (!res.ok) {
          throw new Error(`Scheduling API returned HTTP ${res.status} while resolving conflict.`);
        }
        return (await res.json()) as ScheduleGenerationResponse;
      }

      const bookingId = conflictId.replace(/^conf-/, '');
      const client = requireSupabaseClient();
      const { data: bk, error: bkErr } = await client
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .single();
      if (bkErr || !bk) {
        throw new Error(`Unable to locate booking ${bookingId} for conflict resolution.`);
      }
      const { data: eqList } = await client
        .from('equipment')
        .select('*')
        .in('availability_status', ['available', 'booked']);
      const targetEq =
        ((eqList ?? []) as Record<string, unknown>[]).find(
          (e) => String(e.id) !== String(bk.equipment_id)
        ) ?? ((eqList ?? []) as Record<string, unknown>[])[0];

      if (!targetEq) {
        throw new Error('No available equipment found to resolve this conflict.');
      }

      const dateStr = String(bk.requested_start_time).slice(0, 10);
      const durationHours = Math.max(1, Number(bk.estimated_duration_hours ?? 2));
      const startIso = `${dateStr}T10:00:00Z`;
      const endIso = new Date(new Date(startIso).getTime() + durationHours * 3600000).toISOString();

      const { error: saveErr } = await client.rpc('save_schedule_allocation', {
        p_booking_id: bookingId,
        p_equipment_id: String(targetEq.id),
        p_scheduled_start: startIso,
        p_scheduled_end: endIso,
        p_travel_buffer_minutes: 25,
        p_estimated_travel_distance_km: 8.5,
        p_scheduling_reason: 'Shifted and resolved conflict slot',
      });
      if (saveErr) throw new Error(saveErr.message);

      return loadSupabaseScheduleState();
    }

    await simulateNetworkDelay(180);
    const conflict = demoConflictStore.find((c) => c.id === conflictId);
    if (!conflict) {
      throw new Error(`Conflict ${conflictId} not found.`);
    }

    demoConflictStore = demoConflictStore.map((c) =>
      c.id === conflictId ? { ...c, resolved: true } : c
    );

    demoSlotStore = demoSlotStore.map((slot) =>
      conflict.affectedBookingIds.includes(slot.bookingId)
        ? { ...slot, startHour: 10, status: 'Revised' }
        : slot
    );

    return this.buildDemoResponse('demo-adapter');
  },

  buildDemoResponse(
    sourceMode: 'external-api' | 'supabase-rpc' | 'demo-adapter'
  ): ScheduleGenerationResponse {
    const totalAllocatedHours = demoSlotStore.reduce((sum, s) => sum + s.durationHours, 0);
    const totalTravelBufferMinutes = demoSlotStore.reduce(
      (sum, s) => sum + s.travelBufferMinutes,
      0
    );
    const unresolvedConflicts = demoConflictStore.filter((c) => !c.resolved).length;

    return {
      sourceMode,
      generatedAt: new Date().toISOString(),
      slots: [...demoSlotStore],
      conflicts: [...demoConflictStore],
      summary: {
        totalAllocatedHours,
        totalTravelBufferMinutes,
        onTimeDeadlineRatePercent: unresolvedConflicts === 0 ? 100 : 88,
        unresolvedConflicts,
      },
    };
  },
};
