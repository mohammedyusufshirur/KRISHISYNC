import { INITIAL_DISRUPTIONS } from '../data/mockData';
import { requireSupabaseClient, supabase } from '../lib/supabaseClient';
import {
  AlternativeSuggestion,
  Booking,
  DisruptionInput,
  DisruptionReport,
  DisruptionSeverity,
  DisruptionType,
  Equipment,
  RevisedScheduleItem,
} from '../types/domain';
import { API_CONFIG, isDemoModeActive, simulateNetworkDelay } from './apiConfig';
import { requireVerifiedSchedulerEndpoint, requireVerifiedTable } from './backendContract';
import { bookingService } from './bookingService';
import { equipmentService } from './equipmentService';

let demoDisruptionStore: DisruptionReport[] = [...INITIAL_DISRUPTIONS];

async function buildSchedulerHeaders(): Promise<Record<string, string>> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (supabase) {
    const { data } = await supabase.auth.getSession();
    if (data.session?.access_token) {
      headers['Authorization'] = `Bearer ${data.session.access_token}`;
    }
  }
  return headers;
}

function toFrontendDisruptionType(raw: unknown): DisruptionType {
  switch (String(raw ?? '').toLowerCase()) {
    case 'weather_disruption':
      return 'Severe Weather';
    default:
      return 'Machine Breakdown';
  }
}

function toDbDisruptionType(type: DisruptionType): string {
  return type === 'Severe Weather' ? 'weather_disruption' : 'machine_breakdown';
}

function hydrateDisruptionReport(
  row: Record<string, unknown>,
  cols: {
    id: string;
    type: string;
    equipmentId: string;
    affectedRegion: string;
    description: string;
    status: string;
  },
  allBookings: Booking[],
  allEquipment: Equipment[]
): DisruptionReport {
  const joinedEq = (row.equipment ?? {}) as Record<string, unknown>;
  const rawStatus = String(row[cols.status] ?? 'active').toLowerCase();
  const type = toFrontendDisruptionType(row[cols.type]);
  const equipmentId = row[cols.equipmentId] ? String(row[cols.equipmentId]) : undefined;
  const affectedEq = equipmentId
    ? allEquipment.find((e) => e.id === equipmentId)
    : undefined;

  const isMitigated = rawStatus === 'resolved' || rawStatus === 'mitigated';

  const impactedBookings = allBookings.filter((b) => {
    if (b.status === 'Completed' || b.status === 'Cancelled') return false;
    if (isMitigated) return false;
    if (type === 'Machine Breakdown' && equipmentId) {
      return b.equipmentId === equipmentId || b.status === 'Disrupted';
    }
    return b.status === 'Disrupted' || b.priority !== 'Standard';
  });

  const availableBackups = allEquipment
    .filter((e) => e.id !== equipmentId && e.status === 'Available')
    .sort((a, b) => {
      const aMatch = affectedEq && a.category === affectedEq.category ? 0 : 1;
      const bMatch = affectedEq && b.category === affectedEq.category ? 0 : 1;
      return aMatch - bMatch;
    });

  const alternatives: AlternativeSuggestion[] = availableBackups.slice(0, 3).map((eq, i) => ({
    equipmentId: eq.id,
    equipmentName: eq.name,
    category: eq.category,
    distanceKm: 5.2 + i * 3.1,
    hourlyRateInr: eq.hourlyRateInr,
    earliestWindow: `${eq.nextAvailableDate} · 07:30`,
    compatibilityNote: `Available at ${eq.location} (${eq.workCapacityAcresPerHr} ac/hr).`,
  }));

  const revisedPlan: RevisedScheduleItem[] = impactedBookings.map((bk, idx) => {
    const alt = alternatives[idx % Math.max(1, alternatives.length)];
    return {
      bookingId: bk.id,
      plotName: bk.plotName,
      previousEquipmentName: bk.equipmentName,
      newEquipmentId: alt ? alt.equipmentId : bk.equipmentId,
      newEquipmentName: alt ? alt.equipmentName : 'Pending Regional Dispatch',
      previousWindow: `${bk.requestedDate} · 08:00`,
      revisedWindow:
        type === 'Severe Weather'
          ? `${bk.deadline} · 07:00 (Post-Rain Window)`
          : `${bk.requestedDate} · 10:30 (Backup Dispatch)`,
      status: isMitigated ? 'Applied' : 'Proposed',
    };
  });

  return {
    id: String(row[cols.id]),
    type,
    severity: (row.severity as DisruptionSeverity) ?? 'Critical',
    equipmentId,
    equipmentName:
      typeof joinedEq.equipment_name === 'string'
        ? joinedEq.equipment_name
        : affectedEq?.name,
    affectedRegion: String(row[cols.affectedRegion] ?? ''),
    reportedBy: String(row.reported_by ?? 'Operator'),
    reportedAt: String(row.start_time ?? row.created_at ?? new Date().toISOString()),
    description: String(row[cols.description] ?? ''),
    status: isMitigated ? 'Mitigated' : 'Active',
    affectedBookingIds: Array.isArray(row.affected_booking_ids)
      ? (row.affected_booking_ids as string[])
      : impactedBookings.map((b) => b.id),
    alternatives: Array.isArray(row.alternatives)
      ? (row.alternatives as AlternativeSuggestion[])
      : alternatives,
    revisedPlan: Array.isArray(row.revised_plan)
      ? (row.revised_plan as RevisedScheduleItem[])
      : revisedPlan,
  };
}

export const disruptionService = {
  async list(): Promise<DisruptionReport[]> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('disruptions');
      const [disRes, allBookings, allEquipment] = await Promise.all([
        client
          .from(tableName)
          .select('*, equipment(equipment_name)')
          .order('created_at', { ascending: false }),
        bookingService.list(),
        equipmentService.list(),
      ]);
      if (disRes.error) {
        throw new Error(
          `Failed to fetch disruptions from ${tableName}: ${disRes.error.message}`
        );
      }
      return ((disRes.data ?? []) as Record<string, unknown>[]).map((r) =>
        hydrateDisruptionReport(r, columns, allBookings, allEquipment)
      );
    }

    await simulateNetworkDelay(160);
    return [...demoDisruptionStore];
  },

  async reportDisruption(
    input: DisruptionInput,
    reporterName: string
  ): Promise<DisruptionReport> {
    if (!input.affectedRegion.trim() || !input.description.trim()) {
      throw new Error('Affected region and disruption details are required.');
    }
    if (input.type === 'Machine Breakdown' && !input.equipmentId) {
      throw new Error('Please select the affected machine for a breakdown report.');
    }

    if (!isDemoModeActive()) {
      if (API_CONFIG.isSchedulerApiConfigured && API_CONFIG.hasVerifiedSchedulerContract) {
        const endpoint = requireVerifiedSchedulerEndpoint('reportDisruptionReschedule');
        const baseUrl = API_CONFIG.schedulerApiUrl.replace(/\/+$/, '');
        const headers = await buildSchedulerHeaders();

        const res = await fetch(`${baseUrl}${endpoint.path}`, {
          method: endpoint.method,
          headers,
          body: JSON.stringify({
            ...input,
            reportedBy: reporterName,
          }),
        });
        if (!res.ok) {
          throw new Error(
            `Scheduling API returned HTTP ${res.status} when reporting disruption.`
          );
        }
        return (await res.json()) as DisruptionReport;
      }

      const client = requireSupabaseClient();
      const { columns } = requireVerifiedTable('disruptions');
      const { data, error } = await client.rpc('report_disruption_tx', {
        p_disruption_type: toDbDisruptionType(input.type),
        p_description: input.description.trim(),
        p_equipment_id: input.equipmentId ?? null,
        p_start_time: new Date().toISOString(),
        p_end_time: null,
        p_affected_area: input.affectedRegion.trim(),
      });
      if (error) {
        throw new Error(`Failed to report disruption: ${error.message}`);
      }
      const [allBookings, allEquipment] = await Promise.all([
        bookingService.list(),
        equipmentService.list(),
      ]);
      return hydrateDisruptionReport(
        data as Record<string, unknown>,
        columns,
        allBookings,
        allEquipment
      );
    }

    await simulateNetworkDelay(220);

    const allEquipment = equipmentService.getSnapshot();
    const allBookings = bookingService.getSnapshot();

    const affectedEq = input.equipmentId
      ? allEquipment.find((e) => e.id === input.equipmentId)
      : undefined;

    if (affectedEq) {
      await equipmentService.updateStatus(affectedEq.id, 'Maintenance');
    }

    const impactedBookings = allBookings.filter((b) => {
      if (b.status === 'Completed' || b.status === 'Cancelled') return false;
      if (input.type === 'Machine Breakdown' && affectedEq) {
        return b.equipmentId === affectedEq.id;
      }
      return b.status === 'Scheduled' || b.status === 'Confirmed' || b.priority !== 'Standard';
    });

    const availableBackups = allEquipment
      .filter((e) => e.id !== affectedEq?.id && e.status === 'Available')
      .sort((a, b) => {
        const aMatch = affectedEq && a.category === affectedEq.category ? 0 : 1;
        const bMatch = affectedEq && b.category === affectedEq.category ? 0 : 1;
        return aMatch - bMatch;
      });

    const alternatives: AlternativeSuggestion[] = availableBackups.slice(0, 3).map((eq, i) => ({
      equipmentId: eq.id,
      equipmentName: eq.name,
      category: eq.category,
      distanceKm: 5.2 + i * 3.4,
      hourlyRateInr: eq.hourlyRateInr,
      earliestWindow: `${eq.nextAvailableDate} · 07:30`,
      compatibilityNote: `Available at ${eq.location} (${eq.workCapacityAcresPerHr} ac/hr).`,
    }));

    const revisedPlan: RevisedScheduleItem[] = impactedBookings.map((bk, idx) => {
      const alt = alternatives[idx % Math.max(1, alternatives.length)];
      return {
        bookingId: bk.id,
        plotName: bk.plotName,
        previousEquipmentName: bk.equipmentName,
        newEquipmentId: alt ? alt.equipmentId : bk.equipmentId,
        newEquipmentName: alt ? alt.equipmentName : 'Pending Regional Dispatch',
        previousWindow: `${bk.requestedDate} · 08:00`,
        revisedWindow:
          input.type === 'Severe Weather'
            ? `${bk.deadline} · 07:00 (Post-Rain Window)`
            : `${bk.requestedDate} · 10:30 (Backup Dispatch)`,
        status: 'Proposed',
      };
    });

    const report: DisruptionReport = {
      id: `dis-${Date.now().toString().slice(-3)}`,
      type: input.type,
      severity: input.severity,
      equipmentId: affectedEq?.id,
      equipmentName: affectedEq?.name,
      affectedRegion: input.affectedRegion.trim(),
      reportedBy: reporterName,
      reportedAt: new Date().toISOString(),
      description: input.description.trim(),
      status: 'Active',
      affectedBookingIds: impactedBookings.map((b) => b.id),
      alternatives,
      revisedPlan,
    };

    demoDisruptionStore = [report, ...demoDisruptionStore];
    return report;
  },

  async applyRevisedPlan(disruptionId: string): Promise<DisruptionReport> {
    if (!isDemoModeActive()) {
      if (API_CONFIG.isSchedulerApiConfigured && API_CONFIG.hasVerifiedSchedulerContract) {
        const endpoint = requireVerifiedSchedulerEndpoint('applyRevisedSchedule');
        const baseUrl = API_CONFIG.schedulerApiUrl.replace(/\/+$/, '');
        const headers = await buildSchedulerHeaders();

        const res = await fetch(`${baseUrl}${endpoint.path}`, {
          method: endpoint.method,
          headers,
          body: JSON.stringify({ disruptionId }),
        });
        if (!res.ok) {
          throw new Error(
            `Scheduling API returned HTTP ${res.status} when applying revised schedule.`
          );
        }
        return (await res.json()) as DisruptionReport;
      }

      const reports = await this.list();
      const target = reports.find((r) => r.id === disruptionId);
      if (!target) {
        throw new Error('Disruption report not found.');
      }

      const client = requireSupabaseClient();
      const allBookings = await bookingService.list();

      for (const item of target.revisedPlan) {
        if (!item.newEquipmentId) continue;
        const bk = allBookings.find((b) => b.id === item.bookingId);
        const dateStr = bk?.requestedDate || new Date().toISOString().slice(0, 10);
        const startIso = `${dateStr}T10:30:00Z`;
        const endIso = new Date(
          new Date(startIso).getTime() + Math.max(1, bk?.estimatedHours ?? 2) * 3600000
        ).toISOString();

        const { error: saveErr } = await client.rpc('save_schedule_allocation', {
          p_booking_id: item.bookingId,
          p_equipment_id: item.newEquipmentId,
          p_scheduled_start: startIso,
          p_scheduled_end: endIso,
          p_travel_buffer_minutes: 25,
          p_estimated_travel_distance_km: 8.5,
          p_scheduling_reason: `Backup equipment dispatch for disruption ${disruptionId}`,
        });
        if (saveErr) {
          throw new Error(`Failed to reassign booking ${item.bookingId}: ${saveErr.message}`);
        }
      }

      const { error: updErr } = await client
        .from('disruptions')
        .update({ status: 'mitigated' })
        .eq('id', disruptionId);
      if (updErr) {
        throw new Error(`Failed to update disruption status: ${updErr.message}`);
      }

      return {
        ...target,
        status: 'Mitigated',
        revisedPlan: target.revisedPlan.map((r) => ({ ...r, status: 'Applied' })),
      };
    }

    await simulateNetworkDelay(200);
    const report = demoDisruptionStore.find((d) => d.id === disruptionId);
    if (!report) throw new Error('Disruption report not found.');

    for (const item of report.revisedPlan) {
      if (item.newEquipmentId) {
        await bookingService.reassignEquipment(
          item.bookingId,
          item.newEquipmentId,
          item.newEquipmentName
        );
      }
    }

    const updated: DisruptionReport = {
      ...report,
      status: 'Mitigated',
      revisedPlan: report.revisedPlan.map((r) => ({ ...r, status: 'Applied' })),
    };

    demoDisruptionStore = demoDisruptionStore.map((d) => (d.id === disruptionId ? updated : d));
    return updated;
  },

  async restoreEquipment(equipmentId: string, disruptionId?: string): Promise<void> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { error } = await client.rpc('restore_equipment_availability', {
        p_equipment_id: equipmentId,
        p_disruption_id: disruptionId ?? null,
      });
      if (error) {
        throw new Error(`Failed to restore equipment availability: ${error.message}`);
      }
      return;
    }

    await equipmentService.updateStatus(equipmentId, 'Available');
    if (disruptionId) {
      demoDisruptionStore = demoDisruptionStore.map((d) =>
        d.id === disruptionId ? { ...d, status: 'Mitigated' } : d
      );
    }
  },
};
