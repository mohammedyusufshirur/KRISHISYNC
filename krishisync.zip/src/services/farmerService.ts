import { WEEKLY_OPERATIONS_DEMO } from '../data/mockData';
import { requireSupabaseClient } from '../lib/supabaseClient';
import { FarmerDashboardData, User } from '../types/domain';
import { isDemoModeActive, simulateNetworkDelay } from './apiConfig';
import { requireVerifiedTable } from './backendContract';
import { bookingService } from './bookingService';
import { equipmentService } from './equipmentService';
import { plotService } from './plotService';

export const farmerService = {
  async getProfile(farmerId: string): Promise<Partial<User> | null> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('profiles');
      const { data, error } = await client
        .from(tableName)
        .select('*')
        .eq(columns.id, farmerId)
        .maybeSingle();

      if (error) {
        throw new Error(`Failed to fetch farmer profile: ${error.message}`);
      }
      if (!data) return null;
      const row = data as Record<string, unknown>;
      return {
        id: String(row[columns.id]),
        name: String(row[columns.name] ?? ''),
        email: String(row[columns.email] ?? ''),
        phone: String(row[columns.phone] ?? ''),
        region: String(row[columns.address] ?? ''),
      };
    }

    await simulateNetworkDelay(120);
    return null;
  },

  async getDashboardData(): Promise<FarmerDashboardData> {
    if (!isDemoModeActive()) {
      const [bookings, equipment, plots] = await Promise.all([
        bookingService.list(),
        equipmentService.list(),
        plotService.list(),
      ]);

      const upcomingOperations = bookings.filter(
        (b) =>
          b.status === 'Confirmed' ||
          b.status === 'Scheduled' ||
          b.status === 'In Progress' ||
          b.status === 'Pending'
      ).length;

      const urgentThreshold = new Date(Date.now() + 1000 * 60 * 60 * 24 * 3)
        .toISOString()
        .slice(0, 10);

      const urgentDeadlines = plots.filter((p) => p.deadline <= urgentThreshold).length;

      const availableEquipmentCount = equipment.filter((e) => e.status === 'Available').length;

      const recentActivities = bookings.slice(0, 5).map((b) => ({
        id: `act-${b.id}`,
        title: `${b.operationType} · ${b.plotName}`,
        detail: `${b.equipmentName} — ${b.status}`,
        timestamp: b.requestedDate,
      }));

      // Aggregate live booking hours/acres per weekday when backend data is active
      const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const bucketMap = new Map<string, { scheduledHours: number; completedAcres: number }>();
      days.forEach((d) => bucketMap.set(d, { scheduledHours: 0, completedAcres: 0 }));

      bookings.forEach((b) => {
        const dt = new Date(b.requestedDate);
        if (!Number.isNaN(dt.getTime())) {
          const dayName = days[dt.getDay()];
          const bucket = bucketMap.get(dayName)!;
          bucket.scheduledHours += b.estimatedHours;
          if (b.status === 'Completed') {
            bucket.completedAcres += b.plotAreaAcres;
          }
        }
      });

      const weeklyOperationsChart = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(
        (day) => ({
          day,
          ...(bucketMap.get(day) ?? { scheduledHours: 0, completedAcres: 0 }),
        })
      );

      return {
        metrics: {
          totalBookings: bookings.length,
          upcomingOperations,
          urgentDeadlines,
          availableEquipmentCount,
        },
        weeklyOperationsChart,
        recentActivities,
      };
    }

    await simulateNetworkDelay(180);
    const bookings = bookingService.getSnapshot();
    const equipment = equipmentService.getSnapshot();
    const plots = plotService.getSnapshot();

    const upcomingOperations = bookings.filter(
      (b) =>
        b.status === 'Confirmed' ||
        b.status === 'Scheduled' ||
        b.status === 'In Progress' ||
        b.status === 'Pending'
    ).length;

    const urgentThreshold = new Date(Date.now() + 1000 * 60 * 60 * 24 * 3)
      .toISOString()
      .slice(0, 10);
    const urgentDeadlines = plots.filter((p) => p.deadline <= urgentThreshold).length;
    const availableEquipmentCount = equipment.filter((e) => e.status === 'Available').length;

    const recentActivities = bookings.slice(0, 5).map((b) => ({
      id: `act-${b.id}`,
      title: `${b.operationType} · ${b.plotName}`,
      detail: `${b.equipmentName} — ${b.status}`,
      timestamp: b.requestedDate,
    }));

    return {
      metrics: {
        totalBookings: bookings.length,
        upcomingOperations,
        urgentDeadlines,
        availableEquipmentCount,
      },
      weeklyOperationsChart: WEEKLY_OPERATIONS_DEMO,
      recentActivities,
    };
  },
};
