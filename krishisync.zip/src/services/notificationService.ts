import { INITIAL_NOTIFICATIONS } from '../data/mockData';
import { requireSupabaseClient } from '../lib/supabaseClient';
import { AppNotification, NotificationCategory } from '../types/domain';
import { isDemoModeActive, simulateNetworkDelay } from './apiConfig';
import { requireVerifiedTable } from './backendContract';

let demoNotificationStore: AppNotification[] = [...INITIAL_NOTIFICATIONS];

function toFrontendNotificationCategory(raw: unknown): NotificationCategory {
  switch (String(raw ?? '').toLowerCase()) {
    case 'deadline_warning':
      return 'Urgent Deadline';
    case 'equipment_breakdown':
    case 'weather_disruption':
    case 'rescheduling':
      return 'Rescheduling';
    default:
      return 'Booking Update';
  }
}

function toFrontendNotificationSeverity(raw: unknown): AppNotification['severity'] {
  switch (String(raw ?? '').toLowerCase()) {
    case 'equipment_breakdown':
    case 'weather_disruption':
      return 'critical';
    case 'deadline_warning':
    case 'rescheduling':
      return 'warning';
    default:
      return 'info';
  }
}

function mapNotificationRow(
  row: Record<string, unknown>,
  cols: {
    id: string;
    userId: string;
    category: string;
    title: string;
    message: string;
    relatedBookingId: string;
    read: string;
  }
): AppNotification {
  const rawType = row[cols.category];
  return {
    id: String(row[cols.id]),
    category: toFrontendNotificationCategory(rawType),
    severity: toFrontendNotificationSeverity(rawType),
    title: String(row[cols.title] ?? ''),
    message: String(row[cols.message] ?? ''),
    timestamp: String(row.created_at ?? new Date().toISOString()),
    read: Boolean(row[cols.read]),
    actionRoute: String(row.action_route ?? '/app/notifications'),
    actionLabel: String(row.action_label ?? 'Open'),
    relatedId:
      typeof row[cols.relatedBookingId] === 'string'
        ? (row[cols.relatedBookingId] as string)
        : undefined,
  };
}

export const notificationService = {
  async list(): Promise<AppNotification[]> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('notifications');
      const { data, error } = await client
        .from(tableName)
        .select('*')
        .order('created_at', { ascending: false });
      if (error) {
        throw new Error(`Failed to fetch notifications from ${tableName}: ${error.message}`);
      }
      return ((data ?? []) as Record<string, unknown>[]).map((r) =>
        mapNotificationRow(r, columns)
      );
    }

    await simulateNetworkDelay(120);
    return [...demoNotificationStore];
  },

  async markAsRead(id: string): Promise<AppNotification[]> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('notifications');
      const { error } = await client
        .from(tableName)
        .update({ [columns.read]: true })
        .eq(columns.id, id);
      if (error) {
        throw new Error(`Failed to mark notification as read: ${error.message}`);
      }
      return this.list();
    }

    await simulateNetworkDelay(100);
    demoNotificationStore = demoNotificationStore.map((n) =>
      n.id === id ? { ...n, read: true } : n
    );
    return [...demoNotificationStore];
  },

  async markAllRead(): Promise<AppNotification[]> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('notifications');
      const { error } = await client
        .from(tableName)
        .update({ [columns.read]: true })
        .eq(columns.read, false);
      if (error) {
        throw new Error(`Failed to mark all notifications as read: ${error.message}`);
      }
      return this.list();
    }

    await simulateNetworkDelay(120);
    demoNotificationStore = demoNotificationStore.map((n) => ({ ...n, read: true }));
    return [...demoNotificationStore];
  },

  async dismiss(id: string): Promise<AppNotification[]> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('notifications');
      const { error } = await client.from(tableName).delete().eq(columns.id, id);
      if (error) {
        throw new Error(`Failed to dismiss notification: ${error.message}`);
      }
      return this.list();
    }

    await simulateNetworkDelay(100);
    demoNotificationStore = demoNotificationStore.filter((n) => n.id !== id);
    return [...demoNotificationStore];
  },

  pushNotification(notification: Omit<AppNotification, 'id' | 'timestamp' | 'read'>): void {
    if (!isDemoModeActive()) {
      // In production mode, notifications are persisted/emitted by backend triggers/endpoints.
      return;
    }
    const created: AppNotification = {
      ...notification,
      id: `notif-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString(),
      read: false,
    };
    demoNotificationStore = [created, ...demoNotificationStore];
  },
};
