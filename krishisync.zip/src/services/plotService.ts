import { INITIAL_PLOTS } from '../data/mockData';
import { requireSupabaseClient } from '../lib/supabaseClient';
import { CropType, OperationType, Plot, PlotInput } from '../types/domain';
import { isDemoModeActive, simulateNetworkDelay } from './apiConfig';
import { requireVerifiedTable } from './backendContract';

let demoPlotStore: Plot[] = [...INITIAL_PLOTS];

function mapPlotRow(
  row: Record<string, unknown>,
  cols: {
    id: string;
    farmerId: string;
    name: string;
    areaAcres: string;
    cropType: string;
    locationLabel: string;
    lat: string;
    lng: string;
    operationType: string;
    deadline: string;
  }
): Plot {
  return {
    id: String(row[cols.id]),
    farmerId: String(row[cols.farmerId] ?? ''),
    farmerName: String(row.farmer_name ?? 'Farmer'),
    name: String(row[cols.name] ?? ''),
    areaAcres: Number(row[cols.areaAcres] ?? 0),
    cropType: (row[cols.cropType] as CropType) ?? 'Wheat',
    locationLabel: String(row[cols.locationLabel] ?? ''),
    coordinates: {
      lat: Number(row[cols.lat] ?? 0),
      lng: Number(row[cols.lng] ?? 0),
    },
    operationType: (row[cols.operationType] as OperationType) ?? 'Sowing',
    deadline: String(row[cols.deadline] ?? '').slice(0, 10),
    soilMoisturePercent: Number(row.soil_moisture_percent ?? 0),
    notes: String(row.notes ?? ''),
  };
}

export const plotService = {
  async list(): Promise<Plot[]> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('plots');
      const { data, error } = await client.from(tableName).select('*');
      if (error) {
        throw new Error(`Failed to fetch plots from ${tableName}: ${error.message}`);
      }
      return ((data ?? []) as Record<string, unknown>[]).map((r) =>
        mapPlotRow(r, columns)
      );
    }

    await simulateNetworkDelay(160);
    return [...demoPlotStore];
  },

  async create(input: PlotInput, farmerId: string, farmerName: string): Promise<Plot> {
    if (!input.name.trim() || input.areaAcres <= 0 || !input.deadline) {
      throw new Error('Plot name, valid acreage, and operational deadline are required.');
    }

    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('plots');
      const insertRow: Record<string, unknown> = {
        [columns.farmerId]: farmerId,
        [columns.name]: input.name.trim(),
        [columns.areaAcres]: input.areaAcres,
        [columns.cropType]: input.cropType,
        [columns.locationLabel]: input.locationLabel.trim(),
        [columns.lat]: input.coordinates.lat,
        [columns.lng]: input.coordinates.lng,
        [columns.operationType]: input.operationType,
        [columns.deadline]: input.deadline,
      };
      const { data, error } = await client
        .from(tableName)
        .insert(insertRow)
        .select('*')
        .single();
      if (error) {
        throw new Error(`Failed to create plot in ${tableName}: ${error.message}`);
      }
      return mapPlotRow(data as Record<string, unknown>, columns);
    }

    await simulateNetworkDelay(200);
    const created: Plot = {
      ...input,
      id: `plot-${Date.now().toString().slice(-4)}`,
      farmerId,
      farmerName,
    };
    demoPlotStore = [created, ...demoPlotStore];
    return created;
  },

  async update(id: string, patch: Partial<PlotInput>): Promise<Plot> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('plots');
      const updatePayload: Record<string, unknown> = {};
      if (patch.name !== undefined) updatePayload[columns.name] = patch.name;
      if (patch.areaAcres !== undefined) updatePayload[columns.areaAcres] = patch.areaAcres;
      if (patch.cropType !== undefined) updatePayload[columns.cropType] = patch.cropType;
      if (patch.locationLabel !== undefined) {
        updatePayload[columns.locationLabel] = patch.locationLabel;
      }
      if (patch.coordinates !== undefined) {
        updatePayload[columns.lat] = patch.coordinates.lat;
        updatePayload[columns.lng] = patch.coordinates.lng;
      }
      if (patch.operationType !== undefined) {
        updatePayload[columns.operationType] = patch.operationType;
      }
      if (patch.deadline !== undefined) updatePayload[columns.deadline] = patch.deadline;

      const { data, error } = await client
        .from(tableName)
        .update(updatePayload)
        .eq(columns.id, id)
        .select('*')
        .single();
      if (error) {
        throw new Error(`Failed to update plot ${id}: ${error.message}`);
      }
      return mapPlotRow(data as Record<string, unknown>, columns);
    }

    await simulateNetworkDelay(160);
    const existing = demoPlotStore.find((p) => p.id === id);
    if (!existing) throw new Error(`Plot ${id} not found.`);
    const updated: Plot = { ...existing, ...patch };
    demoPlotStore = demoPlotStore.map((p) => (p.id === id ? updated : p));
    return updated;
  },

  async remove(id: string): Promise<void> {
    if (!isDemoModeActive()) {
      const client = requireSupabaseClient();
      const { tableName, columns } = requireVerifiedTable('plots');
      const { error } = await client.from(tableName).delete().eq(columns.id, id);
      if (error) {
        throw new Error(`Failed to delete plot ${id}: ${error.message}`);
      }
      return;
    }

    await simulateNetworkDelay(140);
    demoPlotStore = demoPlotStore.filter((p) => p.id !== id);
  },

  getSnapshot(): Plot[] {
    return [...demoPlotStore];
  },
};
