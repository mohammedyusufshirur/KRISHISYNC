# KRISHISYNC Scheduling Engine Integration Guide (Member 3)

Member 3's scheduling and optimization engine should never connect directly with browser credentials or bypass PostgreSQL conflict locks. Instead, integrate via the dedicated **`scheduler-bridge`** Supabase Edge Function located at `supabase/functions/scheduler-bridge/index.ts`.

---

## 1. Deploy the `scheduler-bridge` Edge Function

Using the Supabase CLI:

```bash
supabase login
supabase link --project-ref YOUR-PROJECT-REF

# Generate a strong shared secret for Member 3's scheduling service
supabase secrets set SCHEDULER_ENGINE_API_KEY="replace-with-strong-random-secret"

# Deploy the Edge Function
supabase functions deploy scheduler-bridge
```

> **Note:** Supabase Edge Functions automatically receive `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` from the Supabase runtime environment. Never expose either secret to the frontend.

---

## 2. Authentication Header Required by `scheduler-bridge`

Every request from Member 3's engine must include:

```http
x-scheduler-api-key: <SCHEDULER_ENGINE_API_KEY>
Content-Type: application/json
```

Base URL:

```text
https://YOUR-PROJECT-REF.supabase.co/functions/v1/scheduler-bridge
```

---

## 3. Endpoints Exposed for Member 3

### A. Fetch Pending & Rescheduling Bookings
`GET /functions/v1/scheduler-bridge?action=pending-bookings`

Returns bookings in `pending`, `accepted`, or `rescheduling_required` status joined with `plots` and `equipment`, ordered by `priority_score DESC, requested_deadline ASC`.

### B. Fetch Eligible Equipment
`GET /functions/v1/scheduler-bridge?action=available-equipment`

Returns equipment in `available` or `booked` status (excludes `maintenance` and `unavailable`).

### C. Fetch Equipment & Plot Coordinates
`GET /functions/v1/scheduler-bridge?action=locations`

Returns `{ equipmentLocations: [...], plotLocations: [...] }` with `latitude`, `longitude`, `address`, `area_acres`, and `deadline`.

### D. Fetch Existing Active Schedules
`GET /functions/v1/scheduler-bridge?action=existing-schedules`

Returns all active `schedules` (`scheduled`, `in_progress`, `rescheduling_required`) so Member 3 avoids occupied machine windows and plans travel buffers accurately.

### E. Save Optimized Schedule Allocations
`POST /functions/v1/scheduler-bridge?action=save-schedules`

Request body:

```json
{
  "allocations": [
    {
      "booking_id": "uuid-of-booking",
      "equipment_id": "uuid-of-equipment",
      "scheduled_start": "2026-11-18T08:00:00Z",
      "scheduled_end": "2026-11-18T11:30:00Z",
      "travel_buffer_minutes": 25,
      "estimated_travel_distance_km": 9.4,
      "scheduling_reason": "Minimized transit distance with priority-deadline fit"
    }
  ]
}
```

---

## 4. Concurrency & Double-Booking Guarantees

Each item in `allocations` invokes the transactional PostgreSQL function `public.save_schedule_allocation(...)`:
1. Locks the target `bookings` row and `equipment` row (`FOR UPDATE`).
2. Upserts into `public.schedules`.
3. Enforces the PostgreSQL GIST exclusion constraint `excl_no_overlapping_equipment_schedule` on `(equipment_id, tstzrange(scheduled_start, scheduled_end, '[)')) WHERE (status IN ('scheduled', 'in_progress'))`.
4. If an overlapping slot is submitted concurrently, PostgreSQL rejects the conflicting write with SQLSTATE `23P01` (`exclusion_violation`) so a machine can never be double-booked.
5. Updates `bookings.status = 'scheduled'`, `assigned_start_time`, and `assigned_end_time`, which triggers an automatic Realtime notification to the farmer.

---

## 5. Connecting Member 3's Optimizer Back to the Frontend

Once Member 3 deploys their HTTP API (`VITE_SCHEDULER_API_URL`), populate the `path` and `verified: true` values inside `BACKEND_CONTRACT.schedulerEndpoints` in `src/services/backendContract.ts` for:
- `getCurrentSchedule`
- `generateSchedule`
- `resolveConflict`
- `reportDisruptionReschedule`
- `applyRevisedSchedule`
