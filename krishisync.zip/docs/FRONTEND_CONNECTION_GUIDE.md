# KRISHISYNC Frontend Connection Guide

This guide explains how Member 1's React frontend connects to Member 2's Supabase PostgreSQL backend.

---

## 1. Apply Database Migrations in Supabase

1. Open your project in the **Supabase Dashboard** -> **SQL Editor**.
2. Execute the migration files in `supabase/migrations/` in exact numeric order:
   1. `001_extensions_and_types.sql`
   2. `002_profiles_and_auth.sql`
   3. `003_equipment_and_plots.sql`
   4. `004_bookings_and_schedules.sql`
   5. `005_disruptions_and_notifications.sql`
   6. `006_rls_policies.sql`
3. *(Optional for staging/demo)* Run `supabase/seed/001_sample_data.sql` to create two demo accounts (`farmer.demo@krishisync.in` and `owner.demo@krishisync.in`, password `KrishiSync@2026`), sample equipment, plots, bookings, schedules, and notifications.

---

## 2. Configure Authentication in Supabase Dashboard

1. Go to **Authentication -> Providers -> Email** and enable Email/Password sign-in.
2. For hackathon demos without email verification delays, you may disable **Confirm email** under **Authentication -> Providers -> Email**.
3. Go to **Authentication -> URL Configuration** and add your local/deployed app URL (e.g., `http://localhost:3000`) to **Site URL** and **Redirect URLs** (for password resets).

---

## 3. Set Frontend Environment Variables

Copy `.env.example` to `.env` (or configure secrets in AI Studio):

```env
VITE_SUPABASE_URL="https://YOUR-PROJECT-REF.supabase.co"
VITE_SUPABASE_ANON_KEY="YOUR-PUBLIC-ANON-KEY"
VITE_SCHEDULER_API_URL="https://YOUR-SCHEDULER-ENGINE-URL"
```

> **Security Rule:** Only `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` belong in browser code. Never place `SUPABASE_SERVICE_ROLE_KEY` in `.env` variables prefixed with `VITE_`.

---

## 4. How the Frontend Connects

- **Central Supabase Client:** `src/lib/supabaseClient.ts` validates `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY` and initializes a single shared client (`supabase`). If credentials are missing, the frontend gracefully falls back to Demo Mode without crashing.
- **Verified Schema Contract:** `src/services/backendContract.ts` maps all frontend table operations (`profiles`, `equipment`, `plots`, `bookings`, `schedules`, `disruptions`, `notifications`) to the exact PostgreSQL tables and columns created by the migrations.
- **Direct Typed Backend Services:** You can also import Member 2's typed backend services directly from `src/backend`:

```ts
import {
  authBackendService,
  equipmentBackendService,
  plotBackendService,
  bookingBackendService,
  disruptionBackendService,
  notificationBackendService,
} from './backend';
```

---

## 5. Subscribing to Live Notifications (Supabase Realtime)

Migration `005` adds `public.notifications` to `supabase_realtime`. Subscribe inside a React `useEffect`:

```ts
useEffect(() => {
  if (!userId) return;
  const unsubscribe = notificationBackendService.subscribeToNotifications(
    userId,
    (newNotification) => {
      // Prepend newNotification to UI state
    }
  );
  return unsubscribe;
}, [userId]);
```
