# KRISHISYNC Backend API Documentation

All backend TypeScript services live in `src/backend/` and are exported via `src/backend/index.ts`. Every service method returns a consistent structured envelope:

```ts
export interface ServiceResponse<T> {
  success: boolean;
  data: T | null;
  error: string | null;
  meta?: {
    page: number;
    pageSize: number;
    total: number;
  };
}
```

---

## 1. Database Schema Overview (`supabase/migrations/`)

| Migration | Contents |
| :--- | :--- |
| `001_extensions_and_types.sql` | Extensions (`pgcrypto`, `btree_gist`), PostgreSQL enums, `set_updated_at()` trigger |
| `002_profiles_and_auth.sql` | `profiles` table, `is_admin()`, `handle_new_user()` signup trigger, `prevent_role_escalation()` trigger |
| `003_equipment_and_plots.sql` | `equipment` and `plots` tables with lat/lng range checks & indexes |
| `004_bookings_and_schedules.sql` | `bookings`, `booking_history`, `schedules` (with GIST double-booking exclusion constraint), `create_booking_request`, `respond_to_booking`, `save_schedule_allocation` RPCs |
| `005_disruptions_and_notifications.sql` | `disruptions`, `notifications`, Supabase Realtime publication, `notify_on_booking_change()` trigger, `report_disruption_tx`, `restore_equipment_availability` RPCs |
| `006_rls_policies.sql` | Row Level Security (RLS) enabled and enforced across all 8 tables |

---

## 2. Authentication Service (`authBackendService`)

- `registerUser(input: RegisterUserInput)` — Registers via `supabase.auth.signUp`. Coerces role strictly to `'farmer'` or `'equipment_owner'` (never `'admin'`). The `handle_new_user()` DB trigger creates the `profiles` row automatically.
- `loginUser({ email, password })` — Signs in via `signInWithPassword` and loads the authenticated user's `profiles` row. Returns `{ accessToken, profile }`.
- `logoutUser()` — Signs out the active Supabase Auth session.
- `getCurrentUser()` — Returns the currently authenticated `ProfileRow | null`.
- `resetPassword(email, redirectTo?)` — Triggers Supabase password reset email.
- `updateProfile(patch)` — Updates `full_name`, `phone`, `address`, `latitude`, `longitude` for the current user (`role` escalation is blocked by both RLS `WITH CHECK` and `prevent_role_escalation()` trigger).

---

## 3. Equipment Service (`equipmentBackendService`)

- `createEquipment(input)` — Registers a new machine owned by `auth.uid()`. Validates coordinates (`-90..90`, `-180..180`), `work_rate_acres_per_hour > 0`, and non-negative rates.
- `getEquipment(filters?)` — Paginated search & filter by `equipment_type`, `availability_status`, and case-insensitive `search` across name/brand/model/address.
- `getOwnerEquipment(ownerId?, pagination?)` — Lists machines belonging to an equipment owner.
- `updateEquipment(equipmentId, patch)` — Owner-scoped update (enforced by RLS).
- `deleteEquipment(equipmentId)` — Owner-scoped delete (blocked by `ON DELETE RESTRICT` if active bookings/schedules reference the machine).
- `checkEquipmentAvailability(equipmentId, windowStartIso, windowEndIso)` — Checks machine status and overlapping active `schedules` in the requested UTC window.

---

## 4. Farm Plot Service (`plotBackendService`)

- `createPlot(input)` — Registers a plot owned by `auth.uid()` with acreage, crop type, operation type, coordinates, optional `preferred_start_time`, and `deadline`.
- `getFarmerPlots(farmerId?, pagination?)` — Lists plots ordered by earliest `deadline`.
- `getPlotById(plotId)` — Fetches a single plot (accessible to plot farmer, admins, or owners booked for that plot).
- `updatePlot(plotId, patch)` — Updates plot details (farmer-scoped via RLS).
- `deletePlot(plotId)` — Deletes plot (farmer-scoped via RLS).

---

## 5. Booking Service (`bookingBackendService`)

- `createBooking(input)` — Calls PostgreSQL RPC `create_booking_request`:
  - Computes `estimated_duration_hours = GREATEST(0.5, area_acres / work_rate_acres_per_hour)`.
  - Checks active `schedules` for overlapping machine time slots.
  - Inserts `bookings` (`status = 'pending'`), inserts `booking_history`, and triggers an automatic `notifications` row for the equipment owner.
- `getFarmerBookings(farmerId?, pagination?)` — Lists bookings belonging to the farmer.
- `getOwnerBookings(ownerId?, pagination?)` — Lists incoming booking requests for the owner's fleet.
- `acceptBooking(bookingId)` — Calls `respond_to_booking(bookingId, 'accept', null)` (owner-only). Transitions `pending` -> `accepted` and notifies the farmer.
- `rejectBooking(bookingId, rejectionReason)` — Calls `respond_to_booking(bookingId, 'reject', reason)` (owner-only). Transitions `pending` -> `rejected` and notifies the farmer.
- `cancelBooking(bookingId)` / `updateBookingStatus(bookingId, status)` — Updates booking status (RLS restricts farmers to cancelling their own bookings).
- `getBookingHistory(bookingId)` — Returns immutable audit log entries from `booking_history`.

---

## 6. Scheduling Service (`schedulingBackendService`)

- `getPendingBookings(pagination?)` — Returns bookings with status `pending`, `accepted`, or `rescheduling_required`, sorted by `priority_score DESC, requested_deadline ASC`.
- `getAvailableEquipment(pagination?)` — Returns machines in `available` or `booked` state.
- `getEquipmentLocations()` / `getPlotLocations()` — Geospatial coordinates for distance/route calculations.
- `getEquipmentSchedule(equipmentId?, pagination?)` — Lists allocated `schedules` ordered by `scheduled_start`.
- `saveSchedule(input)` — Calls `save_schedule_allocation` RPC. Protected by row locks and PostgreSQL GIST exclusion constraint (`excl_no_overlapping_equipment_schedule`) to guarantee zero overlapping slots per machine.
- `updateSchedule(scheduleId, patch)` — Updates an existing schedule window or status.

---

## 7. Disruption Service (`disruptionBackendService`)

- `reportDisruption(input)` — Calls `report_disruption_tx` RPC:
  - Inserts into `disruptions` (`status = 'active'`).
  - Sets affected equipment `availability_status` to `'maintenance'` (on `machine_breakdown`) or `'unavailable'`.
  - **Preserves confirmed bookings** — never deletes or cancels them; transitions overlapping active `schedules` and `bookings` to `'rescheduling_required'` and notifies affected farmers via trigger.
- `getDisruptions(statusFilter?, pagination?)` — Lists disruption incidents.
- `getAffectedBookings(equipmentId?)` — Lists all bookings currently in `'rescheduling_required'` status.
- `restoreEquipmentAvailability(equipmentId, disruptionId?)` — Calls `restore_equipment_availability` RPC to return a repaired machine to `'available'` and optionally mark the disruption `'resolved'`.

---

## 8. Notification Service (`notificationBackendService`)

- `createNotification(input)` — Inserts a notification record (admin/server context).
- `getNotifications(userId?, pagination?)` — Lists the user's notifications ordered newest-first.
- `markNotificationRead(notificationId)` / `markAllNotificationsRead(userId?)` — Marks notification(s) `is_read = true`.
- `subscribeToNotifications(userId, callback)` — Subscribes to Supabase Realtime `postgres_changes` (`INSERT`) on `public.notifications` filtered by `user_id=eq.${userId}`. Returns an unsubscribe function.
