// Supabase Edge Function: scheduler-bridge
// Purpose: Secure HTTP API for Member 3's Scheduling & Optimization Engine.
// Uses SUPABASE_SERVICE_ROLE_KEY strictly server-side inside Deno Edge Runtime.

import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.49.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-scheduler-api-key',
  'Access-Control-Allow-Methods': 'GET, POST, PATCH, OPTIONS',
};

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  const expectedApiKey = Deno.env.get('SCHEDULER_ENGINE_API_KEY');
  const providedApiKey = req.headers.get('x-scheduler-api-key');

  if (!expectedApiKey || providedApiKey !== expectedApiKey) {
    return jsonResponse(
      { success: false, data: null, error: 'Unauthorized: invalid scheduler engine API key.' },
      401
    );
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!supabaseUrl || !serviceRoleKey) {
    return jsonResponse(
      { success: false, data: null, error: 'Server misconfiguration: missing Supabase environment.' },
      500
    );
  }

  const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false },
  });

  const url = new URL(req.url);
  const action = url.searchParams.get('action') ?? '';

  try {
    if (req.method === 'GET' && action === 'pending-bookings') {
      const { data, error } = await supabaseAdmin
        .from('bookings')
        .select('*, plot:plots(*), equipment:equipment(*)')
        .in('status', ['pending', 'accepted', 'rescheduling_required'])
        .order('priority_score', { ascending: false })
        .order('requested_deadline', { ascending: true });
      if (error) throw error;
      return jsonResponse({ success: true, data, error: null });
    }

    if (req.method === 'GET' && action === 'available-equipment') {
      const { data, error } = await supabaseAdmin
        .from('equipment')
        .select('*')
        .in('availability_status', ['available', 'booked']);
      if (error) throw error;
      return jsonResponse({ success: true, data, error: null });
    }

    if (req.method === 'GET' && action === 'locations') {
      const [eqRes, plotRes] = await Promise.all([
        supabaseAdmin.from('equipment').select('id, equipment_name, equipment_type, latitude, longitude, address, availability_status'),
        supabaseAdmin.from('plots').select('id, plot_name, area_acres, latitude, longitude, address, deadline'),
      ]);
      if (eqRes.error) throw eqRes.error;
      if (plotRes.error) throw plotRes.error;
      return jsonResponse({
        success: true,
        data: { equipmentLocations: eqRes.data, plotLocations: plotRes.data },
        error: null,
      });
    }

    if (req.method === 'GET' && action === 'existing-schedules') {
      const { data, error } = await supabaseAdmin
        .from('schedules')
        .select('*')
        .in('status', ['scheduled', 'in_progress', 'rescheduling_required'])
        .order('scheduled_start', { ascending: true });
      if (error) throw error;
      return jsonResponse({ success: true, data, error: null });
    }

    if (req.method === 'POST' && action === 'save-schedules') {
      const payload = (await req.json()) as {
        allocations: Array<{
          booking_id: string;
          equipment_id: string;
          scheduled_start: string;
          scheduled_end: string;
          travel_buffer_minutes?: number;
          estimated_travel_distance_km?: number;
          scheduling_reason?: string;
        }>;
      };

      if (!Array.isArray(payload.allocations) || payload.allocations.length === 0) {
        return jsonResponse(
          { success: false, data: null, error: 'allocations array is required.' },
          400
        );
      }

      const saved = [];
      for (const item of payload.allocations) {
        const { data, error } = await supabaseAdmin.rpc('save_schedule_allocation', {
          p_booking_id: item.booking_id,
          p_equipment_id: item.equipment_id,
          p_scheduled_start: item.scheduled_start,
          p_scheduled_end: item.scheduled_end,
          p_travel_buffer_minutes: item.travel_buffer_minutes ?? 0,
          p_estimated_travel_distance_km: item.estimated_travel_distance_km ?? 0,
          p_scheduling_reason: item.scheduling_reason ?? '',
        });
        if (error) throw error;
        saved.push(data);
      }

      return jsonResponse({ success: true, data: saved, error: null });
    }

    return jsonResponse(
      { success: false, data: null, error: `Unsupported method/action: ${req.method} ${action}` },
      400
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unexpected Edge Function error.';
    return jsonResponse({ success: false, data: null, error: message }, 500);
  }
});
