-- KRISHISYNC Migration 006: Complete Row Level Security (RLS) Policies

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.equipment ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.plots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.booking_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.disruptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- 1. PROFILES POLICIES
DROP POLICY IF EXISTS "profiles_select_own_or_admin" ON public.profiles;
CREATE POLICY "profiles_select_own_or_admin"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id OR public.is_admin());

-- Allow authenticated users to view basic counterparty profile info on active bookings
DROP POLICY IF EXISTS "profiles_select_booking_counterparty" ON public.profiles;
CREATE POLICY "profiles_select_booking_counterparty"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM public.bookings b
      JOIN public.equipment e ON e.id = b.equipment_id
      WHERE (b.farmer_id = profiles.id AND e.owner_id = auth.uid())
         OR (e.owner_id = profiles.id AND b.farmer_id = auth.uid())
    )
  );

DROP POLICY IF EXISTS "profiles_update_own_non_admin" ON public.profiles;
CREATE POLICY "profiles_update_own_non_admin"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id OR public.is_admin())
  WITH CHECK (
    (auth.uid() = id AND role <> 'admin')
    OR public.is_admin()
  );

-- 2. EQUIPMENT POLICIES
DROP POLICY IF EXISTS "equipment_select_authenticated" ON public.equipment;
CREATE POLICY "equipment_select_authenticated"
  ON public.equipment FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "equipment_insert_owner" ON public.equipment;
CREATE POLICY "equipment_insert_owner"
  ON public.equipment FOR INSERT
  TO authenticated
  WITH CHECK (
    (owner_id = auth.uid() AND EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role IN ('equipment_owner', 'admin')))
    OR public.is_admin()
  );

DROP POLICY IF EXISTS "equipment_update_owner_only" ON public.equipment;
CREATE POLICY "equipment_update_owner_only"
  ON public.equipment FOR UPDATE
  TO authenticated
  USING (owner_id = auth.uid() OR public.is_admin())
  WITH CHECK (owner_id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "equipment_delete_owner_only" ON public.equipment;
CREATE POLICY "equipment_delete_owner_only"
  ON public.equipment FOR DELETE
  TO authenticated
  USING (owner_id = auth.uid() OR public.is_admin());

-- 3. PLOTS POLICIES
DROP POLICY IF EXISTS "plots_select_farmer_or_booked_owner" ON public.plots;
CREATE POLICY "plots_select_farmer_or_booked_owner"
  ON public.plots FOR SELECT
  TO authenticated
  USING (
    farmer_id = auth.uid()
    OR public.is_admin()
    OR EXISTS (
      SELECT 1
      FROM public.bookings b
      JOIN public.equipment e ON e.id = b.equipment_id
      WHERE b.plot_id = plots.id AND e.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "plots_insert_farmer" ON public.plots;
CREATE POLICY "plots_insert_farmer"
  ON public.plots FOR INSERT
  TO authenticated
  WITH CHECK (farmer_id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "plots_update_farmer" ON public.plots;
CREATE POLICY "plots_update_farmer"
  ON public.plots FOR UPDATE
  TO authenticated
  USING (farmer_id = auth.uid() OR public.is_admin())
  WITH CHECK (farmer_id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "plots_delete_farmer" ON public.plots;
CREATE POLICY "plots_delete_farmer"
  ON public.plots FOR DELETE
  TO authenticated
  USING (farmer_id = auth.uid() OR public.is_admin());

-- 4. BOOKINGS POLICIES
DROP POLICY IF EXISTS "bookings_select_farmer_or_owner" ON public.bookings;
CREATE POLICY "bookings_select_farmer_or_owner"
  ON public.bookings FOR SELECT
  TO authenticated
  USING (
    farmer_id = auth.uid()
    OR public.is_admin()
    OR EXISTS (
      SELECT 1 FROM public.equipment e
      WHERE e.id = bookings.equipment_id AND e.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "bookings_insert_farmer" ON public.bookings;
CREATE POLICY "bookings_insert_farmer"
  ON public.bookings FOR INSERT
  TO authenticated
  WITH CHECK (
    (farmer_id = auth.uid() AND status = 'pending')
    OR public.is_admin()
  );

-- Farmers may cancel their own pending/accepted bookings; owners may update requests for their equipment
DROP POLICY IF EXISTS "bookings_update_authorized" ON public.bookings;
CREATE POLICY "bookings_update_authorized"
  ON public.bookings FOR UPDATE
  TO authenticated
  USING (
    farmer_id = auth.uid()
    OR public.is_admin()
    OR EXISTS (
      SELECT 1 FROM public.equipment e
      WHERE e.id = bookings.equipment_id AND e.owner_id = auth.uid()
    )
  )
  WITH CHECK (
    public.is_admin()
    OR (farmer_id = auth.uid() AND status = 'cancelled')
    OR EXISTS (
      SELECT 1 FROM public.equipment e
      WHERE e.id = bookings.equipment_id AND e.owner_id = auth.uid()
    )
  );

-- 5. BOOKING HISTORY POLICIES
DROP POLICY IF EXISTS "booking_history_select_authorized" ON public.booking_history;
CREATE POLICY "booking_history_select_authorized"
  ON public.booking_history FOR SELECT
  TO authenticated
  USING (
    public.is_admin()
    OR EXISTS (
      SELECT 1
      FROM public.bookings b
      LEFT JOIN public.equipment e ON e.id = b.equipment_id
      WHERE b.id = booking_history.booking_id
        AND (b.farmer_id = auth.uid() OR e.owner_id = auth.uid())
    )
  );

-- 6. SCHEDULES POLICIES
DROP POLICY IF EXISTS "schedules_select_participants" ON public.schedules;
CREATE POLICY "schedules_select_participants"
  ON public.schedules FOR SELECT
  TO authenticated
  USING (
    farmer_id = auth.uid()
    OR public.is_admin()
    OR EXISTS (
      SELECT 1 FROM public.equipment e
      WHERE e.id = schedules.equipment_id AND e.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "schedules_admin_write" ON public.schedules;
CREATE POLICY "schedules_admin_write"
  ON public.schedules FOR ALL
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- 7. DISRUPTIONS POLICIES
DROP POLICY IF EXISTS "disruptions_select_authenticated" ON public.disruptions;
CREATE POLICY "disruptions_select_authenticated"
  ON public.disruptions FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "disruptions_insert_authenticated" ON public.disruptions;
CREATE POLICY "disruptions_insert_authenticated"
  ON public.disruptions FOR INSERT
  TO authenticated
  WITH CHECK (reported_by = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "disruptions_update_reporter_or_owner" ON public.disruptions;
CREATE POLICY "disruptions_update_reporter_or_owner"
  ON public.disruptions FOR UPDATE
  TO authenticated
  USING (
    reported_by = auth.uid()
    OR public.is_admin()
    OR EXISTS (
      SELECT 1 FROM public.equipment e
      WHERE e.id = disruptions.equipment_id AND e.owner_id = auth.uid()
    )
  );

-- 8. NOTIFICATIONS POLICIES
DROP POLICY IF EXISTS "notifications_select_own" ON public.notifications;
CREATE POLICY "notifications_select_own"
  ON public.notifications FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "notifications_update_own" ON public.notifications;
CREATE POLICY "notifications_update_own"
  ON public.notifications FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid() OR public.is_admin())
  WITH CHECK (user_id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "notifications_delete_own" ON public.notifications;
CREATE POLICY "notifications_delete_own"
  ON public.notifications FOR DELETE
  TO authenticated
  USING (user_id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "notifications_admin_insert" ON public.notifications;
CREATE POLICY "notifications_admin_insert"
  ON public.notifications FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());
