-- KRISHISYNC Migration 004: Bookings, Booking History, Schedules, Double-Booking Prevention & RPCs

CREATE TABLE IF NOT EXISTS public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  equipment_id UUID NOT NULL REFERENCES public.equipment(id) ON DELETE RESTRICT,
  plot_id UUID NOT NULL REFERENCES public.plots(id) ON DELETE RESTRICT,
  operation_type TEXT NOT NULL CHECK (char_length(trim(operation_type)) >= 2),
  requested_start_time TIMESTAMPTZ NOT NULL,
  requested_deadline TIMESTAMPTZ NOT NULL,
  estimated_duration_hours NUMERIC(8, 2) NOT NULL CHECK (estimated_duration_hours > 0),
  status public.booking_status_enum NOT NULL DEFAULT 'pending',
  priority_score NUMERIC(6, 2) NOT NULL DEFAULT 50 CHECK (priority_score >= 0 AND priority_score <= 100),
  assigned_start_time TIMESTAMPTZ,
  assigned_end_time TIMESTAMPTZ,
  rejection_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  CONSTRAINT chk_booking_deadline_after_start CHECK (requested_deadline >= requested_start_time),
  CONSTRAINT chk_booking_assigned_window CHECK (
    assigned_start_time IS NULL OR assigned_end_time IS NULL OR assigned_end_time > assigned_start_time
  )
);

CREATE INDEX IF NOT EXISTS idx_bookings_farmer_id ON public.bookings(farmer_id);
CREATE INDEX IF NOT EXISTS idx_bookings_equipment_id ON public.bookings(equipment_id);
CREATE INDEX IF NOT EXISTS idx_bookings_plot_id ON public.bookings(plot_id);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON public.bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_priority_deadline ON public.bookings(priority_score DESC, requested_deadline ASC);

DROP TRIGGER IF EXISTS trg_bookings_updated_at ON public.bookings;
CREATE TRIGGER trg_bookings_updated_at
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

-- Booking History Audit Table
CREATE TABLE IF NOT EXISTS public.booking_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
  previous_status public.booking_status_enum,
  new_status public.booking_status_enum NOT NULL,
  changed_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  note TEXT NOT NULL DEFAULT '',
  changed_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now())
);

CREATE INDEX IF NOT EXISTS idx_booking_history_booking_id ON public.booking_history(booking_id, changed_at DESC);

CREATE OR REPLACE FUNCTION public.log_booking_history()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.booking_history (booking_id, previous_status, new_status, changed_by, note)
    VALUES (NEW.id, NULL, NEW.status, auth.uid(), 'Booking request created');
  ELSIF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO public.booking_history (booking_id, previous_status, new_status, changed_by, note)
    VALUES (
      NEW.id,
      OLD.status,
      NEW.status,
      auth.uid(),
      coalesce(NEW.rejection_reason, 'Booking status updated')
    );
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_log_booking_history ON public.bookings;
CREATE TRIGGER trg_log_booking_history
  AFTER INSERT OR UPDATE ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.log_booking_history();

-- Schedules Table (populated by Member 3's Scheduling Engine via RPC / Edge Function)
CREATE TABLE IF NOT EXISTS public.schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL UNIQUE REFERENCES public.bookings(id) ON DELETE CASCADE,
  equipment_id UUID NOT NULL REFERENCES public.equipment(id) ON DELETE RESTRICT,
  farmer_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  plot_id UUID NOT NULL REFERENCES public.plots(id) ON DELETE RESTRICT,
  scheduled_start TIMESTAMPTZ NOT NULL,
  scheduled_end TIMESTAMPTZ NOT NULL,
  travel_buffer_minutes INTEGER NOT NULL DEFAULT 0 CHECK (travel_buffer_minutes >= 0),
  estimated_travel_distance_km NUMERIC(8, 2) NOT NULL DEFAULT 0 CHECK (estimated_travel_distance_km >= 0),
  status public.schedule_status_enum NOT NULL DEFAULT 'scheduled',
  scheduling_reason TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  CONSTRAINT chk_schedule_time_window CHECK (scheduled_end > scheduled_start),
  -- Hard PostgreSQL constraint preventing double-booking overlapping time slots per machine
  CONSTRAINT excl_no_overlapping_equipment_schedule EXCLUDE USING gist (
    equipment_id WITH =,
    tstzrange(scheduled_start, scheduled_end, '[)') WITH &&
  ) WHERE (status IN ('scheduled', 'in_progress'))
);

CREATE INDEX IF NOT EXISTS idx_schedules_equipment_window ON public.schedules(equipment_id, scheduled_start, scheduled_end);
CREATE INDEX IF NOT EXISTS idx_schedules_farmer_id ON public.schedules(farmer_id);
CREATE INDEX IF NOT EXISTS idx_schedules_status ON public.schedules(status);

DROP TRIGGER IF EXISTS trg_schedules_updated_at ON public.schedules;
CREATE TRIGGER trg_schedules_updated_at
  BEFORE UPDATE ON public.schedules
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

-- Transactional RPC: Create Booking with Server-Side Duration, Conflict Check & Notification
CREATE OR REPLACE FUNCTION public.create_booking_request(
  p_equipment_id UUID,
  p_plot_id UUID,
  p_operation_type TEXT,
  p_requested_start_time TIMESTAMPTZ,
  p_requested_deadline TIMESTAMPTZ,
  p_priority_score NUMERIC DEFAULT 50
)
RETURNS public.bookings
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_caller UUID := auth.uid();
  v_plot public.plots%ROWTYPE;
  v_equipment public.equipment%ROWTYPE;
  v_est_hours NUMERIC(8, 2);
  v_est_end TIMESTAMPTZ;
  v_conflict_count INTEGER;
  v_booking public.bookings%ROWTYPE;
BEGIN
  IF v_caller IS NULL THEN
    RAISE EXCEPTION 'Authentication required to create a booking.';
  END IF;

  IF p_requested_deadline < p_requested_start_time THEN
    RAISE EXCEPTION 'Requested deadline must be after or equal to requested start time.';
  END IF;

  SELECT * INTO v_plot FROM public.plots WHERE id = p_plot_id FOR SHARE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Plot not found.';
  END IF;
  IF v_plot.farmer_id <> v_caller AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'Permission denied: you may only book equipment for your own plots.';
  END IF;

  SELECT * INTO v_equipment FROM public.equipment WHERE id = p_equipment_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Equipment not found.';
  END IF;
  IF v_equipment.availability_status IN ('maintenance', 'unavailable') THEN
    RAISE EXCEPTION 'Selected equipment is currently unavailable (%).', v_equipment.availability_status;
  END IF;

  v_est_hours := GREATEST(0.5, ROUND((v_plot.area_acres / v_equipment.work_rate_acres_per_hour)::NUMERIC, 2));
  v_est_end := p_requested_start_time + make_interval(mins => CEIL(v_est_hours * 60)::INTEGER);

  SELECT COUNT(*) INTO v_conflict_count
  FROM public.schedules
  WHERE equipment_id = p_equipment_id
    AND status IN ('scheduled', 'in_progress')
    AND tstzrange(scheduled_start, scheduled_end, '[)') && tstzrange(p_requested_start_time, v_est_end, '[)');

  IF v_conflict_count > 0 THEN
    RAISE EXCEPTION 'Equipment already has a confirmed schedule overlapping this time window.';
  END IF;

  INSERT INTO public.bookings (
    farmer_id,
    equipment_id,
    plot_id,
    operation_type,
    requested_start_time,
    requested_deadline,
    estimated_duration_hours,
    status,
    priority_score
  )
  VALUES (
    v_plot.farmer_id,
    p_equipment_id,
    p_plot_id,
    p_operation_type,
    p_requested_start_time,
    p_requested_deadline,
    v_est_hours,
    'pending',
    COALESCE(p_priority_score, 50)
  )
  RETURNING * INTO v_booking;

  RETURN v_booking;
END;
$$;

-- Transactional RPC: Equipment Owner Accepts or Rejects Booking Request
CREATE OR REPLACE FUNCTION public.respond_to_booking(
  p_booking_id UUID,
  p_decision TEXT,
  p_rejection_reason TEXT DEFAULT NULL
)
RETURNS public.bookings
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_caller UUID := auth.uid();
  v_booking public.bookings%ROWTYPE;
  v_owner_id UUID;
BEGIN
  IF v_caller IS NULL THEN
    RAISE EXCEPTION 'Authentication required.';
  END IF;

  SELECT b.*, e.owner_id INTO v_booking
  FROM public.bookings b
  JOIN public.equipment e ON e.id = b.equipment_id
  WHERE b.id = p_booking_id
  FOR UPDATE OF b;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Booking not found.';
  END IF;

  SELECT owner_id INTO v_owner_id FROM public.equipment WHERE id = v_booking.equipment_id;
  IF v_owner_id <> v_caller AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'Permission denied: only the equipment owner may accept or reject this request.';
  END IF;

  IF v_booking.status <> 'pending' THEN
    RAISE EXCEPTION 'Only pending booking requests can be accepted or rejected (current status: %).', v_booking.status;
  END IF;

  IF p_decision = 'accept' THEN
    UPDATE public.bookings
    SET status = 'accepted', rejection_reason = NULL
    WHERE id = p_booking_id
    RETURNING * INTO v_booking;
  ELSIF p_decision = 'reject' THEN
    UPDATE public.bookings
    SET status = 'rejected', rejection_reason = COALESCE(NULLIF(trim(p_rejection_reason), ''), 'Declined by equipment owner')
    WHERE id = p_booking_id
    RETURNING * INTO v_booking;
  ELSE
    RAISE EXCEPTION 'Invalid decision "%". Expected "accept" or "reject".', p_decision;
  END IF;

  RETURN v_booking;
END;
$$;

-- Transactional RPC: Save or Upsert Schedule Allocation (Conflict-Safe via Row Lock + GIST Exclusion)
CREATE OR REPLACE FUNCTION public.save_schedule_allocation(
  p_booking_id UUID,
  p_equipment_id UUID,
  p_scheduled_start TIMESTAMPTZ,
  p_scheduled_end TIMESTAMPTZ,
  p_travel_buffer_minutes INTEGER DEFAULT 0,
  p_estimated_travel_distance_km NUMERIC DEFAULT 0,
  p_scheduling_reason TEXT DEFAULT ''
)
RETURNS public.schedules
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_schedule public.schedules%ROWTYPE;
BEGIN
  IF p_scheduled_end <= p_scheduled_start THEN
    RAISE EXCEPTION 'scheduled_end must be strictly after scheduled_start.';
  END IF;

  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Booking % not found.', p_booking_id;
  END IF;

  IF v_booking.status IN ('rejected', 'cancelled', 'completed') THEN
    RAISE EXCEPTION 'Cannot schedule booking in status %.', v_booking.status;
  END IF;

  -- Lock equipment row to serialize concurrent schedule writes
  PERFORM 1 FROM public.equipment WHERE id = p_equipment_id FOR UPDATE;

  INSERT INTO public.schedules (
    booking_id,
    equipment_id,
    farmer_id,
    plot_id,
    scheduled_start,
    scheduled_end,
    travel_buffer_minutes,
    estimated_travel_distance_km,
    status,
    scheduling_reason
  )
  VALUES (
    p_booking_id,
    p_equipment_id,
    v_booking.farmer_id,
    v_booking.plot_id,
    p_scheduled_start,
    p_scheduled_end,
    COALESCE(p_travel_buffer_minutes, 0),
    COALESCE(p_estimated_travel_distance_km, 0),
    'scheduled',
    COALESCE(p_scheduling_reason, '')
  )
  ON CONFLICT (booking_id) DO UPDATE SET
    equipment_id = EXCLUDED.equipment_id,
    scheduled_start = EXCLUDED.scheduled_start,
    scheduled_end = EXCLUDED.scheduled_end,
    travel_buffer_minutes = EXCLUDED.travel_buffer_minutes,
    estimated_travel_distance_km = EXCLUDED.estimated_travel_distance_km,
    status = 'scheduled',
    scheduling_reason = EXCLUDED.scheduling_reason
  RETURNING * INTO v_schedule;

  UPDATE public.bookings
  SET
    equipment_id = p_equipment_id,
    status = 'scheduled',
    assigned_start_time = p_scheduled_start,
    assigned_end_time = p_scheduled_end
  WHERE id = p_booking_id;

  RETURN v_schedule;
END;
$$;
