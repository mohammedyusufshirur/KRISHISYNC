-- KRISHISYNC Migration 003: Equipment and Farm Plots Tables

CREATE TABLE IF NOT EXISTS public.equipment (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  equipment_name TEXT NOT NULL CHECK (char_length(trim(equipment_name)) >= 2),
  equipment_type public.equipment_type_enum NOT NULL,
  brand TEXT NOT NULL DEFAULT '',
  model TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  work_rate_acres_per_hour NUMERIC(8, 2) NOT NULL CHECK (work_rate_acres_per_hour > 0),
  hourly_rate NUMERIC(10, 2) NOT NULL CHECK (hourly_rate >= 0),
  per_acre_rate NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (per_acre_rate >= 0),
  latitude DOUBLE PRECISION NOT NULL CHECK (latitude >= -90 AND latitude <= 90),
  longitude DOUBLE PRECISION NOT NULL CHECK (longitude >= -180 AND longitude <= 180),
  address TEXT NOT NULL DEFAULT '',
  availability_status public.equipment_availability_enum NOT NULL DEFAULT 'available',
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now())
);

CREATE INDEX IF NOT EXISTS idx_equipment_owner_id ON public.equipment(owner_id);
CREATE INDEX IF NOT EXISTS idx_equipment_type ON public.equipment(equipment_type);
CREATE INDEX IF NOT EXISTS idx_equipment_availability ON public.equipment(availability_status);
CREATE INDEX IF NOT EXISTS idx_equipment_coords ON public.equipment(latitude, longitude);

DROP TRIGGER IF EXISTS trg_equipment_updated_at ON public.equipment;
CREATE TRIGGER trg_equipment_updated_at
  BEFORE UPDATE ON public.equipment
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

-- Farm Plots Table
CREATE TABLE IF NOT EXISTS public.plots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  plot_name TEXT NOT NULL CHECK (char_length(trim(plot_name)) >= 2),
  area_acres NUMERIC(10, 2) NOT NULL CHECK (area_acres > 0),
  crop_type TEXT NOT NULL CHECK (char_length(trim(crop_type)) >= 2),
  operation_type TEXT NOT NULL CHECK (char_length(trim(operation_type)) >= 2),
  latitude DOUBLE PRECISION NOT NULL CHECK (latitude >= -90 AND latitude <= 90),
  longitude DOUBLE PRECISION NOT NULL CHECK (longitude >= -180 AND longitude <= 180),
  address TEXT NOT NULL DEFAULT '',
  preferred_start_time TIMESTAMPTZ,
  deadline TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  CONSTRAINT chk_plots_preferred_before_deadline CHECK (
    preferred_start_time IS NULL OR preferred_start_time <= deadline
  )
);

CREATE INDEX IF NOT EXISTS idx_plots_farmer_id ON public.plots(farmer_id);
CREATE INDEX IF NOT EXISTS idx_plots_deadline ON public.plots(deadline);
CREATE INDEX IF NOT EXISTS idx_plots_coords ON public.plots(latitude, longitude);

DROP TRIGGER IF EXISTS trg_plots_updated_at ON public.plots;
CREATE TRIGGER trg_plots_updated_at
  BEFORE UPDATE ON public.plots
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();
