-- KRISHISYNC Migration 005: Disruptions, Notifications, Realtime & Disruption Mitigation RPCs

CREATE TABLE IF NOT EXISTS public.disruptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  equipment_id UUID REFERENCES public.equipment(id) ON DELETE SET NULL,
  disruption_type public.disruption_type_enum NOT NULL,
  description TEXT NOT NULL CHECK (char_length(trim(description)) >= 3),
  start_time TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  end_time TIMESTAMPTZ,
  affected_area TEXT NOT NULL DEFAULT '',
  status public.disruption_status_enum NOT NULL DEFAULT 'active',
  reported_by UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now()),
  CONSTRAINT chk_disruption_window CHECK (end_time IS NULL OR end_time >= start_time)
);

CREATE INDEX IF NOT EXISTS idx_disruptions_equipment_id ON public.disruptions(equipment_id);
CREATE INDEX IF NOT EXISTS idx_disruptions_status ON public.disruptions(status);
CREATE INDEX IF NOT EXISTS idx_disruptions_window ON public.disruptions(start_time, end_time);

CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  notification_type public.notification_type_enum NOT NULL,
  related_booking_id UUID REFERENCES public.bookings(id) ON DELETE SET NULL,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc', now())
);

CREATE INDEX IF NOT EXISTS idx_notifications_user_unread ON public.notifications(user_id, is_read, created_at DESC);

-- Enable Supabase Realtime for live notification delivery
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime') THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_publication_tables
      WHERE pubname = 'supabase_realtime'
        AND schemaname = 'public'
        AND tablename = 'notifications'
    ) THEN
      ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
    END IF;
  END IF;
END
$$;

-- Trigger notifications automatically on booking lifecycle transitions
CREATE OR REPLACE FUNCTION public.notify_on_booking_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_owner_id UUID;
  v_eq_name TEXT;
BEGIN
  SELECT owner_id, equipment_name INTO v_owner_id, v_eq_name
  FROM public.equipment
  WHERE id = NEW.equipment_id;

  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.notifications (user_id, title, message, notification_type, related_booking_id)
    VALUES (
      v_owner_id,
      'New Equipment Booking Request',
      format('New %s request received for %s.', NEW.operation_type, coalesce(v_eq_name, 'your machine')),
      'booking_request',
      NEW.id
    );
  ELSIF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    IF NEW.status = 'accepted' THEN
      INSERT INTO public.notifications (user_id, title, message, notification_type, related_booking_id)
      VALUES (
        NEW.farmer_id,
        'Booking Request Accepted',
        format('%s has been accepted for your %s operation.', coalesce(v_eq_name, 'Equipment'), NEW.operation_type),
        'booking_accepted',
        NEW.id
      );
    ELSIF NEW.status = 'rejected' THEN
      INSERT INTO public.notifications (user_id, title, message, notification_type, related_booking_id)
      VALUES (
        NEW.farmer_id,
        'Booking Request Rejected',
        coalesce(NEW.rejection_reason, 'Your booking request was declined by the owner.'),
        'booking_rejected',
        NEW.id
      );
    ELSIF NEW.status = 'scheduled' THEN
      INSERT INTO public.notifications (user_id, title, message, notification_type, related_booking_id)
      VALUES (
        NEW.farmer_id,
        'Operation Schedule Updated',
        format('%s scheduled for %s.', coalesce(v_eq_name, 'Equipment'), to_char(NEW.assigned_start_time AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI UTC')),
        'schedule_updated',
        NEW.id
      );
    ELSIF NEW.status = 'rescheduling_required' THEN
      INSERT INTO public.notifications (user_id, title, message, notification_type, related_booking_id)
      VALUES (
        NEW.farmer_id,
        'Rescheduling Required Due to Disruption',
        format('Your booking for %s requires rescheduling due to an operational disruption.', coalesce(v_eq_name, 'equipment')),
        'rescheduling',
        NEW.id
      );
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_booking_change ON public.bookings;
CREATE TRIGGER trg_notify_booking_change
  AFTER INSERT OR UPDATE ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_on_booking_change();

-- Transactional RPC: Report Disruption WITHOUT Deleting or Cancelling Confirmed Bookings
CREATE OR REPLACE FUNCTION public.report_disruption_tx(
  p_disruption_type public.disruption_type_enum,
  p_description TEXT,
  p_equipment_id UUID DEFAULT NULL,
  p_start_time TIMESTAMPTZ DEFAULT timezone('utc', now()),
  p_end_time TIMESTAMPTZ DEFAULT NULL,
  p_affected_area TEXT DEFAULT ''
)
RETURNS public.disruptions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_caller UUID := auth.uid();
  v_disruption public.disruptions%ROWTYPE;
BEGIN
  IF v_caller IS NULL THEN
    RAISE EXCEPTION 'Authentication required to report a disruption.';
  END IF;

  INSERT INTO public.disruptions (
    equipment_id,
    disruption_type,
    description,
    start_time,
    end_time,
    affected_area,
    status,
    reported_by
  )
  VALUES (
    p_equipment_id,
    p_disruption_type,
    p_description,
    COALESCE(p_start_time, timezone('utc', now())),
    p_end_time,
    COALESCE(p_affected_area, ''),
    'active',
    v_caller
  )
  RETURNING * INTO v_disruption;

  -- Mark broken/unavailable equipment offline without deleting any confirmed bookings
  IF p_equipment_id IS NOT NULL THEN
    UPDATE public.equipment
    SET availability_status = CASE
      WHEN p_disruption_type = 'machine_breakdown' THEN 'maintenance'::public.equipment_availability_enum
      ELSE 'unavailable'::public.equipment_availability_enum
    END
    WHERE id = p_equipment_id;

    -- Transition overlapping active schedules/bookings to 'rescheduling_required'
    UPDATE public.schedules
    SET status = 'rescheduling_required'
    WHERE equipment_id = p_equipment_id
      AND status IN ('scheduled', 'in_progress')
      AND scheduled_end > v_disruption.start_time
      AND (v_disruption.end_time IS NULL OR scheduled_start < v_disruption.end_time);

    UPDATE public.bookings
    SET status = 'rescheduling_required'
    WHERE equipment_id = p_equipment_id
      AND status IN ('accepted', 'scheduled', 'in_progress')
      AND (assigned_end_time IS NULL OR assigned_end_time > v_disruption.start_time)
      AND (v_disruption.end_time IS NULL OR assigned_start_time IS NULL OR assigned_start_time < v_disruption.end_time);
  END IF;

  RETURN v_disruption;
END;
$$;

-- Transactional RPC: Restore Equipment Availability After Disruption Mitigation
CREATE OR REPLACE FUNCTION public.restore_equipment_availability(
  p_equipment_id UUID,
  p_disruption_id UUID DEFAULT NULL
)
RETURNS public.equipment
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_caller UUID := auth.uid();
  v_eq public.equipment%ROWTYPE;
BEGIN
  IF v_caller IS NULL THEN
    RAISE EXCEPTION 'Authentication required.';
  END IF;

  SELECT * INTO v_eq FROM public.equipment WHERE id = p_equipment_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Equipment not found.';
  END IF;

  IF v_eq.owner_id <> v_caller AND NOT public.is_admin() THEN
    RAISE EXCEPTION 'Permission denied: only the equipment owner or admin may restore availability.';
  END IF;

  UPDATE public.equipment
  SET availability_status = 'available'
  WHERE id = p_equipment_id
  RETURNING * INTO v_eq;

  IF p_disruption_id IS NOT NULL THEN
    UPDATE public.disruptions
    SET status = 'resolved', end_time = COALESCE(end_time, timezone('utc', now()))
    WHERE id = p_disruption_id;
  END IF;

  RETURN v_eq;
END;
$$;
