-- KRISHISYNC Migration 001: Extensions, Custom Enums/Domains, and Shared Trigger Functions
-- Run in Supabase SQL Editor or via `supabase db push`

-- Required for GIST exclusion constraints combining UUID equality (=) and TSTZRANGE overlap (&&)
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS btree_gist;

-- User roles (Admin assignment is blocked from client self-signup/updates)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_role') THEN
    CREATE TYPE public.user_role AS ENUM ('farmer', 'equipment_owner', 'admin');
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'equipment_type_enum') THEN
    CREATE TYPE public.equipment_type_enum AS ENUM (
      'Tractor',
      'Harvester',
      'Sprayer',
      'Seeder',
      'Plough',
      'Other'
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'equipment_availability_enum') THEN
    CREATE TYPE public.equipment_availability_enum AS ENUM (
      'available',
      'booked',
      'in_operation',
      'maintenance',
      'unavailable'
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'booking_status_enum') THEN
    CREATE TYPE public.booking_status_enum AS ENUM (
      'pending',
      'accepted',
      'rejected',
      'scheduled',
      'in_progress',
      'completed',
      'cancelled',
      'rescheduling_required'
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'schedule_status_enum') THEN
    CREATE TYPE public.schedule_status_enum AS ENUM (
      'scheduled',
      'in_progress',
      'completed',
      'cancelled',
      'rescheduling_required'
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'disruption_type_enum') THEN
    CREATE TYPE public.disruption_type_enum AS ENUM (
      'machine_breakdown',
      'weather_disruption',
      'equipment_unavailable',
      'other'
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'disruption_status_enum') THEN
    CREATE TYPE public.disruption_status_enum AS ENUM (
      'active',
      'mitigated',
      'resolved'
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'notification_type_enum') THEN
    CREATE TYPE public.notification_type_enum AS ENUM (
      'booking_request',
      'booking_accepted',
      'booking_rejected',
      'schedule_updated',
      'deadline_warning',
      'equipment_breakdown',
      'weather_disruption',
      'rescheduling'
    );
  END IF;
END
$$;

-- Shared updated_at timestamp trigger function
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = timezone('utc', now());
  RETURN NEW;
END;
$$;
