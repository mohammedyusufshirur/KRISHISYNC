-- KRISHISYNC Sample Seed Data (Development / Hackathon Testing)
-- NOTE: Run migrations 001 through 006 first.
-- Creates two test users in auth.users (trigger auto-creates profiles) and seeds sample equipment, plots, bookings, schedules, disruptions, and notifications.

DO $$
DECLARE
  v_farmer_id UUID := '11111111-1111-4111-8111-111111111111';
  v_owner_id  UUID := '22222222-2222-4222-8222-222222222222';
  v_eq1_id    UUID := '33333333-3333-4333-8333-333333333301';
  v_eq2_id    UUID := '33333333-3333-4333-8333-333333333302';
  v_eq3_id    UUID := '33333333-3333-4333-8333-333333333303';
  v_plot1_id  UUID := '44444444-4444-4444-8444-444444444401';
  v_plot2_id  UUID := '44444444-4444-4444-8444-444444444402';
  v_bk1_id    UUID := '55555555-5555-4555-8555-555555555501';
  v_bk2_id    UUID := '55555555-5555-4555-8555-555555555502';
BEGIN
  -- 1. Seed sample auth.users if not already present (password: KrishiSync@2026)
  INSERT INTO auth.users (
    id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
    raw_app_meta_data, raw_user_meta_data, created_at, updated_at
  )
  VALUES
    (
      v_farmer_id,
      '00000000-0000-0000-0000-000000000000',
      'authenticated',
      'authenticated',
      'farmer.demo@krishisync.in',
      crypt('KrishiSync@2026', gen_salt('bf')),
      timezone('utc', now()),
      '{"provider":"email","providers":["email"]}'::jsonb,
      '{"full_name":"Rajesh Deshmukh","phone":"+91 98230 44120","role":"farmer","address":"Baramati Cluster, Pune","latitude":"18.1384","longitude":"74.5210"}'::jsonb,
      timezone('utc', now()),
      timezone('utc', now())
    ),
    (
      v_owner_id,
      '00000000-0000-0000-0000-000000000000',
      'authenticated',
      'authenticated',
      'owner.demo@krishisync.in',
      crypt('KrishiSync@2026', gen_salt('bf')),
      timezone('utc', now()),
      '{"provider":"email","providers":["email"]}'::jsonb,
      '{"full_name":"Vikramjit Singh Gill","phone":"+91 98142 77890","role":"equipment_owner","address":"Baramati Hub, Pune","latitude":"18.1517","longitude":"74.5772"}'::jsonb,
      timezone('utc', now()),
      timezone('utc', now())
    )
  ON CONFLICT (id) DO NOTHING;

  -- 2. Seed Equipment
  INSERT INTO public.equipment (
    id, owner_id, equipment_name, equipment_type, brand, model, description,
    work_rate_acres_per_hour, hourly_rate, per_acre_rate, latitude, longitude, address, availability_status
  )
  VALUES
    (
      v_eq1_id, v_owner_id, 'John Deere 5310 Precision Tractor', 'Tractor', 'John Deere', '5310 Trem IV',
      '55 HP 4WD tractor with zero-till planter hitch.', 2.40, 950.00, 420.00,
      18.1517, 74.5772, 'Baramati Hub, Sector 4', 'available'
    ),
    (
      v_eq2_id, v_owner_id, 'Claas Crop Tiger 40 Combine', 'Harvester', 'Claas', 'Crop Tiger 40',
      '76 HP multi-crop tracked combine harvester.', 3.10, 2400.00, 850.00,
      18.1135, 75.0268, 'Indapur Depot, North Gate', 'booked'
    ),
    (
      v_eq3_id, v_owner_id, 'DJI Agras T40 Spray Drone', 'Sprayer', 'DJI', 'Agras T40',
      '40L dual-atomizer precision agricultural spray drone.', 12.50, 1650.00, 180.00,
      18.1604, 74.5910, 'Baramati Hub, Pad B', 'available'
    )
  ON CONFLICT (id) DO NOTHING;

  -- 3. Seed Plots
  INSERT INTO public.plots (
    id, farmer_id, plot_name, area_acres, crop_type, operation_type,
    latitude, longitude, address, preferred_start_time, deadline
  )
  VALUES
    (
      v_plot1_id, v_farmer_id, 'Nira Canal Block A-12', 14.50, 'Wheat', 'Sowing',
      18.1384, 74.5210, 'Malegaon Bk, Baramati',
      timezone('utc', now()) + interval '1 day',
      timezone('utc', now()) + interval '3 days'
    ),
    (
      v_plot2_id, v_farmer_id, 'Khandaj Terrace Plot B-04', 9.20, 'Sugarcane', 'Spraying',
      18.1742, 74.5608, 'Khandaj, Baramati',
      timezone('utc', now()) + interval '12 hours',
      timezone('utc', now()) + interval '2 days'
    )
  ON CONFLICT (id) DO NOTHING;

  -- 4. Seed Bookings
  INSERT INTO public.bookings (
    id, farmer_id, equipment_id, plot_id, operation_type,
    requested_start_time, requested_deadline, estimated_duration_hours,
    status, priority_score, assigned_start_time, assigned_end_time
  )
  VALUES
    (
      v_bk1_id, v_farmer_id, v_eq3_id, v_plot2_id, 'Spraying',
      timezone('utc', now()) + interval '1 day',
      timezone('utc', now()) + interval '2 days',
      1.00, 'scheduled', 92.00,
      timezone('utc', now()) + interval '1 day',
      timezone('utc', now()) + interval '1 day 2 hours'
    ),
    (
      v_bk2_id, v_farmer_id, v_eq1_id, v_plot1_id, 'Sowing',
      timezone('utc', now()) + interval '2 days',
      timezone('utc', now()) + interval '3 days',
      6.00, 'pending', 78.00, NULL, NULL
    )
  ON CONFLICT (id) DO NOTHING;

  -- 5. Seed Schedule Allocation
  INSERT INTO public.schedules (
    booking_id, equipment_id, farmer_id, plot_id,
    scheduled_start, scheduled_end, travel_buffer_minutes, estimated_travel_distance_km,
    status, scheduling_reason
  )
  VALUES (
    v_bk1_id, v_eq3_id, v_farmer_id, v_plot2_id,
    timezone('utc', now()) + interval '1 day',
    timezone('utc', now()) + interval '1 day 2 hours',
    20, 4.80, 'scheduled',
    'High priority deadline window with minimal transit buffer from Baramati Pad B.'
  )
  ON CONFLICT (booking_id) DO NOTHING;

  -- 6. Seed Sample Notification
  INSERT INTO public.notifications (
    user_id, title, message, notification_type, related_booking_id, is_read
  )
  VALUES (
    v_owner_id,
    'Pending Sowing Request',
    'Rajesh Deshmukh requested John Deere 5310 Precision Tractor for Nira Canal Block A-12.',
    'booking_request',
    v_bk2_id,
    FALSE
  );
END
$$;
